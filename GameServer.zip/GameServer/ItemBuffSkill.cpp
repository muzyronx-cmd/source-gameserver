#include "stdafx.h"
#include "ItemBuffSkill.h"
#include "MemScript.h"
#include "Util.h"
#include "ItemManager.h"
#include "Viewport.h"
#include "SkillManager.h"

ItemBuffSkill gItemBuffSkill;

ItemBuffSkill::ItemBuffSkill()
{
	this->m_ItemBuffSkill.clear();
}

ItemBuffSkill::~ItemBuffSkill()
{
}

void ItemBuffSkill::Load(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_ItemBuffSkill.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			ITEMBUFFSKILL_INFOS info;

			int section = lpMemScript->GetNumber();
			int index = lpMemScript->GetAsNumber();

			info.Index = section * MAX_ITEM_TYPE + index;

			info.Skill = lpMemScript->GetAsNumber();

			this->m_ItemBuffSkill.insert(std::pair<int, ITEMBUFFSKILL_INFOS>(info.Index, info));
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void ItemBuffSkill::ApplyBuffSkill(LPOBJ lpObj)
{
	CItem* lpItem = &lpObj->Inventory[8];

	if (lpItem->IsItem() != 0 && lpItem->m_Durability > 0)
	{
		std::map<int, ITEMBUFFSKILL_INFOS>::iterator it = this->m_ItemBuffSkill.find(lpItem->m_Index);

		if (it != this->m_ItemBuffSkill.end())
		{
			if (it->second.Skill >= 0)
			{
				gSkillManager.GCSkillAttackSend(lpObj, it->second.Skill, lpObj->Index, 1);

				for (int n = 0; n < MAX_VIEWPORT; n++)
				{
					if (lpObj->VpPlayer2[n].state == VIEWPORT_NONE)
					{
						continue;
					}

					int index = lpObj->VpPlayer2[n].index;

					gSkillManager.GCSkillAttackSend(lpObj, it->second.Skill, index, 0);
				}

				gSkillManager.GCSkillAttackSend(lpObj, it->second.Skill, lpObj->Index, 0);
			}
		}
	}
}