#pragma once

#include "Shop.h"

enum eCustomNpcMalucoState
{
	CUSTOM_NPC_MALUCO_STATE_BLANK = 0,
	CUSTOM_NPC_MALUCO_STATE_EMPTY = 1,
	CUSTOM_NPC_MALUCO_STATE_START = 2,
	CUSTOM_NPC_MALUCO_STATE_CLEAN = 3,
};

struct CUSTOM_NPC_MALUCO_START_TIME
{
	int Year;
	int Month;
	int Day;
	int DayOfWeek;
	int Hour;
	int Minute;
	int Second;
};

struct CUSTOM_NPC_MALUCO_RULE_INFO
{
	int AlarmTime;
	int EventTime;
};

struct CUSTOM_NPC_MALUCO_INFO
{
	int State;
	int RemainTime;
	int TargetTime;
	int TickCount;
	int AlarmMinSave;
	int AlarmMinLeft;

	CUSTOM_NPC_MALUCO_RULE_INFO RuleInfo;
	std::vector<CUSTOM_NPC_MALUCO_START_TIME> StartTime;
};

class CCustomNpcMaluco
{
public:
	CCustomNpcMaluco();
	virtual ~CCustomNpcMaluco();
	void Init();
	void ReadCustomNpcMalucoInfo(char* section, char* path);
	void Load(char* path);
	void MainProc();
	void ProcState_BLANK(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void ProcState_EMPTY(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void ProcState_START(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void ProcState_CLEAN(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void SetState(CUSTOM_NPC_MALUCO_INFO* lpInfo, int state);
	void SetState_BLANK(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void SetState_EMPTY(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void SetState_START(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void SetState_CLEAN(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	void CheckSync(CUSTOM_NPC_MALUCO_INFO* lpInfo);
	int GetState();
	void SetMonsterNumber();

private:
	int m_CustomNpcMalucoSwitch;
	char m_CustomNpcMalucoText1[128];
	char m_CustomNpcMalucoText2[128];
	char m_CustomNpcMalucoText3[128];
	CUSTOM_NPC_MALUCO_INFO m_CustomNpcMalucoInfo;
};

extern CCustomNpcMaluco gCustomNpcMaluco;