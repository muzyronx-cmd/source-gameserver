// Log.h: interface for the CLog class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#define MAX_LOG 13

enum eLogType
{
	LOG_GENERAL = 0,
	LOG_CHAT = 1,
	LOG_TRADE = 2,
	LOG_CONNECT = 3,
	LOG_HACK = 4,
	LOG_CASH_SHOP = 5,
	LOG_CHAOS_MIX = 6,
	LOG_LUA = 7,
	LOG_SKILL_HACK = 8,
	LOG_INVENTORY = 9,
	LOG_WAREHOUSE = 10,
	LOG_TRADEX = 11,
	LOG_LUA_EVENT = 12,
#ifdef CUSTOM_GAMESERVER
	LOG_DUEL = 13,
#endif
};

struct LOG_INFO
{
	BOOL Active;
	char Directory[256];
	int Day;
	int Month;
	int Year;
	char Filename[256];
	HANDLE File;
};

class CLog
{
public:
	CLog();
	virtual ~CLog();
	void AddLog(BOOL active,char* directory);
	void Output(eLogType type,char* text,...);
private:
	LOG_INFO m_LogInfo[MAX_LOG];
	int m_count;
};

extern CLog gLog;
