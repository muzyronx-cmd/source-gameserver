// CustomStore.cpp: implementation of the CCustomStore class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CustomStore.h"
#include "CashShop.h"
#include "CommandManager.h"
#include "DSProtocol.h"
#include "GameMain.h"
#include "Log.h"
#include "Map.h"
#include "MasterSkillTree.h"
#include "Notice.h"
#include "PcPoint.h"
#include "ServerInfo.h"
#include "SocketManager.h"
#include "Message.h"
#include "Util.h"
#include "LuaGameServer.h"

CCustomStore gCustomStore;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomStore::CCustomStore() // OK
{

}

CCustomStore::~CCustomStore() // OK
{

}

void CCustomStore::ReadCustomStoreInfo(char* section,char* path) // OK
{
	this->m_CustomStoreSwitch = GetPrivateProfileInt(section,"CustomStoreSwitch",0,path);

	this->m_CustomStoreMapZone = GetPrivateProfileInt(section,"CustomStoreMapZone",0,path);

	this->m_CustomStoreTime[0] = GetPrivateProfileInt(section, "CustomStoreTime_FREE", 0, path);

	this->m_CustomStoreTime[1] = GetPrivateProfileInt(section, "CustomStoreTime_VIP1", 0, path);

	this->m_CustomStoreTime[2] = GetPrivateProfileInt(section, "CustomStoreTime_VIP2", 0, path);

	this->m_CustomStoreTime[3] = GetPrivateProfileInt(section, "CustomStoreTime_VIP3", 0, path);

	this->m_CustomStoreEnable[0] = GetPrivateProfileInt(section,"CustomStoreEnable_FREE",0,path);

	this->m_CustomStoreEnable[1] = GetPrivateProfileInt(section,"CustomStoreEnable_VIP1",0,path);

	this->m_CustomStoreEnable[2] = GetPrivateProfileInt(section,"CustomStoreEnable_VIP2",0,path);

	this->m_CustomStoreEnable[3] = GetPrivateProfileInt(section,"CustomStoreEnable_VIP3",0,path);

	this->m_CustomStoreRequireLevel[0] = GetPrivateProfileInt(section,"CustomStoreRequireLevel_FREE",0,path);

	this->m_CustomStoreRequireLevel[1] = GetPrivateProfileInt(section,"CustomStoreRequireLevel_VIP1",0,path);

	this->m_CustomStoreRequireLevel[2] = GetPrivateProfileInt(section,"CustomStoreRequireLevel_VIP2",0,path);

	this->m_CustomStoreRequireLevel[3] = GetPrivateProfileInt(section,"CustomStoreRequireLevel_VIP3",0,path);

	this->m_CustomStoreRequireReset[0] = GetPrivateProfileInt(section,"CustomStoreRequireReset_FREE",0,path);

	this->m_CustomStoreRequireReset[1] = GetPrivateProfileInt(section,"CustomStoreRequireReset_VIP1",0,path);

	this->m_CustomStoreRequireReset[2] = GetPrivateProfileInt(section,"CustomStoreRequireReset_VIP2",0,path);

	this->m_CustomStoreRequireReset[3] = GetPrivateProfileInt(section,"CustomStoreRequireReset_VIP3",0,path);

	GetPrivateProfileString(section,"CustomStoreCommandSyntax","",this->m_CustomStoreCommandSyntax,sizeof(this->m_CustomStoreCommandSyntax),path);

	GetPrivateProfileString(section,"CustomStoreCommandJoBSyntax","",this->m_CustomStoreCommandJoBSyntax,sizeof(this->m_CustomStoreCommandJoBSyntax),path);

	GetPrivateProfileString(section,"CustomStoreCommandJoSSyntax","",this->m_CustomStoreCommandJoSSyntax,sizeof(this->m_CustomStoreCommandJoSSyntax),path);

	GetPrivateProfileString(section,"CustomStoreCommandJoCSyntax","",this->m_CustomStoreCommandJoCSyntax,sizeof(this->m_CustomStoreCommandJoCSyntax),path);

	#if(GAMESERVER_UPDATE>=501)

	GetPrivateProfileString(section,"CustomStoreCommandWCCSyntax","",this->m_CustomStoreCommandWCCSyntax,sizeof(this->m_CustomStoreCommandWCCSyntax),path);

	GetPrivateProfileString(section,"CustomStoreCommandWCPSyntax","",this->m_CustomStoreCommandWCPSyntax,sizeof(this->m_CustomStoreCommandWCPSyntax),path);

	GetPrivateProfileString(section,"CustomStoreCommandWCGSyntax","",this->m_CustomStoreCommandWCGSyntax,sizeof(this->m_CustomStoreCommandWCGSyntax),path);

	#else

	GetPrivateProfileString(section,"CustomStoreCommandPCPSyntax","",this->m_CustomStoreCommandWCGSyntax,sizeof(this->m_CustomStoreCommandWCGSyntax),path);

	#endif

	GetPrivateProfileString(section,"CustomStoreJoBName","",this->m_CustomStoreJoBName,sizeof(this->m_CustomStoreJoBName),path);

	GetPrivateProfileString(section,"CustomStoreJoSName","",this->m_CustomStoreJoSName,sizeof(this->m_CustomStoreJoSName),path);

	GetPrivateProfileString(section,"CustomStoreJoCName","",this->m_CustomStoreJoCName,sizeof(this->m_CustomStoreJoCName),path);

	#if(GAMESERVER_UPDATE>=501)

	GetPrivateProfileString(section,"CustomStoreWCCName","",this->m_CustomStoreWCCName,sizeof(this->m_CustomStoreWCCName),path);

	GetPrivateProfileString(section,"CustomStoreWCPName","",this->m_CustomStoreWCPName,sizeof(this->m_CustomStoreWCPName),path);

	GetPrivateProfileString(section,"CustomStoreWCGName","",this->m_CustomStoreWCGName,sizeof(this->m_CustomStoreWCGName),path);

	#else

	GetPrivateProfileString(section,"CustomStorePCPName","",this->m_CustomStoreWCGName,sizeof(this->m_CustomStoreWCGName),path);

	#endif

	this->m_CustomStoreOfflineSwitch = GetPrivateProfileInt(section,"CustomStoreOfflineSwitch",0,path);

	this->m_CustomStoreOfflineGPGain = GetPrivateProfileInt(section,"CustomStoreOfflineGPGain",0,path);

	this->m_CustomStoreOfflineMapZone = GetPrivateProfileInt(section,"CustomStoreOfflineMapZone",0,path);

	this->m_CustomStoreOfflineEnable[0] = GetPrivateProfileInt(section,"CustomStoreOfflineEnable_FREE",0,path);

	this->m_CustomStoreOfflineEnable[1] = GetPrivateProfileInt(section,"CustomStoreOfflineEnable_VIP1",0,path);

	this->m_CustomStoreOfflineEnable[2] = GetPrivateProfileInt(section,"CustomStoreOfflineEnable_VIP2",0,path);

	this->m_CustomStoreOfflineEnable[3] = GetPrivateProfileInt(section,"CustomStoreOfflineEnable_VIP3",0,path);

	this->m_CustomStoreOfflineRequireLevel[0] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireLevel_FREE",0,path);

	this->m_CustomStoreOfflineRequireLevel[1] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireLevel_VIP1",0,path);

	this->m_CustomStoreOfflineRequireLevel[2] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireLevel_VIP2",0,path);

	this->m_CustomStoreOfflineRequireLevel[3] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireLevel_VIP3",0,path);

	this->m_CustomStoreOfflineRequireReset[0] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireReset_FREE",0,path);

	this->m_CustomStoreOfflineRequireReset[1] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireReset_VIP1",0,path);

	this->m_CustomStoreOfflineRequireReset[2] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireReset_VIP2",0,path);

	this->m_CustomStoreOfflineRequireReset[3] = GetPrivateProfileInt(section,"CustomStoreOfflineRequireReset_VIP3",0,path);

	GetPrivateProfileString(section,"CustomStoreOfflineCommandSyntax","",this->m_CustomStoreOfflineCommandSyntax,sizeof(this->m_CustomStoreOfflineCommandSyntax),path);
}

#ifdef CUSTOM_GAMESERVER
void CCustomStore::CustomStoreOpen(LPOBJ lpObj, int type)
{
	if (lpObj->TradeDuel != 0)
	{
		return;
	}

	if (lpObj->PShopOpen == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "you need to open personal shop first");
		return;
	}

	if (gMap[lpObj->Map].CheckAttr(lpObj->X, lpObj->Y, 1) == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 702));
		return;
	}

	if (lpObj->Level <= 5)
	{
		gPersonalShop.GCPShopOpenSend(lpObj->Index, 2);
		return;
	}

	if (lpObj->Map != MAP_TARKAN)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "you need to be in tarkan!");
		return;
	}

	lpObj->PShopOpen = 1;

	lpObj->PShopCustom = 1;

	lpObj->PShopCustomType = type;

	lpObj->PShopCustomOffline = 0;

	lpObj->PShopCustomOfflineTime = 0;

	lpObj->PShopCustomTime = 0;

	switch (type)
	{
	case 1:
		memcpy(lpObj->PShopText, "::: ZEN SHOP :::", sizeof(lpObj->PShopText));
		break;
	case 2:
		memcpy(lpObj->PShopText, "::: TRIAD COIN SHOP :::", sizeof(lpObj->PShopText));
		break;
	}

	gPersonalShop.GCPShopOpenSend(lpObj->Index, 1);

	PMSG_PSHOP_TEXT_CHANGE_SEND pMsg;

	pMsg.header.set(0x3F, 0x10, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(lpObj->Index);

	pMsg.index[1] = SET_NUMBERLB(lpObj->Index);

	memcpy(pMsg.text, lpObj->PShopText, sizeof(pMsg.text));

	memcpy(pMsg.name, lpObj->Name, sizeof(pMsg.name));

	DataSend(lpObj->Index, (BYTE*)&pMsg, pMsg.header.size);

	//Disconnect
	lpObj->Socket = INVALID_SOCKET;

	lpObj->PShopCustomOffline = 1;

	lpObj->PShopCustomOfflineTime = 0;

	lpObj->PShopCustomTime = 0;

	closesocket(lpObj->PerSocketContext->Socket);

#ifdef CUSTOM_GAMESERVER
	this->SendOfflineTrade(lpObj);
#endif
}
#endif

void CCustomStore::CommandCustomStore(LPOBJ lpObj,char* arg) // OK
{
	if(this->m_CustomStoreSwitch == 0)
	{
		return;
	}

	if (lpObj->TradeDuel != 0)
	{
		return;
	}

#if(GAMESERVER_UPDATE>=401)
	if(this->m_CustomStoreEnable[lpObj->AccountLevel] == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0,gMessage.GetMessage(lpObj->m_Language, 705));
		return;
	}

	if(((gMasterSkillTree.CheckMasterLevel(lpObj)==0)?lpObj->Level:(lpObj->Level+lpObj->MasterLevel)) < this->m_CustomStoreRequireLevel[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 714),this->m_CustomStoreRequireLevel[lpObj->AccountLevel]);
		return;
	}

	if(lpObj->Reset < this->m_CustomStoreRequireReset[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 715),this->m_CustomStoreRequireReset[lpObj->AccountLevel]);
		return;
	}

	char mode[32] = {0};

	gCommandManager.GetString(arg,mode,sizeof(mode),0);

	if(strcmp(mode,"") != 0)
	{
		if(strcmp(mode,this->m_CustomStoreCommandJoBSyntax) == 0)
		{
			this->OpenCustomStore(lpObj,0);
		}
		else if(strcmp(mode,this->m_CustomStoreCommandJoSSyntax) == 0)
		{
			this->OpenCustomStore(lpObj,1);
		}
		else if(strcmp(mode,this->m_CustomStoreCommandJoCSyntax) == 0)
		{
			this->OpenCustomStore(lpObj,2);
		}
		else if(strcmp(mode,this->m_CustomStoreCommandWCCSyntax) == 0)
		{
			this->OpenCustomStore(lpObj,3);
		}
		else if(strcmp(mode,this->m_CustomStoreCommandWCPSyntax) == 0)
		{
			this->OpenCustomStore(lpObj,4);
		}
		else if(strcmp(mode,this->m_CustomStoreCommandWCGSyntax) == 0)
		{
			this->OpenCustomStore(lpObj,5);
		}
	}
#endif
}

void CCustomStore::CommandCustomStoreOffline(LPOBJ lpObj,char* arg) // OK
{
	if(this->m_CustomStoreOfflineSwitch == 0)
	{
		return;
	}

	if (lpObj->TradeDuel != 0)
	{
		return;
	}

	if(this->m_CustomStoreOfflineEnable[lpObj->AccountLevel] == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0,gMessage.GetMessage(lpObj->m_Language, 700));
		return;
	}

	if(((gMasterSkillTree.CheckMasterLevel(lpObj)==0)?lpObj->Level:(lpObj->Level+lpObj->MasterLevel)) < this->m_CustomStoreOfflineRequireLevel[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 703),this->m_CustomStoreOfflineRequireLevel[lpObj->AccountLevel]);
		return;
	}

	if(lpObj->Reset < this->m_CustomStoreOfflineRequireReset[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 704),this->m_CustomStoreOfflineRequireReset[lpObj->AccountLevel]);
		return;
	}

	if(lpObj->PShopOpen == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 701));
		return;
	}

	if(gMap[lpObj->Map].CheckAttr(lpObj->X,lpObj->Y,1) == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 702));
		return;
	}

	if(CC_MAP_RANGE(lpObj->Map) != 0 
#if(GAMESERVER_UPDATE>=251)
		|| IT_MAP_RANGE(lpObj->Map) != 0
#endif
		)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 702));
		return;
	}

	if(this->m_CustomStoreOfflineMapZone != -1 && this->m_CustomStoreOfflineMapZone != lpObj->Map)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 702));
		return;
	}

	lpObj->Socket = INVALID_SOCKET;

	lpObj->PShopCustomOffline = 1;

	lpObj->PShopCustomOfflineTime = 0;

	lpObj->PShopCustomTime = this->m_CustomStoreTime[lpObj->AccountLevel] * 60;

	closesocket(lpObj->PerSocketContext->Socket);

#ifdef CUSTOM_GAMESERVER
	this->SendOfflineTrade(lpObj);
#endif
}

void CCustomStore::OpenCustomStore(LPOBJ lpObj,int type) // OK
{
	if(gServerInfo.m_PersonalShopSwitch == 0)
	{
		return;
	}

	if(lpObj->PShopOpen != 0)
	{
		gPersonalShop.GCPShopOpenSend(lpObj->Index,0);
		return;
	}

	if(gMap[lpObj->Map].CheckAttr(lpObj->X,lpObj->Y,1) == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 706));
		return;
	}

	if(CC_MAP_RANGE(lpObj->Map) != 0
#if(GAMESERVER_UPDATE>=251)
		|| IT_MAP_RANGE(lpObj->Map) != 0
#endif
		)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 706));
		return;
	}

	if(this->m_CustomStoreMapZone != -1 && this->m_CustomStoreMapZone != lpObj->Map)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 706));
		return;
	}

	if(gPersonalShop.CheckPersonalShopOpen(lpObj->Index) == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 707));
		return;
	}

	if(lpObj->Level <= 5)
	{
		gPersonalShop.GCPShopOpenSend(lpObj->Index,2);
		return;
	}

	lpObj->PShopOpen = 1;

	lpObj->PShopCustom = 1;

	lpObj->PShopCustomType = type;

	lpObj->PShopCustomOffline = 0;

	lpObj->PShopCustomOfflineTime = 0;

	lpObj->PShopCustomTime = this->m_CustomStoreTime[lpObj->AccountLevel] * 60;

	if (this->m_CustomStoreTime[lpObj->AccountLevel] > 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 716), this->m_CustomStoreTime[lpObj->AccountLevel]);
	}

	switch(type)
	{
		case 0:
			memcpy(lpObj->PShopText,this->m_CustomStoreJoBName,sizeof(lpObj->PShopText));
			break;
		case 1:
			memcpy(lpObj->PShopText,this->m_CustomStoreJoSName,sizeof(lpObj->PShopText));
			break;
		case 2:
			memcpy(lpObj->PShopText,this->m_CustomStoreJoCName,sizeof(lpObj->PShopText));
			break;
		case 3:
			memcpy(lpObj->PShopText,this->m_CustomStoreWCCName,sizeof(lpObj->PShopText));
			break;
		case 4:
			memcpy(lpObj->PShopText,this->m_CustomStoreWCPName,sizeof(lpObj->PShopText));
			break;
		case 5:
			memcpy(lpObj->PShopText,this->m_CustomStoreWCGName,sizeof(lpObj->PShopText));
			break;
	}

	gPersonalShop.GCPShopOpenSend(lpObj->Index,1);

	PMSG_PSHOP_TEXT_CHANGE_SEND pMsg;

	pMsg.header.set(0x3F,0x10,sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(lpObj->Index);

	pMsg.index[1] = SET_NUMBERLB(lpObj->Index);

	memcpy(pMsg.text,lpObj->PShopText,sizeof(pMsg.text));

	memcpy(pMsg.name,lpObj->Name,sizeof(pMsg.name));

	DataSend(lpObj->Index,(BYTE*)&pMsg,pMsg.header.size);
}

bool CCustomStore::OnPShopOpen(LPOBJ lpObj) // OK
{
	return ((lpObj->PShopCustom==0)?0:1);
}

void CCustomStore::OnPShopClose(LPOBJ lpObj) // OK
{
	if(lpObj->PShopCustom != 0)
	{
		lpObj->PShopCustom = 0;
		lpObj->PShopCustomType = 0;
	}

	if(lpObj->PShopCustomOffline == 1)
	{
		lpObj->PShopCustomOffline = 2;
		lpObj->PShopCustomOfflineTime = 5;
	}

#ifdef CUSTOM_GAMESERVER
	this->SendDeleteAllItemOffTrade(lpObj);
#endif
}

void CCustomStore::OnPShopSecondProc(LPOBJ lpObj) // OK
{
	if(lpObj->PShopCustomOffline != 0)
	{
		if(lpObj->PShopCustomOffline == 2)
		{
			if((--lpObj->PShopCustomOfflineTime) == 0)
			{
				gObjDel(lpObj->Index);
				lpObj->PShopCustomOffline = 0;
				lpObj->PShopCustomOfflineTime = 0;
			}
		}

		lpObj->CheckSumTime = GetTickCount();
		lpObj->ConnectTickCount = GetTickCount();
		#if(GAMESERVER_UPDATE>=250)
		lpObj->PcPointPointTime = ((this->m_CustomStoreOfflineGPGain==0)?GetTickCount():lpObj->PcPointPointTime);
		lpObj->CashShopGoblinPointTime = ((this->m_CustomStoreOfflineGPGain==0)?GetTickCount():lpObj->CashShopGoblinPointTime);
		#endif
	}

	if (lpObj->PShopCustomTime > 0) {
		if ((--lpObj->PShopCustomTime) == 0) {
			gPersonalShop.GCPShopCloseSend(lpObj->Index, 1);

			lpObj->PShopOpen = 0;
			memset(lpObj->PShopText, 0, sizeof(lpObj->PShopText));
			this->OnPShopClose(lpObj);

			gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 717));
		}
	}
}

void CCustomStore::OnPShopAlreadyConnected(LPOBJ lpObj) // OK
{
	if(lpObj->PShopCustomOffline != 0)
	{
		gObjDel(lpObj->Index);
		lpObj->PShopCustomOffline = 0;
		lpObj->PShopCustomOfflineTime = 0;
	}
}

void CCustomStore::OnPShopItemList(LPOBJ lpObj,LPOBJ lpTarget) // OK
{
	if(lpTarget->PShopCustom != 0)
	{
		switch(lpTarget->PShopCustomType)
		{
			case 0:
				gNotice.GCNoticeSend(lpObj->Index,0,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 708));
				break;
			case 1:
				gNotice.GCNoticeSend(lpObj->Index,0,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 709));
				break;
			case 2:
				gNotice.GCNoticeSend(lpObj->Index,0,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 710));
				break;
			case 3:
				gNotice.GCNoticeSend(lpObj->Index,0,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 711));
				break;
			case 4:
				gNotice.GCNoticeSend(lpObj->Index,0,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 712));
				break;
			case 5:
				gNotice.GCNoticeSend(lpObj->Index,0,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 713));
				break;
		}
	}
}

bool CCustomStore::OnPShopBuyItemRecv(PMSG_PSHOP_BUY_ITEM_RECV* lpMsg,int aIndex) // OK
{
	LPOBJ lpObj = &gObj[aIndex];

	if(gObjIsConnectedGP(aIndex) == 0)
	{
		return 1;
	}

	int bIndex = MAKE_NUMBERW(lpMsg->index[0],lpMsg->index[1]);

	if(gObjIsConnectedGP(bIndex) == 0)
	{
		return 1;
	}

	LPOBJ lpTarget = &gObj[bIndex];

	if(lpTarget->PShopOpen == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,3);
		return 1;
	}

	if(lpTarget->PShopCustom == 0)
	{
		return 0;
	}

	if(lpTarget->PShopTransaction != 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,4);
		return 1;
	}

	if(INVENTORY_SHOP_RANGE(lpMsg->slot) == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,5);
		return 1;
	}

	gObjFixInventoryPointer(aIndex);

	if(lpObj->Transaction == 1)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,6);
		return 1;
	}

	char name[11] = {0};

	memcpy(name,lpMsg->name,sizeof(lpMsg->name));
	
	if(strcmp(name,lpTarget->Name) != 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,6);
		return 1;
	}

	if(lpTarget->Inventory[lpMsg->slot].IsItem() == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,6);
		return 1;
	}

#if(GAMESERVER_UPDATE == 201 || GAMESERVER_UPDATE == 603)
	if (gServerInfo.m_PersonalShopCustom == 0) {
		if (lpTarget->Inventory[lpMsg->slot].m_PShopValue <= 0)
		{
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 6);
			return 1;
		}
	}
#else
	if (gServerInfo.m_PersonalShopCustom == 0) {
		if (lpTarget->Inventory[lpMsg->slot].m_PShopValue <= 0)
		{
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 6);
			return 1;
		}
}
#endif

#ifdef CUSTOM_GAMESERVER_GRING
	if (lpTarget->PShopCustomType == 2)
	{
		gPcPoint.GDPcPointRecievePointSend(aIndex, (DWORD)&CCustomStore::OnPShopBuyItemCallbackRecv, (DWORD)&gObj[bIndex], lpMsg->slot);
		return 1;
	}

	if (lpObj->Money < ((DWORD)lpTarget->Inventory[lpMsg->slot].m_PShopValue))
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 7);
		return 1;
	}

	if (gObjCheckMaxMoney(bIndex, lpTarget->Inventory[lpMsg->slot].m_PShopValue) == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 8);
		return 1;
	}
#elif (GAMESERVER_UPDATE>=501)
	#if(GAMESERVER_UPDATE>=501)

	if(lpTarget->PShopCustomType == 3 || lpTarget->PShopCustomType == 4 || lpTarget->PShopCustomType == 5)
	{
		gCashShop.GDCashShopRecievePointSend(aIndex,(DWORD)&CCustomStore::OnPShopBuyItemCallbackRecv,(DWORD)&gObj[bIndex],lpMsg->slot);
		return 1;
	}

	#else

	if(lpTarget->PShopCustomType == 3 || lpTarget->PShopCustomType == 4 || lpTarget->PShopCustomType == 5)
	{
		gPcPoint.GDPcPointRecievePointSend(aIndex,(DWORD)&CCustomStore::OnPShopBuyItemCallbackRecv,(DWORD)&gObj[bIndex],lpMsg->slot);
		return 1;
	}

	#endif


	int PShopJoBValue = ((lpTarget->PShopCustomType==0)?lpTarget->Inventory[lpMsg->slot].m_PShopValue:0);

	int PShopJoSValue = ((lpTarget->PShopCustomType==1)?lpTarget->Inventory[lpMsg->slot].m_PShopValue:0);

	int PShopJoCValue = ((lpTarget->PShopCustomType==2)?lpTarget->Inventory[lpMsg->slot].m_PShopValue:0);

	int RequireJewelCount[3] = {0};

	int PaymentJewelCount[3] = {0};

	int RequireJewelTable[3][4] = {0};

	int PaymentJewelTable[3][4] = {0};

	gPersonalShop.GetRequireJewelCount(lpObj,&RequireJewelCount[0],RequireJewelTable[0],0,PShopJoBValue);

	gPersonalShop.GetRequireJewelCount(lpObj,&RequireJewelCount[1],RequireJewelTable[1],1,PShopJoSValue);

	gPersonalShop.GetRequireJewelCount(lpObj,&RequireJewelCount[2],RequireJewelTable[2],2,PShopJoCValue);

	gPersonalShop.GetPaymentJewelCount(lpTarget,&PaymentJewelCount[0],PaymentJewelTable[0],0,PShopJoBValue);

	gPersonalShop.GetPaymentJewelCount(lpTarget,&PaymentJewelCount[1],PaymentJewelTable[1],1,PShopJoSValue);

	gPersonalShop.GetPaymentJewelCount(lpTarget,&PaymentJewelCount[2],PaymentJewelTable[2],2,PShopJoCValue);

	if(RequireJewelCount[0] < PShopJoBValue)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,7);
		return 1;
	}

	if(RequireJewelCount[1] < PShopJoSValue)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,7);
		return 1;
	}

	if(RequireJewelCount[2] < PShopJoCValue)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,7);
		return 1;
	}

	if(PShopJoBValue > 0 && RequireJewelTable[0][0] == 0 && RequireJewelTable[0][1] == 0 && RequireJewelTable[0][2] == 0 && RequireJewelTable[0][3] == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,7);
		return 1;
	}

	if(PShopJoSValue > 0 && RequireJewelTable[1][0] == 0 && RequireJewelTable[1][1] == 0 && RequireJewelTable[1][2] == 0 && RequireJewelTable[1][3] == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,7);
		return 1;
	}

	if(PShopJoCValue > 0 && RequireJewelTable[2][0] == 0 && RequireJewelTable[2][1] == 0 && RequireJewelTable[2][2] == 0 && RequireJewelTable[2][3] == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,7);
		return 1;
	}

	if(gItemManager.GetInventoryEmptySlotCount(lpTarget) < (PaymentJewelCount[0]+PaymentJewelCount[1]+PaymentJewelCount[2]))
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,7);
		return 1;
	}

	if (gServerInfo.m_PersonalShopCustom == 0) {
		if (lpObj->Money < ((DWORD)lpTarget->Inventory[lpMsg->slot].m_PShopValue))
		{
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 7);
			return 1;
		}

		if (gObjCheckMaxMoney(bIndex, lpTarget->Inventory[lpMsg->slot].m_PShopValue) == 0)
		{
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 8);
			return 1;
		}
	}
#if (GAMESERVER_UPDATE==603)
	else {
		int CheckHaveCoin = gLuaGameServer.CheckPersonalShopValue(aIndex
			, lpTarget->Inventory[lpMsg->slot].m_Index
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);

		if (CheckHaveCoin != 1) {
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, CheckHaveCoin);
			return 1;
		}
	}
#endif
#else
	if (gServerInfo.m_PersonalShopCustom == 0) {
		if (lpObj->Money < ((DWORD)lpTarget->Inventory[lpMsg->slot].m_PShopValue))
		{
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 7);
			return 1;
		}

		if (gObjCheckMaxMoney(bIndex, lpTarget->Inventory[lpMsg->slot].m_PShopValue) == 0)
		{
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, 8);
			return 1;
		}
	}
#if GAMESERVER_UPDATE == 201 || GAMESERVER_UPDATE == 603
	else {
		int CheckHaveCoin = gLuaGameServer.CheckPersonalShopValue(aIndex
			, lpTarget->Inventory[lpMsg->slot].m_Index
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);

		if (CheckHaveCoin != 1) {
			gPersonalShop.GCPShopBuyItemSend(aIndex, bIndex, 0, CheckHaveCoin);
			return 1;
		}
	}
#endif
#endif

	lpTarget->PShopTransaction = 1;

	BYTE result = gItemManager.InventoryInsertItem(aIndex,lpTarget->Inventory[lpMsg->slot]);

	if(result == 0xFF)
	{
		gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,0,8);
		return 1;
	}

#if(GAMESERVER_UPDATE>=603)
	gLog.Output(LOG_TRADE,"[SellPesonalShopItem][%s][%s] - (Account: %s, Name: %s, Value: %d, JoBValue: %d, JoSValue: %d, JoCValue: %d, Index: %04d, Level: %02d, Serial: %08X, Option1: %01d, Option2: %01d, Option3: %01d, NewOption: %03d, JewelOfHarmonyOption: %03d, ItemOptionEx: %03d, SocketOption: %03d, %03d, %03d, %03d, %03d)",lpTarget->Account,lpTarget->Name,lpObj->Account,0,PShopJoBValue,PShopJoSValue,PShopJoCValue,lpTarget->Inventory[lpMsg->slot].m_Index,lpTarget->Inventory[lpMsg->slot].m_Level,lpTarget->Inventory[lpMsg->slot].m_Serial,lpTarget->Inventory[lpMsg->slot].m_Option1,lpTarget->Inventory[lpMsg->slot].m_Option2,lpTarget->Inventory[lpMsg->slot].m_Option3,lpTarget->Inventory[lpMsg->slot].m_NewOption,lpTarget->Inventory[lpMsg->slot].m_JewelOfHarmonyOption,lpTarget->Inventory[lpMsg->slot].m_ItemOptionEx,lpTarget->Inventory[lpMsg->slot].m_SocketOption[0],lpTarget->Inventory[lpMsg->slot].m_SocketOption[1],lpTarget->Inventory[lpMsg->slot].m_SocketOption[2],lpTarget->Inventory[lpMsg->slot].m_SocketOption[3],lpTarget->Inventory[lpMsg->slot].m_SocketOption[4]);
#else
	gLog.Output(LOG_TRADE, "[SellPesonalShopItem][%s][%s] - (Account: %s, Name: %s, Value: %d, Index: %04d, Level: %02d, Serial: %08X, Option1: %01d, Option2: %01d, Option3: %01d, NewOption: %03d, JewelOfHarmonyOption: %03d, ItemOptionEx: %03d, SocketOption: %03d, %03d, %03d, %03d, %03d)", lpTarget->Account, lpTarget->Name, lpObj->Account, lpObj->Name, lpTarget->Inventory[lpMsg->slot].m_PShopValue, lpTarget->Inventory[lpMsg->slot].m_Index, lpTarget->Inventory[lpMsg->slot].m_Level, lpTarget->Inventory[lpMsg->slot].m_Serial, lpTarget->Inventory[lpMsg->slot].m_Option1, lpTarget->Inventory[lpMsg->slot].m_Option2, lpTarget->Inventory[lpMsg->slot].m_Option3, lpTarget->Inventory[lpMsg->slot].m_NewOption, lpTarget->Inventory[lpMsg->slot].m_JewelOfHarmonyOption, lpTarget->Inventory[lpMsg->slot].m_ItemOptionEx, lpTarget->Inventory[lpMsg->slot].m_SocketOption[0], lpTarget->Inventory[lpMsg->slot].m_SocketOption[1], lpTarget->Inventory[lpMsg->slot].m_SocketOption[2], lpTarget->Inventory[lpMsg->slot].m_SocketOption[3], lpTarget->Inventory[lpMsg->slot].m_SocketOption[4]);
#endif

#if (GAMESERVER_UPDATE>= 603)
	gPersonalShop.SetRequireJewelCount(lpObj,RequireJewelTable[0],0);

	gPersonalShop.SetRequireJewelCount(lpObj,RequireJewelTable[1],1);

	gPersonalShop.SetRequireJewelCount(lpObj,RequireJewelTable[2],2);

	if (gServerInfo.m_PersonalShopCustom == 0) {
		lpObj->Money -= lpTarget->Inventory[lpMsg->slot].m_PShopValue;

		GCMoneySend(aIndex, lpObj->Money);
	}
#if (GAMESERVER_UPDATE==603)
	else {
		gLog.Output(LOG_TRADE, "[SellPesonalShopItem][%s][%s] - (Account: %s, Name: %s, Coin1: %d, Coin2: %d, Coin3: %d, Coin4: %d)", lpTarget->Account, lpTarget->Name, lpObj->Account, lpObj->Name, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);
		gLuaGameServer.PersonalShopDecreaseValue(lpObj->Index
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);
	}
#endif

	gPersonalShop.GCPShopBuyItemSend(aIndex,bIndex,result,1);
#else
	if (gServerInfo.m_PersonalShopCustom == 0) {
		lpObj->Money -= lpTarget->Inventory[lpMsg->slot].m_PShopValue;

		GCMoneySend(aIndex, lpObj->Money);
	}
	#if GAMESERVER_UPDATE == 201 || GAMESERVER_UPDATE == 603
	else {
		gLog.Output(LOG_TRADE, "[SellPesonalShopItem][%s][%s] - (Account: %s, Name: %s, Coin1: %d, Coin2: %d, Coin3: %d, Coin4: %d)", lpTarget->Account, lpTarget->Name, lpObj->Account, lpObj->Name, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);
		gLuaGameServer.PersonalShopDecreaseValue(lpObj->Index
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);
	}
	#endif
#endif

	GDCharacterInfoSaveSend(aIndex);

#if (GAMESERVER_UPDATE>= 603)
	gPersonalShop.SetPaymentJewelCount(lpTarget,PaymentJewelTable[0],0);

	gPersonalShop.SetPaymentJewelCount(lpTarget,PaymentJewelTable[1],1);

	gPersonalShop.SetPaymentJewelCount(lpTarget,PaymentJewelTable[2],2);

	if (gServerInfo.m_PersonalShopCustom == 0) {
		lpTarget->Money += lpTarget->Inventory[lpMsg->slot].m_PShopValue;
		GCMoneySend(bIndex, lpTarget->Money);
	}
#if (GAMESERVER_UPDATE==603)
	else {
		gLuaGameServer.PersonalShopAddValue(lpTarget->Index
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3
			, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);
	}
#endif

	gPersonalShop.GCPShopSellItemSend(bIndex, aIndex, lpMsg->slot);
#else
	if (gServerInfo.m_PersonalShopCustom == 0) {
#ifdef CUSTOM_GAMESERVER_GRING
		int commision = (lpTarget->Inventory[lpMsg->slot].m_PShopValue * 1) / 100;

		lpTarget->Money += (lpTarget->Inventory[lpMsg->slot].m_PShopValue - commision);
#else
		lpTarget->Money += lpTarget->Inventory[lpMsg->slot].m_PShopValue;
#endif
		GCMoneySend(bIndex, lpTarget->Money);
	}
	#if GAMESERVER_UPDATE == 201 || GAMESERVER_UPDATE == 603
	else {
		if (gServerInfo.m_PersonalShopCustom == 1) {
			gLuaGameServer.PersonalShopAddValue(lpTarget->Index
				, lpTarget->Inventory[lpMsg->slot].m_ShopCoin1
				, lpTarget->Inventory[lpMsg->slot].m_ShopCoin2
				, lpTarget->Inventory[lpMsg->slot].m_ShopCoin3
				, lpTarget->Inventory[lpMsg->slot].m_ShopCoin4);
		}
	}
	#endif
#endif

	gItemManager.InventoryDelItem(bIndex,lpMsg->slot);
	gItemManager.GCItemDeleteSend(bIndex,lpMsg->slot,1);

#ifdef CUSTOM_GAMESERVER
	gItemManager.GCItemListSend(aIndex);

	gCustomStore.SendDeleteItemOffTrade(lpObj, lpMsg->slot);
#endif

	GDCharacterInfoSaveSend(bIndex);

	if(gPersonalShop.CheckPersonalShop(bIndex) == 0)
	{
		lpTarget->PShopItemChange = 1;
	}
	else
	{
		lpTarget->PShopOpen = 0;
		memset(lpTarget->PShopText,0,sizeof(lpTarget->PShopText));
		gPersonalShop.GCPShopCloseSend(bIndex,1);
		this->OnPShopClose(lpTarget);
	}

	lpTarget->PShopTransaction = 0;

	return 1;
}

void CCustomStore::OnPShopBuyItemCallbackRecv(LPOBJ lpObj,LPOBJ lpTarget,DWORD slot,DWORD WCoinC,DWORD WCoinP,DWORD GoblinPoint) // OK
{
	if(gObjIsConnectedGP(lpTarget->Index) == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,3);
		return;
	}

	if(lpTarget->PShopOpen == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,3);
		return;
	}

	if(lpTarget->PShopTransaction != 0)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,4);
		return;
	}

	if(lpTarget->Inventory[slot].IsItem() == 0)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,6);
		return;
	}

#ifdef CUSTOM_GAMESERVER_GRING
	DWORD PShopWGPValue = lpTarget->Inventory[slot].m_PShopValue;

	if (WCoinC < PShopWGPValue)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index, lpTarget->Index, 0, 7);
		return;
	}
#else
	DWORD PShopWCCValue = ((lpTarget->PShopCustomType==3)?lpTarget->Inventory[slot].m_PShopValue:0);

	DWORD PShopWCPValue = ((lpTarget->PShopCustomType==4)?lpTarget->Inventory[slot].m_PShopValue:0);

	DWORD PShopWGPValue = ((lpTarget->PShopCustomType==5)?lpTarget->Inventory[slot].m_PShopValue:0);

	if(WCoinC < PShopWCCValue)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,7);
		return;
	}

	if(WCoinP < PShopWCPValue)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,7);
		return;
	}

	if(GoblinPoint < PShopWGPValue)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,7);
		return;
	}
#endif

	lpTarget->PShopTransaction = 1;

	BYTE result = gItemManager.InventoryInsertItem(lpObj->Index,lpTarget->Inventory[slot]);

	if(result == 0xFF)
	{
		gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,0,8);
		return;
	}

#ifdef CUSTOM_GAMESERVER_GRING
	gLog.Output(LOG_TRADE,"[SellPesonalShopItem][%s][%s] - (Account: %s, Name: %s, Value: %d, WGPValue: %d, Index: %04d, Level: %02d, Serial: %08X, Option1: %01d, Option2: %01d, Option3: %01d, NewOption: %03d, JewelOfHarmonyOption: %03d, ItemOptionEx: %03d, SocketOption: %03d, %03d, %03d, %03d, %03d)",lpTarget->Account,lpTarget->Name,lpObj->Account,0,PShopWGPValue,lpTarget->Inventory[slot].m_Index,lpTarget->Inventory[slot].m_Level,lpTarget->Inventory[slot].m_Serial,lpTarget->Inventory[slot].m_Option1,lpTarget->Inventory[slot].m_Option2,lpTarget->Inventory[slot].m_Option3,lpTarget->Inventory[slot].m_NewOption,lpTarget->Inventory[slot].m_JewelOfHarmonyOption,lpTarget->Inventory[slot].m_ItemOptionEx,lpTarget->Inventory[slot].m_SocketOption[0],lpTarget->Inventory[slot].m_SocketOption[1],lpTarget->Inventory[slot].m_SocketOption[2],lpTarget->Inventory[slot].m_SocketOption[3],lpTarget->Inventory[slot].m_SocketOption[4]);
#else
	gLog.Output(LOG_TRADE, "[SellPesonalShopItem][%s][%s] - (Account: %s, Name: %s, Value: %d, WCCValue: %d, WCPValue: %d, WGPValue: %d, Index: %04d, Level: %02d, Serial: %08X, Option1: %01d, Option2: %01d, Option3: %01d, NewOption: %03d, JewelOfHarmonyOption: %03d, ItemOptionEx: %03d, SocketOption: %03d, %03d, %03d, %03d, %03d)", lpTarget->Account, lpTarget->Name, lpObj->Account, 0, PShopWCCValue, PShopWCPValue, PShopWGPValue, lpTarget->Inventory[slot].m_Index, lpTarget->Inventory[slot].m_Level, lpTarget->Inventory[slot].m_Serial, lpTarget->Inventory[slot].m_Option1, lpTarget->Inventory[slot].m_Option2, lpTarget->Inventory[slot].m_Option3, lpTarget->Inventory[slot].m_NewOption, lpTarget->Inventory[slot].m_JewelOfHarmonyOption, lpTarget->Inventory[slot].m_ItemOptionEx, lpTarget->Inventory[slot].m_SocketOption[0], lpTarget->Inventory[slot].m_SocketOption[1], lpTarget->Inventory[slot].m_SocketOption[2], lpTarget->Inventory[slot].m_SocketOption[3], lpTarget->Inventory[slot].m_SocketOption[4]);
#endif

	#if(GAMESERVER_UPDATE>=501)

	gCashShop.GDCashShopSubPointSaveSend(lpObj->Index,0,PShopWCCValue,PShopWCPValue,PShopWGPValue);

	#else

	gPcPoint.GDPcPointSubPointSaveSend(lpObj->Index,PShopWGPValue);

	gPcPoint.GDPcPointPointSend(lpObj->Index);

	#endif

	gPersonalShop.GCPShopBuyItemSend(lpObj->Index,lpTarget->Index,result,1);

	GDCharacterInfoSaveSend(lpObj->Index);

	#if(GAMESERVER_UPDATE>=501)

	gCashShop.GDCashShopAddPointSaveSend(lpTarget->Index,0,PShopWCCValue,PShopWCPValue,PShopWGPValue);

	#else

#ifdef CUSTOM_GAMESERVER_GRING
	int commission = (PShopWGPValue * 1) / 100;

	gPcPoint.GDPcPointAddPointSaveSend(lpTarget->Index,PShopWGPValue - commission);

#else
	gPcPoint.GDPcPointAddPointSaveSend(lpTarget->Index, PShopWGPValue);
#endif

	gPcPoint.GDPcPointPointSend(lpTarget->Index);

	#endif

	gPersonalShop.GCPShopSellItemSend(lpTarget->Index,lpObj->Index,slot);

	gItemManager.InventoryDelItem(lpTarget->Index,(BYTE)slot);
	gItemManager.GCItemDeleteSend(lpTarget->Index,(BYTE)slot,1);

	GDCharacterInfoSaveSend(lpTarget->Index);

#ifdef CUSTOM_GAMESERVER
	gCustomStore.SendDeleteItemOffTrade(lpObj, slot);
#endif

	if(gPersonalShop.CheckPersonalShop(lpTarget->Index) == 0)
	{
		lpTarget->PShopItemChange = 1;
	}
	else
	{
		lpTarget->PShopOpen = 0;
		memset(lpTarget->PShopText,0,sizeof(lpTarget->PShopText));
		gPersonalShop.GCPShopCloseSend(lpTarget->Index,1);
		gCustomStore.OnPShopClose(lpTarget);
	}

	lpTarget->PShopTransaction = 0;
}

#ifdef CUSTOM_GAMESERVER
void CCustomStore::SendOfflineTrade(LPOBJ lpObj)
{
	for (int n = INVENTORY_MAIN_SIZE; n < INVENTORY_SIZE; n++)
	{
		if (lpObj->Inventory[n].IsItem() != 0) {
			PMSG_OFF_TRADE_ITEM_SAVE_SEND pMsg;

			pMsg.header.set(0x0C, 0x50, sizeof(pMsg));

			strcpy(pMsg.account, lpObj->Account);

			strcpy(pMsg.name, lpObj->Name);

			pMsg.value = lpObj->Inventory[n].m_PShopValue;

			pMsg.coin = lpObj->PShopCustomType;

			pMsg.map = lpObj->Map;

			pMsg.x = lpObj->X;

			pMsg.y = lpObj->Y;

			gItemManager.DBItemByteConvert(pMsg.item, &lpObj->Inventory[n]);

			gDataServerConnection.DataSend((BYTE*)&pMsg, pMsg.header.size);
		}
	}
}

void CCustomStore::SendDeleteItemOffTrade(LPOBJ lpObj, BYTE slot)
{
	PMSG_OFF_TRADE_DELETE_ITEM_SEND pMsg;

	pMsg.header.set(0x0C, 0x51, sizeof(pMsg));

	strcpy(pMsg.account, lpObj->Account);

	strcpy(pMsg.name, lpObj->Name);

	pMsg.slot = slot;

	gDataServerConnection.DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CCustomStore::SendDeleteAllItemOffTrade(LPOBJ lpObj)
{
	PMSG_OFF_TRADE_DELETE_ALL_ITEM_SEND pMsg;

	pMsg.header.set(0x0C, 0x52, sizeof(pMsg));

	strcpy(pMsg.account, lpObj->Account);

	strcpy(pMsg.name, lpObj->Name);

	gDataServerConnection.DataSend((BYTE*)&pMsg, pMsg.header.size);
}
#endif