#pragma once

#include "Protocol.h"

struct PMSG_SEND_TRAP
{
	PSBMSG_HEAD header;
	WORD wUserIndex;
	time_t CurrTime;
};

class Traps {
public:
	Traps();
	~Traps();

	void SendCheck(int aIndex);
};

extern Traps gTraps;