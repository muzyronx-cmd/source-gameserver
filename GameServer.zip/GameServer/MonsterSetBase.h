// MonsterSetBase.h: interface for the CMonsterSetBase class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "Map.h"

#define MAX_MSB_MONSTER 12000

struct MONSTER_SET_BASE_INFO
{
	int Type;
	int MonsterClass;
	int Map;
	int Dis;
	int X;
	int Y;
	int Dir;
	int TX;
	int TY;
	int Value;
};

class CMonsterSetBase
{
public:
	CMonsterSetBase();
	virtual ~CMonsterSetBase();
	void Clear();
	void ClearMap(int map);
	void Load();
	void Reload(int map);
	void Load(char* path, int checkMap);
	void SetInfo(MONSTER_SET_BASE_INFO info, int map);
	bool GetPosition(int index,short map,short* ox,short* oy);
	bool GetBoxPosition(int map,int x,int y,int tx,int ty,short* ox,short* oy);
	void SetBoxPosition(int index,int map,int x,int y,int tx,int ty);

public:
	int m_count[MAX_MAP];
	int m_total_count;

	std::map<int, MONSTER_SET_BASE_INFO> m_MonsterSetBaseInfo[MAX_MAP];
};

extern CMonsterSetBase gMonsterSetBase;
