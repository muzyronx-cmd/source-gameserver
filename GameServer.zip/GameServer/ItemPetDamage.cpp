#include "stdafx.h"
#include "ItemPetDamage.h"
#include "MemScript.h"
#include "Util.h"

CItemPetDamage gItemPetDamage;

CItemPetDamage::CItemPetDamage()
{
	this->m_CItemPetDamage.clear();
}

CItemPetDamage::~CItemPetDamage()
{
}

void CItemPetDamage::Load(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_CItemPetDamage.clear();

	int n = 0;

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			ITEM_PET_INFOS info;

			info.Index = lpMemScript->GetNumber();

			info.Target = lpMemScript->GetAsNumber();

			info.Damage = lpMemScript->GetAsNumber();

			info.Level = lpMemScript->GetAsNumber();

			this->m_CItemPetDamage.insert(std::pair<int, ITEM_PET_INFOS>(n, info));

			n++;
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void CItemPetDamage::SetDamage(LPOBJ lpObj, LPOBJ lpTarget, int * damage)
{
	try
	{
		if (lpObj->Type != OBJECT_USER || lpTarget->Type != OBJECT_USER)
		{
			return;
		}

		CItem* lpItem = &lpObj->Inventory[8];

		CItem* lpTargetItem = &lpTarget->Inventory[8];

		if (lpItem->IsItem() == 0 && lpTargetItem->IsItem() == 0)
		{
			return;
		}

		for (std::map<int, ITEM_PET_INFOS>::iterator it = this->m_CItemPetDamage.begin(); it != this->m_CItemPetDamage.end(); it++)
		{
			if ((lpItem->IsItem() == 1 && lpItem->m_Index == it->second.Index) && (lpTargetItem->IsItem() == 1 && lpTargetItem->m_Index == it->second.Target))
			{
				if ((it->second.Level == -1 || lpItem->m_Level == it->second.Level))
				{
					if (it->second.Damage > 0)
					{
						(*damage) = ((*damage)*(100 + it->second.Damage)) / 100;
					}
				}

				break;
			}
			else if ((lpItem->IsItem() == 0 && it->second.Index == -1) && (lpTargetItem->IsItem() == 1 && lpTargetItem->m_Index == it->second.Target))
			{
				if ((it->second.Level == -1 || lpItem->m_Level == it->second.Level))
				{
					if (it->second.Damage > 0)
					{
						(*damage) = ((*damage)*(100 + it->second.Damage)) / 100;
					}
				}

				break;
			}
			else if ((lpItem->IsItem() == 1 && lpItem->m_Index == it->second.Index) && (lpTargetItem->IsItem() == 0 && it->second.Target == -1))
			{
				if ((it->second.Level == -1 || lpItem->m_Level == it->second.Level))
				{
					if (it->second.Damage > 0)
					{
						(*damage) = ((*damage)*(100 + it->second.Damage)) / 100;
					}
				}

				break;
			}
		}
	}
	catch (...)
	{
		LogAdd(LOG_RED, "[ItemPetDamage::SetDamage] Error");
	}
}
