// CommandManager.h: interface for the CCommandManager class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "Protocol.h"
#include "User.h"

#define MAX_COMMAND 32

enum eCommandNumber
{
	COMMAND_MOVE = 1,
	COMMAND_GUILD_WAR = 24,
	COMMAND_BATTLE_SOCCER = 25,
	COMMAND_REQUEST = 26,
	COMMAND_CUSTOM_STORE = 27,
	COMMAND_CUSTOM_STORE_OFFLINE = 28,
	COMMAND_HIDE = 29,
	COMMAND_CUSTOM_ATTACK = 30,
	COMMAND_CUSTOM_ATTACK_OFFLINE = 31,

	COMMAND_TRADEX = 32,
};

//**********************************************//
//**********************************************//
//**********************************************//

struct COMMAND_INFO
{
	int code;
	char label[32];
};

class CCommandManager
{
public:
	CCommandManager();
	virtual ~CCommandManager();
	void Init();
	void MainProc();
	void Add(char* label,int code);
	long GetNumber(char* arg,int pos);
	void GetString(char* arg,char* out,int size,int pos);
	char* GetFullString(char* arg);
	long GetCommandCode(char* label);
	bool ManagementCore(LPOBJ lpObj,char* message);
	void CommandMove(LPOBJ lpObj,char* arg);
	void CommandGuildWar(LPOBJ lpObj,char* arg);
	void CommandBattleSoccer(LPOBJ lpObj,char* arg);
	void CommandRequest(LPOBJ lpObj,char* arg);
	void CommandHide(LPOBJ lpObj,char* arg);
	void CommandTradeX(LPOBJ lpObj, char* arg);
	void CommandAddPointAuto(LPOBJ lpObj, int amount, int type);
	void CommandAddPointAutoProc(LPOBJ lpObj);

private:
	COMMAND_INFO m_CommandInfo[MAX_COMMAND];
};

extern CCommandManager gCommandManager;
