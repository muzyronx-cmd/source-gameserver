#include "stdafx.h"
#include "ItemDuration.h"
#include "User.h"
#include "Util.h"
#include "GameMain.h"
#include "DSProtocol.h"
#include "ItemManager.h"
#include "Warehouse.h"
#include "Notice.h"

#if (GAMESERVER_UPDATE==201)
ItemDuration gItemDuration;

ItemDuration::ItemDuration()
{
}

ItemDuration::~ItemDuration()
{
}

/*time_t rawtime = (time_t)lpObj->Inventory[i].m_PeriodicItemTime;

struct tm * dt;
char buffer[30];
dt = localtime(&rawtime);
strftime(buffer, sizeof(buffer), "%Y-%m-%d  %H:%M:%S", dt);

Console.LogConsole(LIGHTGREEN, "Tempo: %s", buffer);*/

void ItemDuration::MainProc()
{
	for (int n = OBJECT_START_USER; n < MAX_OBJECT; n++)
	{
		if (gObjIsConnectedGP(n) == 0)
		{
			continue;
		}

		LPOBJ lpObj = &gObj[n];

		for (int i = 0; i < INVENTORY_SIZE; i++)
		{
			if (lpObj->Inventory[i].IsItem() == 0)
			{
				continue;
			}

			if (lpObj->Inventory[i].m_IsPeriodicItem != 1)
			{
				continue;
			}

			if (lpObj->Inventory[i].m_LoadPeriodicItem == 0)
			{
				continue;
			}

			if (lpObj->Inventory[i].m_PeriodicItemTime <= ((DWORD)time(0)))
			{
				//gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "[Sistema] %s expirou!", lpObj->Inventory[i].GetName());

				//LogAdd(LOG_BLACK, "%s, Slot: %d Time: %d - %d", lpObj->Inventory[i].GetName(), i, lpObj->Inventory[i].m_PeriodicItemTime, ((int)time(0)));

				//if (lpObj->Inventory[i].m_IsPeriodicItem != (BYTE)2)
				{
					char msg[256] = { 0 };
					wsprintf(msg, "[Sistema] %s expirou!", lpObj->Inventory[i].GetName());
					gNotice.GCNoticeSend(n, 1, 0, 0, 0, 0, 0, msg);

					this->DGPeriodicItemDelSend(lpObj->Inventory[i].m_Serial);
					gItemManager.InventoryDelItem(lpObj->Index, i);
					gItemManager.GCItemDeleteSend(lpObj->Index, i, 0);
					gItemManager.GCItemChangeSend(lpObj->Index, i);
				}
			}
		}

		if (lpObj->Interface.type == 6)
		{
			bool ExpiredItem = 0;

			for (int i = 0; i < WAREHOUSE_SIZE; i++)
			{
				if (lpObj->Warehouse[i].IsItem() == 0)
				{
					continue;
				}

				if (lpObj->Warehouse[i].m_IsPeriodicItem != 1)
				{
					continue;
				}

				if (lpObj->Warehouse[i].m_LoadPeriodicItem == 0)
				{
					continue;
				}

				if (lpObj->Warehouse[i].m_PeriodicItemTime <= ((DWORD)time(0)))
				{
					//if (lpObj->Warehouse[i].m_IsPeriodicItem != (BYTE)2)
					{
						char msg[256] = { 0 };
						wsprintf(msg, "[Sistema] %s expirou!", lpObj->Warehouse[i].GetName());

						gNotice.GCNoticeSend(n, 1, 0, 0, 0, 0, 0, msg);

						this->DGPeriodicItemDelSend(lpObj->Warehouse[i].m_Serial);
						gItemManager.WarehouseDelItem(lpObj->Index, i);
						ExpiredItem = true;
					}
				}
			}

			if (ExpiredItem)
			{
				gWarehouse.GCWarehouseListSend(lpObj);
				gWarehouse.GCWarehouseStateSend(lpObj->Index, ((lpObj->WarehousePW>0) ? ((lpObj->WarehouseLock == 0) ? 12 : 1) : 0));
			}
		}
	}
}

void ItemDuration::SendInformationMain(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	BYTE send[4096];
	PMSG_PERIODIC_ITEM_SEND pMsg;
	int size = sizeof(pMsg);

	pMsg.h.set(0xFB, 0x2B, sizeof(pMsg));
	pMsg.count = 0;
	pMsg.Type = 0;

	PMSG_PERIODIC_ITEM info;

	for (int i = 0; i < INVENTORY_SIZE; i++)
	{
		if (lpObj->Inventory[i].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->Inventory[i].m_IsPeriodicItem != 1)
		{
			continue;
		}

		if (lpObj->Inventory[i].m_LoadPeriodicItem == 0)
		{
			continue;
		}

		info.ItemIndex = lpObj->Inventory[i].m_Index;
		info.Slot = i;
		info.Timer = lpObj->Inventory[i].m_PeriodicItemTime;
		info.Type = lpObj->Inventory[i].m_IsPeriodicItem;
		info.TickCount = (DWORD)time(0);

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);
		pMsg.count++;
	}

	if (pMsg.count > 0)
	{
		pMsg.h.size[0] = SET_NUMBERHB(size);
		pMsg.h.size[1] = SET_NUMBERLB(size);
		memcpy(send, &pMsg, sizeof(pMsg));
		DataSend(lpObj->Index, send, size);
	}

	if (lpObj->Interface.type == 6)
	{
		BYTE sendware[4096];
		PMSG_PERIODIC_ITEM_SEND lpMsg;
		int size = sizeof(lpMsg);

		lpMsg.h.set(0xFB, 0x2B, sizeof(lpMsg));
		lpMsg.count = 0;
		lpMsg.Type = 1;

		PMSG_PERIODIC_ITEM ware_info;

		for (int i = 0; i < WAREHOUSE_SIZE; i++)
		{
			if (lpObj->Warehouse[i].IsItem() == 0)
			{
				continue;
			}

			if (lpObj->Warehouse[i].m_IsPeriodicItem != 1)
			{
				continue;
			}

			if (lpObj->Warehouse[i].m_LoadPeriodicItem == 0)
			{
				continue;
			}

			ware_info.ItemIndex = lpObj->Warehouse[i].m_Index;
			ware_info.Slot = i;
			ware_info.Timer = lpObj->Warehouse[i].m_PeriodicItemTime;
			ware_info.Type = lpObj->Warehouse[i].m_IsPeriodicItem;
			ware_info.TickCount = (DWORD)time(0);

			memcpy(&sendware[size], &ware_info, sizeof(ware_info));
			size += sizeof(ware_info);
			lpMsg.count++;
		}

		if (lpMsg.count > 0)
		{
			lpMsg.h.size[0] = SET_NUMBERHB(size);
			lpMsg.h.size[1] = SET_NUMBERLB(size);
			memcpy(sendware, &lpMsg, sizeof(lpMsg));
			DataSend(lpObj->Index, sendware, size);
		}
	}
}

void ItemDuration::DGPeriodicItemSend(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	BYTE send[4096];

	SDHP_PERIODIC_ITEM_SEND pMsg;

	pMsg.header.set(0x18, 0x05, 0);

	int size = sizeof(pMsg);

	pMsg.index = aIndex;

	memcpy(pMsg.account, lpObj->Account, sizeof(pMsg.account));

	pMsg.count = 0;

	SDHP_PERIODIC_ITEM2 info;

	for (int n = 0; n < INVENTORY_SIZE; n++)
	{
		if (lpObj->Inventory[n].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->Inventory[n].m_IsPeriodicItem != 1)
		{
			continue;
		}

		info.slot = n;

		info.serial = lpObj->Inventory[n].m_Serial;

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	if (pMsg.count > 0)
	{
		pMsg.header.size[0] = SET_NUMBERHB(size);
		pMsg.header.size[1] = SET_NUMBERLB(size);

		memcpy(send, &pMsg, sizeof(pMsg));

		gDataServerConnection.DataSend(send, size);
	}
}

void ItemDuration::DGPeriodicWarehouseItemSend(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	BYTE send[4096];

	SDHP_PERIODIC_ITEM_SEND pMsg;

	pMsg.header.set(0x18, 0x06, 0);

	int size = sizeof(pMsg);

	pMsg.index = aIndex;

	memcpy(pMsg.account, lpObj->Account, sizeof(pMsg.account));

	pMsg.count = 0;

	SDHP_PERIODIC_ITEM2 info;

	for (int n = 0; n < WAREHOUSE_SIZE; n++)
	{
		if (lpObj->Warehouse[n].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->Warehouse[n].m_IsPeriodicItem != (BYTE)1 && lpObj->Warehouse[n].m_IsPeriodicItem != (BYTE)2)
		{
			continue;
		}

		info.slot = n;

		info.serial = lpObj->Warehouse[n].m_Serial;

		//Console.LogConsole(LIGHTRED, "Item Send: Slot: %d Serial: %d", info.slot, info.serial);

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	if (pMsg.count > 0)
	{
		pMsg.header.size[0] = SET_NUMBERHB(size);
		pMsg.header.size[1] = SET_NUMBERLB(size);

		memcpy(send, &pMsg, sizeof(pMsg));

		gDataServerConnection.DataSend(send, size);
	}
}

void ItemDuration::DGPeriodicItemRecv(SDHP_PERIODIC_ITEM_RECV * lpMsg)
{
	LPOBJ lpObj = &gObj[lpMsg->index];

	for (int n = 0; n < lpMsg->count; n++)
	{
		SDHP_PERIODIC_ITEM1* lpInfo = (SDHP_PERIODIC_ITEM1*)(((BYTE*)lpMsg) + sizeof(SDHP_PERIODIC_ITEM_RECV) + (sizeof(SDHP_PERIODIC_ITEM1)*n));

		if (INVENTORY_RANGE(lpInfo->slot) == 0)
		{
			continue;
		}

		if (lpObj->Inventory[lpInfo->slot].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->Inventory[lpInfo->slot].m_Serial != lpInfo->serial)
		{
			continue;
		}

		if (lpObj->Inventory[lpInfo->slot].m_IsPeriodicItem != 1)
		{
			continue;
		}

		if (lpObj->Inventory[lpInfo->slot].m_LoadPeriodicItem != 0)
		{
			continue;
		}

		lpObj->Inventory[lpInfo->slot].m_LoadPeriodicItem = 1;

		lpObj->Inventory[lpInfo->slot].m_PeriodicItemTime = lpInfo->time;
	}
}

void ItemDuration::DGPeriodicWarehouseItemRecv(SDHP_PERIODIC_ITEM_RECV* lpMsg)
{
	LPOBJ lpObj = &gObj[lpMsg->index];

	for (int n = 0; n < lpMsg->count; n++)
	{
		SDHP_PERIODIC_ITEM1* lpInfo = (SDHP_PERIODIC_ITEM1*)(((BYTE*)lpMsg) + sizeof(SDHP_PERIODIC_ITEM_RECV) + (sizeof(SDHP_PERIODIC_ITEM1)*n));

		if (INVENTORY_RANGE(lpInfo->slot) == 0)
		{
			continue;
		}

		if (lpObj->Warehouse[lpInfo->slot].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->Warehouse[lpInfo->slot].m_Serial != lpInfo->serial)
		{
			continue;
		}

		if (lpObj->Warehouse[lpInfo->slot].m_IsPeriodicItem != 1)
		{
			continue;
		}

		if (lpObj->Warehouse[lpInfo->slot].m_LoadPeriodicItem != 0)
		{
			continue;
		}

		lpObj->Warehouse[lpInfo->slot].m_LoadPeriodicItem = 1;

		lpObj->Warehouse[lpInfo->slot].m_PeriodicItemTime = lpInfo->time;
	}
}

void ItemDuration::PickUpItemSend(LPOBJ lpObj)
{
	SDHP_PERIODIC_PICK_UP_SEND pMsg;

	pMsg.header.set(0x18, 0x04, sizeof(pMsg));

	pMsg.index = lpObj->Index;

	memcpy(pMsg.account, lpObj->Account, sizeof(pMsg.account));

	gDataServerConnection.DataSend((BYTE*)&pMsg, pMsg.header.size);
}

bool ItemDuration::DGPeriodicItemDelSend(DWORD Serial)
{
	SDHP_PERIODIC_ITEM_DEL_SEND pMsg;

	pMsg.header.set(0x18, 0x03, sizeof(pMsg));

	pMsg.Serial = Serial;

	gDataServerConnection.DataSend((BYTE*)&pMsg, pMsg.header.size);

	return 1;
}

void ItemDuration::DGPeriodicItemTimeSaveSend(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	BYTE send[4096];

	SDHP_PERIODIC_ITEM_SAVE_SEND pMsg;

	pMsg.header.set(0x18, 0x34, 0);

	int size = sizeof(pMsg);

	pMsg.index = aIndex;

	memcpy(pMsg.account, lpObj->Account, sizeof(pMsg.account));

	pMsg.count = 0;

	SDHP_PERIODIC_ITEM_SAVE info;

	for (int n = 0; n < INVENTORY_SIZE; n++)
	{
		if (lpObj->Inventory[n].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->Inventory[n].m_IsPeriodicItem != 1)
		{
			continue;
		}

		if (lpObj->Inventory[n].m_LoadPeriodicItem == 0)
		{
			continue;
		}

		info.serial = lpObj->Inventory[n].m_Serial;

		info.time = lpObj->Inventory[n].m_PeriodicItemTime;

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	if (pMsg.count > 0)
	{
		pMsg.header.size[0] = SET_NUMBERHB(size);
		pMsg.header.size[1] = SET_NUMBERLB(size);

		memcpy(send, &pMsg, sizeof(pMsg));

		gDataServerConnection.DataSend(send, size);
	}
}

void ItemDuration::DGPeriodicItemTimeSaveCMSend(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	BYTE send[4096];

	SDHP_PERIODIC_ITEM_SAVE_SEND pMsg;

	pMsg.header.set(0x18, 0x34, 0);

	int size = sizeof(pMsg);

	pMsg.index = aIndex;

	memcpy(pMsg.account, lpObj->Account, sizeof(pMsg.account));

	pMsg.count = 0;

	SDHP_PERIODIC_ITEM_SAVE info;

	for (int n = 0; n < CHAOS_BOX_SIZE; n++)
	{
		if (lpObj->ChaosBox[n].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->ChaosBox[n].m_IsPeriodicItem != 1)
		{
			continue;
		}

		if (lpObj->ChaosBox[n].m_LoadPeriodicItem == 0)
		{
			continue;
		}

		info.serial = lpObj->ChaosBox[n].m_Serial;

		info.time = lpObj->ChaosBox[n].m_PeriodicItemTime;

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	if (pMsg.count > 0)
	{
		pMsg.header.size[0] = SET_NUMBERHB(size);
		pMsg.header.size[1] = SET_NUMBERLB(size);

		memcpy(send, &pMsg, sizeof(pMsg));

		gDataServerConnection.DataSend(send, size);
	}
}

int ItemDuration::GetNewPeriodicTimer(int Hours)
{
	int Left = Hours * 60;
	int timer = (int)(time(0) + Left);

	return timer;
}

void ItemDuration::SendInformationBySlot(LPOBJ lpObj)
{
	BYTE send[4096];
	PMSG_PERIODIC_ITEM_SEND pMsg;
	int size = sizeof(pMsg);

	pMsg.h.set(0xFB, 0x2B, sizeof(pMsg));
	pMsg.count = 0;
	pMsg.Type = 0;

	PMSG_PERIODIC_ITEM info;

	for (int i = 0; i < INVENTORY_SIZE; i++)
	{
		if (lpObj->Inventory[i].IsItem() == 0)
		{
			continue;
		}

		if (lpObj->Inventory[i].m_IsPeriodicItem != 1)
		{
			continue;
		}

		if (lpObj->Inventory[i].m_LoadPeriodicItem == 0)
		{
			continue;
		}

		info.ItemIndex = lpObj->Inventory[i].m_Index;
		info.Slot = i;
		info.Timer = lpObj->Inventory[i].m_PeriodicItemTime;
		info.Type = lpObj->Inventory[i].m_IsPeriodicItem;
		info.TickCount = (DWORD)time(0);

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);
		pMsg.count++;
	}

	//if (pMsg.count > 0)
	{
		pMsg.h.size[0] = SET_NUMBERHB(size);
		pMsg.h.size[1] = SET_NUMBERLB(size);
		memcpy(send, &pMsg, sizeof(pMsg));
		DataSend(lpObj->Index, send, size);
	}

	if (lpObj->Interface.type == 6)
	{
		BYTE sendware[4096];
		PMSG_PERIODIC_ITEM_SEND lpMsg;
		int size = sizeof(lpMsg);

		lpMsg.h.set(0xFB, 0x2B, sizeof(lpMsg));
		lpMsg.count = 0;
		lpMsg.Type = 1;

		PMSG_PERIODIC_ITEM ware_info;

		for (int i = 0; i < WAREHOUSE_SIZE; i++)
		{
			if (lpObj->Warehouse[i].IsItem() == 0)
			{
				continue;
			}

			if (lpObj->Warehouse[i].m_IsPeriodicItem != 1)
			{
				continue;
			}

			if (lpObj->Warehouse[i].m_LoadPeriodicItem == 0)
			{
				continue;
			}

			ware_info.ItemIndex = lpObj->Warehouse[i].m_Index;
			ware_info.Slot = i;
			ware_info.Timer = lpObj->Warehouse[i].m_PeriodicItemTime;
			ware_info.Type = lpObj->Warehouse[i].m_IsPeriodicItem;
			ware_info.TickCount = (DWORD)time(0);

			memcpy(&sendware[size], &ware_info, sizeof(ware_info));
			size += sizeof(ware_info);
			lpMsg.count++;
		}

		//if (lpMsg.count > 0)
		{
			lpMsg.h.size[0] = SET_NUMBERHB(size);
			lpMsg.h.size[1] = SET_NUMBERLB(size);
			memcpy(sendware, &lpMsg, sizeof(lpMsg));
			DataSend(lpObj->Index, sendware, size);
		}
	}
}
#endif