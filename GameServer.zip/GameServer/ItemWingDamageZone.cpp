#include "stdafx.h"
#include "ItemWingDamageZone.h"
#include "MemScript.h"
#include "Util.h"
#include "Protocol.h"

CItemWingDamageZone gItemWingDamageZone;

CItemWingDamageZone::CItemWingDamageZone()
{
	this->m_WingZoneInfo.clear();
}

CItemWingDamageZone::~CItemWingDamageZone()
{
}

void CItemWingDamageZone::Load(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_WingZoneInfo.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			ITEM_WING_ZONE_INFO info;

			info.Index = lpMemScript->GetNumber();

			info.Damage = lpMemScript->GetAsNumber();

			info.DamageDec = lpMemScript->GetAsNumber();

			info.Level = lpMemScript->GetAsNumber();

			info.map = lpMemScript->GetAsNumber();

			info.x1 = lpMemScript->GetAsNumber();

			info.y1 = lpMemScript->GetAsNumber();

			info.x2 = lpMemScript->GetAsNumber();

			info.y2 = lpMemScript->GetAsNumber();

			this->m_WingZoneInfo.insert(std::pair<int, ITEM_WING_ZONE_INFO>(info.Index, info));
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void CItemWingDamageZone::SetDamage(LPOBJ lpObj, LPOBJ lpTarget, int * damage)
{
	try
	{
		if (lpObj != 0 && lpObj->Type == OBJECT_USER)
		{
			CItem* lpItem = &lpObj->Inventory[7];

			if (lpItem->IsItem() != 0)
			{
				std::map<int, ITEM_WING_ZONE_INFO>::iterator it = this->m_WingZoneInfo.find(lpItem->m_Index);

				if (it != this->m_WingZoneInfo.end())
				{
					if (lpObj->Map == it->second.map && (lpObj->X >= it->second.x1 && lpObj->Y >= it->second.y1 && lpObj->X <= it->second.x2 && lpObj->Y <= it->second.y2))
					{
						if (it->second.Level == -1 || lpItem->m_Level == it->second.Level)
						{
							if (it->second.Damage > 0)
							{
								lpObj->Life -= 3;

								GCLifeSend(lpObj->Index, 0xFF, (int)lpObj->Life, 0);

								(*damage) = ((*damage)*(100 + it->second.Damage)) / 100;
							}
						}
					}
				}
			}
		}

		if (lpTarget != 0 && lpTarget->Type == OBJECT_USER)
		{
			CItem* lpTargetItem = &lpTarget->Inventory[7];

			if (lpTargetItem->IsItem() != 0)
			{
				std::map<int, ITEM_WING_ZONE_INFO>::iterator it = this->m_WingZoneInfo.find(lpTargetItem->m_Index);

				if (it != this->m_WingZoneInfo.end())
				{
					if (lpTarget->Map == it->second.map && (lpTarget->X >= it->second.x1 && lpTarget->Y >= it->second.y1 && lpTarget->X <= it->second.x2 && lpTarget->Y <= it->second.y2))
					{
						if (it->second.Level == -1 || lpTargetItem->m_Level == it->second.Level)
						{
							if (it->second.DamageDec > 0)
							{
								(*damage) = ((*damage)*(100 - it->second.DamageDec)) / 100;
							}
						}
					}
				}
			}
		}
	}
	catch (...)
	{
		LogAdd(LOG_RED, "[ItemWingDamageZone::SetDamage] Error");
	}
}
