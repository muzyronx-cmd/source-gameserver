// Protect.h: interface for the CProtect class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#define PROTECT_START _asm _emit 0xEB _asm _emit 0x0E _asm _emit 0x14 _asm _emit 0x28 _asm _emit 0xCD _asm _emit 0xDB _asm _emit 0x50 _asm _emit 0x63 _asm _emit 0xAF _asm _emit 0x22 _asm _emit 0x75 _asm _emit 0xEE _asm _emit 0xB5 _asm _emit 0xD8 _asm _emit 0x43 _asm _emit 0x72
#define PROTECT_FINAL _asm _emit 0xEB _asm _emit 0x0E _asm _emit 0x37 _asm _emit 0xF2 _asm _emit 0xCD _asm _emit 0xDB _asm _emit 0x50 _asm _emit 0x63 _asm _emit 0xAF _asm _emit 0x22 _asm _emit 0x75 _asm _emit 0xEE _asm _emit 0xB5 _asm _emit 0xD8 _asm _emit 0x85 _asm _emit 0x61
#define CRASH_APPLICATION_MACRO _asm _emit 0xFF _asm _emit 0x25 _asm _emit 0x00 _asm _emit 0x00 _asm _emit 0x00 _asm _emit 0x00

enum eAuthServerType
{
	AUTH_SERVER_TYPE_NONE = 0,

	AUTH_SERVER_TYPE_97_CONNECT_SERVER = 1,
	AUTH_SERVER_TYPE_97_JOIN_SERVER = 2,
	AUTH_SERVER_TYPE_97_DATA_SERVER = 3,
	AUTH_SERVER_TYPE_97_GAME_SERVER = 4,

	AUTH_SERVER_TYPE_99_CONNECT_SERVER = 10,
	AUTH_SERVER_TYPE_99_JOIN_SERVER = 11,
	AUTH_SERVER_TYPE_99_DATA_SERVER = 12,
	AUTH_SERVER_TYPE_99_GAME_SERVER = 13,

	AUTH_SERVER_TYPE_S1_CONNECT_SERVER = 20,
	AUTH_SERVER_TYPE_S1_JOIN_SERVER = 21,
	AUTH_SERVER_TYPE_S1_DATA_SERVER = 22,
	AUTH_SERVER_TYPE_S1_GAME_SERVER = 23,

	AUTH_SERVER_TYPE_S2_CONNECT_SERVER = 30,
	AUTH_SERVER_TYPE_S2_JOIN_SERVER = 31,
	AUTH_SERVER_TYPE_S2_DATA_SERVER = 32,
	AUTH_SERVER_TYPE_S2_GAME_SERVER = 33,

	AUTH_SERVER_TYPE_S4_CONNECT_SERVER = 40,
	AUTH_SERVER_TYPE_S4_JOIN_SERVER = 41,
	AUTH_SERVER_TYPE_S4_DATA_SERVER = 42,
	AUTH_SERVER_TYPE_S4_GAME_SERVER = 43,

	AUTH_SERVER_TYPE_S6_CONNECT_SERVER = 50,
	AUTH_SERVER_TYPE_S6_JOIN_SERVER = 51,
	AUTH_SERVER_TYPE_S6_DATA_SERVER = 52,
	AUTH_SERVER_TYPE_S6_GAME_SERVER = 53,

	AUTH_SERVER_TYPE_S8_CONNECT_SERVER = 60,
	AUTH_SERVER_TYPE_S8_JOIN_SERVER = 61,
	AUTH_SERVER_TYPE_S8_DATA_SERVER = 62,
	AUTH_SERVER_TYPE_S8_GAME_SERVER = 63,

	AUTH_SERVER_TYPE_S10_CONNECT_SERVER = 70,
	AUTH_SERVER_TYPE_S10_JOIN_SERVER = 71,
	AUTH_SERVER_TYPE_S10_DATA_SERVER = 72,
	AUTH_SERVER_TYPE_S10_GAME_SERVER = 73,
};

enum eAuthServerStatus
{
	AUTH_SERVER_STATUS_NONE = 0,
	AUTH_SERVER_STATUS_SUCCESS = 1,
};

struct SDHP_AUTH_SERVER_IV_RECV
{
	BYTE type;
	BYTE size;
	BYTE head;
	BYTE rands;
	unsigned char IV[16];
};

struct SDHP_AUTH_SERVER_DATA_RECV
{
	BYTE type;
	BYTE size[2];
	BYTE head;
	BYTE EncKey;
	char AnyKey[50];
	BYTE ServerType;
	BYTE Status;
	BYTE PackageType;
	BYTE PlanType;
	BYTE Patente;
	char CustomerName[50];
	char AnyKey02[50];
	char CustomerHardwareId[45];
	char ServerVersion[8];
	char IpAddress[17];
	char ServerName[25];
	int LicenseDays;
	BYTE DLLCustom; //Added on 1.0.1.0
	char ServerKey[10]; //Serverkey

	char BufferSign[1024];
};

struct SDHP_AUTH_SERVER_DATA_SEND
{
	BYTE type;
	BYTE size[2];
	BYTE head;
	BYTE EncKey;
	char AnyKey[50];
	BYTE ServerType;
	char CustomerName[100];
	char CustomerHardwareId[45];
	char ServerVersion[20];
};

struct SDHP_AUTH_GAMESERVER_INFO_SEND
{
	BYTE type;
	BYTE size[2];
	BYTE head;
	BYTE EncKey;
	BYTE ServerType;
	char ServerName[100];
	char GameServerName[100];
	WORD UsersOnline;
	WORD UsersBoot;
	DWORD timestamp;
};

class CProtect
{
public:
	CProtect();
	virtual ~CProtect();
	bool GetComputerHardwareId();
	bool ConnectToAuthServer(char* IpAddress, WORD port);
	bool AuthServerDataSend(eAuthServerType ServerType);
	void StartAuthGS(eAuthServerType ServerType, bool checktimer = false);
	inline void ErrorMessageBox();
	static inline DWORD WINAPI GameServerTheread(LPVOID lpParam);
	inline void SafeExitProcess();
	void SetDisconnectRand();
	void SendDLLCustom(int aIndex);
	char* GetEncryptedString(BYTE* string, int size);
	char* GetDecryptedString(char* string, int size);
	char * GetIpAddress();
	char * GetPrivateIpAddress();
	char * GetServerName();
	char * GetHWID();
	char * GetServerKey();
	int GetServerType();
	char * GetLicenseType();
	char * GetDays();
	char * GetLicenseMethod();
	int GetMaxWings();
	int GetMaxPets();
	int GetPatente();
	int GetMaxElementSlot();
	void CheckLicenseDays();
	int GetDLLCustom();

	void runThread();

public:
	SOCKET m_socket;
	char m_ComputerHardwareId[45];
	char m_HDWID[45];
	char m_IpAddress[17];
	char m_PrivateIpAddress[17];
	char m_ServerName[50];
	int m_ServerType;
	int m_ServerLicense;
	int m_ServerDays;
	int m_Customs;
	int m_CustomsKey[25];
	int m_DisconnectRand;
	BYTE m_HavePatente;
	BYTE m_EncKey;
	BYTE m_DLLCustom;
	char m_ServerKey[20];
	int m_CheckCount;
	SDHP_AUTH_SERVER_DATA_RECV m_AuthInfo;
	SDHP_AUTH_SERVER_IV_RECV m_AuthIvRecv;

	DWORD m_TimeThread;

	unsigned char PrivateIV[16];

	int SuccessLicense;

	std::thread licenseThread;
};

extern CProtect gProtect;

static BYTE EncDecKey1[5] = { 0x57, 0xE9, 0x22, 0xFA, 0xB8 };
static BYTE EncDecKey2[5] = { 0x94, 0xC7, 0x84, 0xAB, 0x5C };
static BYTE EncDecKeyProtect1[5] = { 0x41, 0x54, 0x46, 0x48, 0x57 };
static BYTE EncDecKeyProtect2[5] = { 0x4E, 0x2D, 0x58, 0x31, 0x59 };
static BYTE gProtectString1[04] = { 0x80,0xE8,0xC2,0x51 }; //"C:\\"
static BYTE gProtectString2[25] = { 0xEE,0x1E,0x9E,0xF9,0x31,0xEE,0x1E,0x9E,0xF9,0x31,0xEE,0x1E,0x9E,0xF9,0x31,0xEE,0x1E,0x9E,0xF9,0x31,0xEE,0x1E,0x9E,0xF9,0xE4 }; //"%08X-%08X-%08X-%08X-%08X"
static BYTE gProtectString3[18] = { 0xA0,0xDF,0xD0,0xE3,0x79,0xA0,0xD2,0x90,0xE0,0x7B,0x54,0xC3,0xDE,0x23,0x07,0x54,0xDD,0xA6 }; //"connect.ogocx.com"