// CustomAttack.cpp: implementation of the CCustomAttack class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CustomAttack.h"
#include "ItemManager.h"
#include "Map.h"
#include "MasterSkillTree.h"
#include "Notice.h"
#include "SkillManager.h"
#include "SocketManager.h"
#include "Message.h"
#include "Util.h"
#include "Viewport.h"

CCustomAttack gCustomAttack;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomAttack::CCustomAttack() // OK
{

}

CCustomAttack::~CCustomAttack() // OK
{

}

void CCustomAttack::ReadCustomAttackInfo(char* section,char* path) // OK
{
	this->m_CustomAttackSwitch = GetPrivateProfileInt(section,"CustomAttackSwitch",0,path);

	this->m_CustomAttackEnable[0] = GetPrivateProfileInt(section,"CustomAttackEnable_FREE",0,path);

	this->m_CustomAttackEnable[1] = GetPrivateProfileInt(section,"CustomAttackEnable_VIP1",0,path);

	this->m_CustomAttackEnable[2] = GetPrivateProfileInt(section,"CustomAttackEnable_VIP2",0,path);

	this->m_CustomAttackEnable[3] = GetPrivateProfileInt(section,"CustomAttackEnable_VIP3",0,path);

	this->m_CustomAttackTime[0] = GetPrivateProfileInt(section, "CustomAttackRunningTime_FREE", 0, path);

	this->m_CustomAttackTime[1] = GetPrivateProfileInt(section, "CustomAttackRunningTime_VIP1", 0, path);

	this->m_CustomAttackTime[2] = GetPrivateProfileInt(section, "CustomAttackRunningTime_VIP2", 0, path);

	this->m_CustomAttackTime[3] = GetPrivateProfileInt(section, "CustomAttackRunningTime_VIP3", 0, path);

	this->m_CustomAttackRequireLevel[0] = GetPrivateProfileInt(section,"CustomAttackRequireLevel_FREE",0,path);

	this->m_CustomAttackRequireLevel[1] = GetPrivateProfileInt(section,"CustomAttackRequireLevel_VIP1",0,path);

	this->m_CustomAttackRequireLevel[2] = GetPrivateProfileInt(section,"CustomAttackRequireLevel_VIP2",0,path);

	this->m_CustomAttackRequireLevel[3] = GetPrivateProfileInt(section,"CustomAttackRequireLevel_VIP3",0,path);

	this->m_CustomAttackRequireReset[0] = GetPrivateProfileInt(section,"CustomAttackRequireReset_FREE",0,path);

	this->m_CustomAttackRequireReset[1] = GetPrivateProfileInt(section,"CustomAttackRequireReset_VIP1",0,path);

	this->m_CustomAttackRequireReset[2] = GetPrivateProfileInt(section,"CustomAttackRequireReset_VIP2",0,path);

	this->m_CustomAttackRequireReset[3] = GetPrivateProfileInt(section,"CustomAttackRequireReset_VIP3",0,path);

	GetPrivateProfileString(section,"CustomAttackCommandSyntax","",this->m_CustomAttackCommandSyntax,sizeof(this->m_CustomAttackCommandSyntax),path);

	this->m_CustomAttackOfflineSwitch = GetPrivateProfileInt(section,"CustomAttackOfflineSwitch",0,path);

	this->m_CustomAttackOfflineGPGain = GetPrivateProfileInt(section,"CustomAttackOfflineGPGain",0,path);

	this->m_CustomAttackOfflineEnable[0] = GetPrivateProfileInt(section,"CustomAttackOfflineEnable_FREE",0,path);

	this->m_CustomAttackOfflineEnable[1] = GetPrivateProfileInt(section,"CustomAttackOfflineEnable_VIP1",0,path);

	this->m_CustomAttackOfflineEnable[2] = GetPrivateProfileInt(section,"CustomAttackOfflineEnable_VIP2",0,path);

	this->m_CustomAttackOfflineEnable[3] = GetPrivateProfileInt(section,"CustomAttackOfflineEnable_VIP3",0,path);

	this->m_CustomAttackOfflineRequireLevel[0] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireLevel_FREE",0,path);

	this->m_CustomAttackOfflineRequireLevel[1] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireLevel_VIP1",0,path);

	this->m_CustomAttackOfflineRequireLevel[2] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireLevel_VIP2",0,path);

	this->m_CustomAttackOfflineRequireLevel[3] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireLevel_VIP3",0,path);

	this->m_CustomAttackOfflineRequireReset[0] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireReset_FREE",0,path);

	this->m_CustomAttackOfflineRequireReset[1] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireReset_VIP1",0,path);

	this->m_CustomAttackOfflineRequireReset[2] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireReset_VIP2",0,path);

	this->m_CustomAttackOfflineRequireReset[3] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireReset_VIP3",0,path);

	this->m_CustomAttackOfflineRequireMoney[0] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireMoney_FREE",0,path);

	this->m_CustomAttackOfflineRequireMoney[1] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireMoney_VIP1",0,path);

	this->m_CustomAttackOfflineRequireMoney[2] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireMoney_VIP2",0,path);

	this->m_CustomAttackOfflineRequireMoney[3] = GetPrivateProfileInt(section,"CustomAttackOfflineRequireMoney_VIP3",0,path);

	this->m_CustomAttackDelaySpeed[CLASS_DW] = GetPrivateProfileInt(section, "CustomAttackDelaySpeed_DW", 1500, path);

	this->m_CustomAttackDelaySpeed[CLASS_DK] = GetPrivateProfileInt(section, "CustomAttackDelaySpeed_DK", 1500, path);

	this->m_CustomAttackDelaySpeed[CLASS_FE] = GetPrivateProfileInt(section, "CustomAttackDelaySpeed_FE", 1500, path);

	this->m_CustomAttackDelaySpeed[CLASS_MG] = GetPrivateProfileInt(section, "CustomAttackDelaySpeed_MG", 1500, path);

	this->m_CustomAttackDelaySpeed[CLASS_DL] = GetPrivateProfileInt(section, "CustomAttackDelaySpeed_DL", 1500, path);

#if (GAMESERVER_UPDATE >= 601)
	this->m_CustomAttackDelaySpeed[CLASS_SU] = GetPrivateProfileInt(section, "CustomAttackDelaySpeed_SU", 1500, path);

	this->m_CustomAttackDelaySpeed[CLASS_RF] = GetPrivateProfileInt(section, "CustomAttackDelaySpeed_RF", 1500, path);
#endif

	GetPrivateProfileString(section,"CustomAttackOfflineCommandSyntax","",this->m_CustomAttackOfflineCommandSyntax,sizeof(this->m_CustomAttackOfflineCommandSyntax),path);

}

void CCustomAttack::CommandCustomAttack(LPOBJ lpObj,char* arg) // OK
{
	if(this->m_CustomAttackSwitch == 0)
	{
		return;
	}

	if (lpObj->TradeDuel != 0)
	{
		return;
	}

	if(this->m_CustomAttackEnable[lpObj->AccountLevel] == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0,gMessage.GetMessage(lpObj->m_Language, 800));
		return;
	}

	if(((gMasterSkillTree.CheckMasterLevel(lpObj)==0)?lpObj->Level:(lpObj->Level+lpObj->MasterLevel)) < this->m_CustomAttackRequireLevel[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 801),this->m_CustomAttackRequireLevel[lpObj->AccountLevel]);
		return;
	}

	if(lpObj->Reset < this->m_CustomAttackRequireReset[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 802),this->m_CustomAttackRequireReset[lpObj->AccountLevel]);
		return;
	}

	if(lpObj->AttackCustom != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 803));
		return;
	}

	if(gMap[lpObj->Map].CheckAttr(lpObj->X,lpObj->Y,1) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 804));
		return;
	}

	if(CA_MAP_RANGE(lpObj->Map) != 0 || DS_MAP_RANGE(lpObj->Map) != 0 || BC_MAP_RANGE(lpObj->Map) != 0 || CC_MAP_RANGE(lpObj->Map) != 0 
#if(GAMESERVER_UPDATE>=251)
		|| IT_MAP_RANGE(lpObj->Map) != 0 || DA_MAP_RANGE(lpObj->Map) != 0 || DG_MAP_RANGE(lpObj->Map) != 0 || IG_MAP_RANGE(lpObj->Map) != 0
#endif
		)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 804));
		return;
	}

	int SkillNumber = SKILL_NONE;

	if(this->GetAttackSkill(lpObj,&SkillNumber) == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 805));
		return;
	}

	lpObj->AttackCustom = 1;

	lpObj->AttackCustomSkill = SkillNumber;

	lpObj->AttackCustomDelay = GetTickCount();

	lpObj->AttackCustomZoneX = lpObj->X;

	lpObj->AttackCustomZoneY = lpObj->Y;

	lpObj->AttackCustomZoneMap = lpObj->Map;

	lpObj->AttackCustomOffline = 0;

	lpObj->AttackCustomOfflineTime = 0;

	lpObj->AttackCustomOfflineMoneyDelay = 0;

	lpObj->AttackCustomTime = this->m_CustomAttackTime[lpObj->AccountLevel] * 600;

	if (this->m_CustomAttackTime[lpObj->AccountLevel] > 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 806), this->m_CustomAttackTime[lpObj->AccountLevel]);
	}
}

void CCustomAttack::CommandCustomAttackOffline(LPOBJ lpObj,char* arg) // OK
{
	if(this->m_CustomAttackOfflineSwitch == 0)
	{
		return;
	}

	if (lpObj->TradeDuel != 0)
	{
		return;
	}

	if(this->m_CustomAttackOfflineEnable[lpObj->AccountLevel] == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 810));
		return;
	}

	if(((gMasterSkillTree.CheckMasterLevel(lpObj)==0)?lpObj->Level:(lpObj->Level+lpObj->MasterLevel)) < this->m_CustomAttackOfflineRequireLevel[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 811),this->m_CustomAttackOfflineRequireLevel[lpObj->AccountLevel]);
		return;
	}

	if(((int)lpObj->Reset) < this->m_CustomAttackOfflineRequireReset[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 812),this->m_CustomAttackOfflineRequireReset[lpObj->AccountLevel]);
		return;
	}

	if(((int)lpObj->Money) < this->m_CustomAttackOfflineRequireMoney[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 813),this->m_CustomAttackOfflineRequireMoney[lpObj->AccountLevel]);
		return;
	}

	if(lpObj->AttackCustom == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 814));
		return;
	}

	if(gMap[lpObj->Map].CheckAttr(lpObj->X,lpObj->Y,1) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 815));
		return;
	}

	if(CA_MAP_RANGE(lpObj->Map) != 0 || DS_MAP_RANGE(lpObj->Map) != 0 || BC_MAP_RANGE(lpObj->Map) != 0 || CC_MAP_RANGE(lpObj->Map) != 0 
#if(GAMESERVER_UPDATE>=251)
		|| IT_MAP_RANGE(lpObj->Map) != 0 || DA_MAP_RANGE(lpObj->Map) != 0 || DG_MAP_RANGE(lpObj->Map) != 0 || IG_MAP_RANGE(lpObj->Map) != 0
#endif
		)
	{
		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0, gMessage.GetMessage(lpObj->m_Language, 815));
		return;
	}

	lpObj->Socket = INVALID_SOCKET;

	lpObj->AttackCustomOffline = 1;

	lpObj->AttackCustomOfflineTime = 0;

	lpObj->AttackCustomOfflineMoneyDelay = GetTickCount();

	lpObj->AttackCustomOfflineTimeOnline = GetTickCount();

	lpObj->Money -= this->m_CustomAttackOfflineRequireMoney[lpObj->AccountLevel];

	closesocket(lpObj->PerSocketContext->Socket);
}

bool CCustomAttack::GetAttackSkill(LPOBJ lpObj,int* SkillNumber) // OK
{
	CSkill* lpSkill = 0;

	switch (lpObj->Class)
	{
	case CLASS_DW:
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_ICE_STORM) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_EVIL_SPIRIT) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_INFERNO) : lpSkill);
		break;
	case CLASS_DK:
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_TWISTING_SLASH) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_DEATH_STAB) : lpSkill);
		break;
	case CLASS_FE:
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_TRIPLE_SHOT) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_FIVE_SHOT) : lpSkill);
		break;
	case CLASS_MG:
		if (lpObj->Inventory[0].m_Index >= GET_ITEM(5, 0) && lpObj->Inventory[0].m_Index < GET_ITEM(6, 0))
		{
			#if(GAMESERVER_UPDATE>=301)
			lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_LIGHTNING_STORM) : lpSkill);
			#endif
			lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_EVIL_SPIRIT) : lpSkill);
		}
		else
		{
			#if(GAMESERVER_UPDATE>=301)
			lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_SWORD_SLASH) : lpSkill);
			#endif
			lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_POWER_SLASH) : lpSkill);
		}
		break;
	case CLASS_DL:
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_FIRE_SCREAM) : lpSkill);
		#if(GAMESERVER_UPDATE>=301)
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_BIRDS) : lpSkill);
		#endif
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_FIRE_BURST) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_FORCE) : lpSkill);
		break;
	case CLASS_SU:
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_RED_STORM) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_CHAIN_LIGHTNING) : lpSkill);
		break;
	case CLASS_RF:
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_DARK_SIDE) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_DRAGON_LORE) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_PHOENIX_SHOT) : lpSkill);
		lpSkill = ((lpSkill == 0) ? gSkillManager.GetSkill(lpObj, SKILL_LARGE_RING_BLOWER) : lpSkill);
		break;
	}

	if(lpSkill == 0)
	{
		return 0;
	}
	else
	{
		(*SkillNumber) = lpSkill->m_index;
		return 1;
	}
}

bool CCustomAttack::GetTargetMonster(LPOBJ lpObj,int SkillNumber,int* MonsterIndex) // OK
{
	int NearestDistance = 100;

	for(int n=0;n < MAX_VIEWPORT;n++)
	{
		if(lpObj->VpPlayer2[n].state == VIEWPORT_NONE || OBJECT_RANGE(lpObj->VpPlayer2[n].index) == 0 || lpObj->VpPlayer2[n].type != OBJECT_MONSTER)
		{
			continue;
		}

		if(gSkillManager.CheckSkillTarget(lpObj,lpObj->VpPlayer2[n].index,-1,lpObj->VpPlayer2[n].type) == 0)
		{
			continue;
		}

		if(gObjCalcDistance(lpObj,&gObj[lpObj->VpPlayer2[n].index]) >= NearestDistance)
		{
			continue;
		}

		if(gSkillManager.CheckSkillRange(SkillNumber,lpObj->X,lpObj->Y,gObj[lpObj->VpPlayer2[n].index].X,gObj[lpObj->VpPlayer2[n].index].Y) != 0)
		{
			(*MonsterIndex) = lpObj->VpPlayer2[n].index;
			NearestDistance = gObjCalcDistance(lpObj,&gObj[lpObj->VpPlayer2[n].index]);
			continue;
		}

		if(gSkillManager.CheckSkillRadio(SkillNumber,lpObj->X,lpObj->Y,gObj[lpObj->VpPlayer2[n].index].X,gObj[lpObj->VpPlayer2[n].index].Y) != 0)
		{
			(*MonsterIndex) = lpObj->VpPlayer2[n].index;
			NearestDistance = gObjCalcDistance(lpObj,&gObj[lpObj->VpPlayer2[n].index]);
			continue;
		}
	}

	return ((NearestDistance==100)?0:1);
}

bool CCustomAttack::CheckRequireMoney(LPOBJ lpObj) // OK
{
	if(lpObj->AttackCustomOffline == 0)
	{
		return 1;
	}

	if((GetTickCount()-((DWORD)lpObj->AttackCustomOfflineMoneyDelay)) < 60000)
	{
		return 1;
	}

	if(((int)lpObj->Money) < this->m_CustomAttackOfflineRequireMoney[lpObj->AccountLevel])
	{
		return 0;
	}

	lpObj->Money -= this->m_CustomAttackOfflineRequireMoney[lpObj->AccountLevel];

	lpObj->AttackCustomOfflineMoneyDelay = GetTickCount();

	return 1;
}

void CCustomAttack::OnAttackClose(LPOBJ lpObj) // OK
{
	if(lpObj->AttackCustom != 0)
	{
		lpObj->AttackCustom = 0;
		lpObj->AttackCustomSkill = 0;
		lpObj->AttackCustomDelay = 0;
		lpObj->AttackCustomZoneX = 0;
		lpObj->AttackCustomZoneY = 0;
		lpObj->AttackCustomZoneMap = 0;
	}

	if(lpObj->AttackCustomOffline == 1)
	{
		lpObj->AttackCustomOffline = 2;
		lpObj->AttackCustomOfflineTime = 5;
	}
}

void CCustomAttack::OnAttackSecondProc(LPOBJ lpObj) // OK
{
	if(lpObj->AttackCustomOffline != 0)
	{
		if(lpObj->AttackCustomOffline == 2)
		{
			if((--lpObj->AttackCustomOfflineTime) == 0)
			{
				gObjDel(lpObj->Index);
				lpObj->AttackCustomOffline = 0;
				lpObj->AttackCustomOfflineTime = 0;
				lpObj->AttackCustomOfflineMoneyDelay = 0;
			}
		}

		lpObj->CheckSumTime = GetTickCount();
		lpObj->ConnectTickCount = GetTickCount();
		#if(GAMESERVER_UPDATE>=250)
		lpObj->PcPointPointTime = ((this->m_CustomAttackOfflineGPGain==0)?GetTickCount():lpObj->PcPointPointTime);
		lpObj->CashShopGoblinPointTime = ((this->m_CustomAttackOfflineGPGain==0)?GetTickCount():lpObj->CashShopGoblinPointTime);
		#endif
	}
}

void CCustomAttack::OnAttackAlreadyConnected(LPOBJ lpObj) // OK
{
	if(lpObj->AttackCustomOffline != 0)
	{
		gObjDel(lpObj->Index);
		lpObj->AttackCustomOffline = 0;
		lpObj->AttackCustomOfflineTime = 0;
		lpObj->AttackCustomOfflineMoneyDelay = 0;
	}
}

void CCustomAttack::OnAttackMonsterAndMsgProc(LPOBJ lpObj) // OK
{
	CSkill* lpSkill;

	if(lpObj->AttackCustom == 0)
	{
		return;
	}

	if(this->CheckRequireMoney(lpObj) == 0)
	{
		this->OnAttackClose(lpObj);
		return;
	}

	if(gMap[lpObj->Map].CheckAttr(lpObj->X,lpObj->Y,1) != 0)
	{
		this->OnAttackClose(lpObj);
		return;
	}

	if((lpSkill=gSkillManager.GetSkill(lpObj,lpObj->AttackCustomSkill)) == 0)
	{
		this->OnAttackClose(lpObj);
		return;
	}

	if (lpObj->AttackCustomTime > 0)
	{
		if ((--lpObj->AttackCustomTime) == 0)
		{
			gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 816));
			this->OnAttackClose(lpObj);
			return;
		}
	}

	if(gViewport.CheckViewportObjectPosition(lpObj->Index,lpObj->AttackCustomZoneMap,lpObj->AttackCustomZoneX,lpObj->AttackCustomZoneY,7) == 0)
	{
		this->OnAttackClose(lpObj);
		return;
	}

	if(((lpObj->Life*100)/(lpObj->MaxLife+lpObj->AddLife)) < 50)
	{
		PMSG_ITEM_USE_RECV pMsg;

		pMsg.header.set(0x26,sizeof(pMsg));

		pMsg.SourceSlot = 0xFF;

		pMsg.SourceSlot = ((pMsg.SourceSlot==0xFF)?gItemManager.GetInventoryItemSlot(lpObj,GET_ITEM(14,3),-1):pMsg.SourceSlot);

		pMsg.SourceSlot = ((pMsg.SourceSlot==0xFF)?gItemManager.GetInventoryItemSlot(lpObj,GET_ITEM(14,2),-1):pMsg.SourceSlot);

		pMsg.SourceSlot = ((pMsg.SourceSlot==0xFF)?gItemManager.GetInventoryItemSlot(lpObj,GET_ITEM(14,1),-1):pMsg.SourceSlot);

		pMsg.TargetSlot = 0xFF;

		pMsg.type = 0;

		if(INVENTORY_FULL_RANGE(pMsg.SourceSlot) != 0){gItemManager.CGItemUseRecv(&pMsg,lpObj->Index);}
	}

	if(((lpObj->Mana*100)/(lpObj->MaxMana+lpObj->AddMana)) < 50)
	{
		PMSG_ITEM_USE_RECV pMsg;

		pMsg.header.set(0x26,sizeof(pMsg));

		pMsg.SourceSlot = 0xFF;

		pMsg.SourceSlot = ((pMsg.SourceSlot==0xFF)?gItemManager.GetInventoryItemSlot(lpObj,GET_ITEM(14,6),-1):pMsg.SourceSlot);

		pMsg.SourceSlot = ((pMsg.SourceSlot==0xFF)?gItemManager.GetInventoryItemSlot(lpObj,GET_ITEM(14,4),-1):pMsg.SourceSlot);

		pMsg.SourceSlot = ((pMsg.SourceSlot==0xFF)?gItemManager.GetInventoryItemSlot(lpObj,GET_ITEM(14,3),-1):pMsg.SourceSlot);

		pMsg.TargetSlot = 0xFF;

		pMsg.type = 0;

		if(INVENTORY_FULL_RANGE(pMsg.SourceSlot) != 0){gItemManager.CGItemUseRecv(&pMsg,lpObj->Index);}
	}

	if((GetTickCount()-((DWORD)lpObj->AttackCustomDelay)) >= (((((DWORD)lpObj->PhysiSpeed)*5)> this->m_CustomAttackDelaySpeed[lpObj->Class])?0:(this->m_CustomAttackDelaySpeed[lpObj->Class] -(((DWORD)lpObj->PhysiSpeed)*5))))
	{
		int MonsterIndex = -1;

		lpObj->AttackCustomDelay = GetTickCount();

		if(this->GetTargetMonster(lpObj,lpSkill->m_index,&MonsterIndex) != 0)
		{
			switch(lpSkill->m_skill)
			{
			case SKILL_EVIL_SPIRIT:
				this->SendMultiSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_INFERNO:
				this->SendMultiSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_ICE_STORM:
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_TWISTING_SLASH:
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_DEATH_STAB:
				this->SendMultiSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_POWER_SLASH:
				gSkillManager.GCSkillAttackSend(lpObj, lpSkill->m_index, MonsterIndex, 1);
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_FORCE:
				this->SendSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_FIRE_BURST:
				this->SendMultiSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_FIRE_SCREAM:
				this->SendMultiSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_CHAIN_LIGHTNING:
				this->SendSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_RED_STORM:
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_FIVE_SHOT:
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_TRIPLE_SHOT:
				this->SendMultiSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_SWORD_SLASH:
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_LIGHTNING_STORM:
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_BIRDS:
				gSkillManager.GCSkillAttackSend(lpObj, lpSkill->m_index, MonsterIndex, 1);
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_LARGE_RING_BLOWER:
				this->SendSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_DRAGON_LORE:
				this->SendDurationSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_PHOENIX_SHOT:
				this->SendSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			case SKILL_DARK_SIDE:
				this->SendRFSkillAttack(lpObj, MonsterIndex, lpSkill->m_index);
				break;
			}
		}
	}
}

void CCustomAttack::SendSkillAttack(LPOBJ lpObj,int aIndex,int SkillNumber) // OK
{
	PMSG_SKILL_ATTACK_RECV pMsg;

	pMsg.header.set(0x19,sizeof(pMsg));

	#if(GAMESERVER_UPDATE>=701)

	pMsg.skillH = SET_NUMBERHB(SkillNumber);

	pMsg.skillL = SET_NUMBERLB(SkillNumber);

	pMsg.indexH = SET_NUMBERHB(aIndex);

	pMsg.indexL = SET_NUMBERLB(aIndex);

	#else

	#if(GAMESERVER_UPDATE>=301)
	pMsg.skill[0] = SET_NUMBERHB(SkillNumber);

	pMsg.skill[1] = SET_NUMBERLB(SkillNumber);
	#else
	pMsg.skill = (BYTE)SkillNumber;
	#endif

	pMsg.index[0] = SET_NUMBERHB(aIndex);

	pMsg.index[1] = SET_NUMBERLB(aIndex);

	#endif

	pMsg.dis = 0;

	gSkillManager.CGSkillAttackRecv(&pMsg,lpObj->Index);
}

void CCustomAttack::SendMultiSkillAttack(LPOBJ lpObj,int aIndex,int SkillNumber) // OK
{
	this->SendDurationSkillAttack(lpObj,aIndex,SkillNumber);

	BYTE send[256];

	PMSG_MULTI_SKILL_ATTACK_RECV pMsg;

	pMsg.header.set(PROTOCOL_CODE4,sizeof(pMsg));

	int size = sizeof(pMsg);

	#if(GAMESERVER_UPDATE>=701)

	pMsg.skillH = SET_NUMBERHB(SkillNumber);

	pMsg.skillL = SET_NUMBERLB(SkillNumber);

	#else

	#if(GAMESERVER_UPDATE>=301)
	pMsg.skill[0] = SET_NUMBERHB(SkillNumber);

	pMsg.skill[1] = SET_NUMBERLB(SkillNumber);
	#else
	pMsg.skill = (BYTE)SkillNumber;
	#endif

	#endif

	pMsg.x = (BYTE)lpObj->X;

	pMsg.y = (BYTE)lpObj->Y;

	pMsg.serial = 0;

	pMsg.count = 0;

	PMSG_MULTI_SKILL_ATTACK info;

	for(int n=0;n < MAX_VIEWPORT;n++)
	{
		if(lpObj->VpPlayer2[n].state == VIEWPORT_NONE || OBJECT_RANGE(lpObj->VpPlayer2[n].index) == 0 || lpObj->VpPlayer2[n].type != OBJECT_MONSTER)
		{
			continue;
		}

		int index = lpObj->VpPlayer2[n].index;

		if(gSkillManager.CheckSkillTarget(lpObj,index,aIndex,lpObj->VpPlayer2[n].type) == 0)
		{
			continue;
		}

		if(gSkillManager.CheckSkillRadio(SkillNumber,lpObj->X,lpObj->Y,gObj[index].X,gObj[index].Y) == 0)
		{
			continue;
		}

		#if(GAMESERVER_UPDATE>=701)

		info.indexH = SET_NUMBERHB(index);

		info.indexL = SET_NUMBERLB(index);

		#else

		info.index[0] = SET_NUMBERHB(index);

		info.index[1] = SET_NUMBERLB(index);

		#endif

		info.MagicKey = 0;

		memcpy(&send[size],&info,sizeof(info));
		size += sizeof(info);

		if(CHECK_SKILL_ATTACK_COUNT(pMsg.count) == 0)
		{
			break;
		}
	}

	pMsg.header.size = size;

	memcpy(send,&pMsg,sizeof(pMsg));

	gSkillManager.CGMultiSkillAttackRecv((PMSG_MULTI_SKILL_ATTACK_RECV*)send,lpObj->Index,0);
}

void CCustomAttack::SendDurationSkillAttack(LPOBJ lpObj,int aIndex,int SkillNumber) // OK
{
	PMSG_DURATION_SKILL_ATTACK_RECV pMsg;

	pMsg.header.set(0x1E,sizeof(pMsg));

	#if(GAMESERVER_UPDATE>=701)

	pMsg.skillH = SET_NUMBERHB(SkillNumber);

	pMsg.skillL = SET_NUMBERLB(SkillNumber);

	#else

#if(GAMESERVER_UPDATE>=301)
	pMsg.skill[0] = SET_NUMBERHB(SkillNumber);

	pMsg.skill[1] = SET_NUMBERLB(SkillNumber);
#else
	pMsg.skill = (BYTE)SkillNumber;
#endif

	#endif

	pMsg.x = (BYTE)gObj[aIndex].X;

	pMsg.y = (BYTE)gObj[aIndex].Y;

	pMsg.dir = (gSkillManager.GetSkillAngle(gObj[aIndex].X,gObj[aIndex].Y,lpObj->X,lpObj->Y)*255)/360;

	pMsg.dis = 0;

	pMsg.angle = (gSkillManager.GetSkillAngle(lpObj->X,lpObj->Y,gObj[aIndex].X,gObj[aIndex].Y)*255)/360;

	#if(GAMESERVER_UPDATE>=803)

	pMsg.indexH = SET_NUMBERHB(aIndex);

	pMsg.indexL = SET_NUMBERLB(aIndex);

	#else

	pMsg.index[0] = SET_NUMBERHB(aIndex);

	pMsg.index[1] = SET_NUMBERLB(aIndex);

	#endif

	pMsg.MagicKey = 0;

	gSkillManager.CGDurationSkillAttackRecv(&pMsg,lpObj->Index);
}

void CCustomAttack::SendRFSkillAttack(LPOBJ lpObj, int aIndex, int SkillNumber)
{
	PMSG_SKILL_DARK_SIDE_RECV Msg;

	Msg.skill[0] = SET_NUMBERHB(SkillNumber);

	Msg.skill[1] = SET_NUMBERLB(SkillNumber);

	Msg.index[0] = SET_NUMBERHB(aIndex);

	Msg.index[1] = SET_NUMBERLB(aIndex);

	gSkillManager.CGSkillDarkSideRecv(&Msg, lpObj->Index);

	PMSG_RAGE_FIGHTER_SKILL_ATTACK_RECV pMsg;

	pMsg.header.set(0x19, sizeof(pMsg));

#if(GAMESERVER_UPDATE>=701)

	pMsg.skillH = SET_NUMBERHB(SkillNumber);

	pMsg.skillL = SET_NUMBERLB(SkillNumber);

	pMsg.indexH = SET_NUMBERHB(aIndex);

	pMsg.indexL = SET_NUMBERLB(aIndex);

#else

	pMsg.skill[0] = SET_NUMBERHB(SkillNumber);

	pMsg.skill[1] = SET_NUMBERLB(SkillNumber);

	pMsg.index[0] = SET_NUMBERHB(aIndex);

	pMsg.index[1] = SET_NUMBERLB(aIndex);

#endif

	pMsg.dis = 0;

	this->SendDurationSkillAttack(lpObj, aIndex, SkillNumber);
	gSkillManager.CGRageFighterSkillAttackRecv(&pMsg, lpObj->Index);
}
