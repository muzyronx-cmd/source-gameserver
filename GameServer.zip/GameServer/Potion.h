#pragma once

#include "Protocol.h"

struct PMSG_POTION_RECV
{
	PSBMSG_HEAD h;
	int	HP;
	int MP;
	int AG;
	int SD;
};

class cPotion
{
public:
	cPotion();
	virtual ~cPotion();
	void CGPotionTypeRecv(int aIndex, PMSG_POTION_RECV* lpMsg);
	bool CommandAutoPotion(LPOBJ lpObj, char* arg);
	int Inventory(LPOBJ lpObj, int aIndex);
	static void Thread1(void* lpParam);
	static void Thread2(void* lpParam);
};

extern cPotion Potion;