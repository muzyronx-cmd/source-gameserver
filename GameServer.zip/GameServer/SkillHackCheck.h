#pragma once

class SKILL_HACK_CHECK_INFO {
public:
	SKILL_HACK_CHECK_INFO() {
		this->MinDetectHits = 0;
		this->MaxDetectHits = 0;
		this->MinDelay = 0;
		this->MaxDelay = 0;
	};

	~SKILL_HACK_CHECK_INFO() {

	};

	int MinDetectHits;
	int MaxDetectHits;
	int MinDelay;
	int MaxDelay;
};

class SKILL_HACK_CHECK_OBJ {
public:
	SKILL_HACK_CHECK_OBJ() {
		this->skill = -1;

		this->m_SkillHackCheckInfo.clear();
	};

	~SKILL_HACK_CHECK_OBJ() {
		this->m_SkillHackCheckInfo.clear();
	};

	int skill;
	std::vector<SKILL_HACK_CHECK_INFO> m_SkillHackCheckInfo;
};

class CSkillHackCheck {
public:
	CSkillHackCheck();
	~CSkillHackCheck();

	void Load(char * path);
	SKILL_HACK_CHECK_OBJ* GetSkillInfo(int skill);
	bool CheckSkillHack(int aIndex, int skill);
	bool CheckSkillSkillHackMinHits(int aIndex, int index, int MinHits);
	bool CheckSkillSkillHackMaxHits(int aIndex, int index, int MaxHits);
	bool CheckSkillSkillHackMinDelay(int aIndex, int index, int MinDelay);
	bool CheckSkillSkillHackMaxDelay(int aIndex, int index, int MaxDelay);

private:
	std::map<int, SKILL_HACK_CHECK_OBJ> m_SkillHackCheckObj;
};

extern CSkillHackCheck gSkillHackCheck;