#pragma once

struct ANTI_FLOOD_INFO
{
	std::string IpAddress;
	int Count;
	DWORD TickCount;
	bool Block;
	DWORD BlockTime;
	DWORD LastActivity;

	ANTI_FLOOD_INFO() {
		IpAddress.clear();
		Count = 0;
		Block = false;
	}
};

class CAntiFlood
{
public:
	CAntiFlood();
	virtual ~CAntiFlood();

	void AddIpAddress(char * IpAddress);
	bool CheckFlood(char * IpAddress);
	void BlockIpAddress(char * IpAddress);

private:
	std::map<std::string, ANTI_FLOOD_INFO*> m_AntiFloodInfo;
};

extern CAntiFlood gAntiFlood;