#include "StdAfx.h"
#include "AntiHack.h"
#include "Log.h"
#include "ServerInfo.h"
#include "Util.h"
#include "Notice.h"
#include "LuaGameServer.h"

CAntiHack gAntiHack;

CAntiHack::CAntiHack()
{

}

CAntiHack::~CAntiHack()
{

}

void CAntiHack::MainProc()
{
	
}

void CAntiHack::GameServerGetHitsMain(int aIndex)
{
	
}

void CAntiHack::AntiHackRecv(PMSG_ANTI_HACK_HITS * lpMsg, int aIndex)
{
	
}

void CAntiHack::AntiHackRecvHits(PMSG_ANTI_HACK_RECV * lpMsg, int aIndex)
{
	
}

void CAntiHack::AntiHackRecvMoves(PMSG_ANTI_HACK_MOVE_RECV * lpMsg, int aIndex)
{
	
}

void CAntiHack::AntiHackRecvPotions(PMSG_ANTI_HACK_POTION_RECV * lpMsg, int aIndex)
{
	
}

char* DisconnectTypes[12] = { "TickCount Server Worker",
"TickCount Framers",
"Framers Alterados",
"TickCount Hook",
"Query Performance Hook",
"TimeGetTime Hook",
"FPS Acima de 23 Use Skill",
"FPS Acima de 23 Andando",
"Incorrect Frame Detected",
"Auto Potion",
"Auto Rest Potion",
"Speed Hack Framers", };

void CAntiHack::AntiHackDisconnectType(PMSG_ANTI_HACK_DISCONNECT_RECV * lpMsg, int aIndex)
{
	
}

void CAntiHack::ClientKeySend(int aIndex)
{
	PMSG_ANTI_CLIENT_KEY_SEND pMsg;

	pMsg.header.set(0xFB, 0x04, sizeof(pMsg));

	pMsg.m_Key01 = rand() % 50000;

	pMsg.m_Key02 = pMsg.m_Key01;

	pMsg.m_Key03 = 4874;

	pMsg.m_Key04 = 150;

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
}

void CAntiHack::ClientKeyRecv(PMSG_ANTI_CLIENT_KEY_RECV * lpMsg, int aIndex)
{
	if (OBJECT_RANGE(aIndex) == 0) {
		return;
	}

	gLuaGameServer.MacAddressPlayer(aIndex, lpMsg->m_MacAddress);

	if (_strcmpi(lpMsg->m_Language, "Por") == 0) {
		strcpy_s(lpMsg->m_Language, "Por");
	}

	if (_strcmpi(lpMsg->m_Language, "Eng") == 0) {
		strcpy_s(lpMsg->m_Language, "Eng");
	}

	if (_strcmpi(lpMsg->m_Language, "Spn") == 0) {
		strcpy_s(lpMsg->m_Language, "Spn");
	}

	if (_strcmpi(lpMsg->m_Language, "Por") != 0
		&& _strcmpi(lpMsg->m_Language, "Eng") != 0
		&& _strcmpi(lpMsg->m_Language, "Spn") != 0) {
		std::memcpy(lpMsg->m_Language, "Por", sizeof(lpMsg->m_Language));
	}

	strcpy_s(gObj[aIndex].m_Language, lpMsg->m_Language);

	/*strcpy_s(gObj[aIndex].m_MacAddress, lpMsg->m_MacAddress);

	gSqlFuctions.UpdateMacAddress(gObj[aIndex].Account, lpMsg->m_MacAddress);*/
}

void CAntiHack::CheckMacAddress(LPOBJ lpObj)
{
	/*if(gSqlFuctions.CheckMacBlock(lpObj->m_MacAddress) != 0)
	{
	gNotice.GCNoticeCustomSend(lpObj->Index, 24, "Voc� est� pro�bido de jogar o servidor");
	CloseClient(lpObj->Index);
	}*/
}