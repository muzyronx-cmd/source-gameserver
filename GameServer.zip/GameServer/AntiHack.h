#pragma once

#include "user.h"
#include "protocol.h"

struct PMSG_ANTI_HACK_RECV
{
	PSBMSG_HEAD header;
	int Hits;
	int FPS;
	int Ping;
	int Framers;
};

struct PMSG_ANTI_HACK_MOVE_RECV
{
	PSBMSG_HEAD header;
	int Moves;
	int FPS;
};

struct PMSG_ANTI_HACK_POTION_RECV
{
	PSBMSG_HEAD header;
	int Potions;
	int FPS;
	int RestPotion;
	int PotionQ;
	int PotionW;
	int PotionE;
};

struct PMSG_ANTI_HACK_HITS
{
	PSBMSG_HEAD header;
	int Hits;
	int TotalHits;
	int FPS;
	int Ping;
	int Framers;
};

struct PMSG_ANTI_HACK_DISCONNECT_RECV
{
	PSBMSG_HEAD header;
	int type;
	int fps;
	int ping;
	int framers;
};

struct PMSG_ANTI_CLIENT_KEY_SEND
{
	PSBMSG_HEAD header;

	int m_Key01;
	int m_Key02;
	int m_Key03;
	int m_Key04;
};

struct PMSG_ANTI_CLIENT_KEY_RECV
{
	PSBMSG_HEAD header;

	char m_MacAddress[40];
	char m_Language[4];
};

class CAntiHack
{
public:
	CAntiHack();
	virtual ~CAntiHack();

	void MainProc();
	void GameServerGetHitsMain(int aIndex);
	void AntiHackRecv(PMSG_ANTI_HACK_HITS * lpMsg, int aIndex);
	void AntiHackRecvHits(PMSG_ANTI_HACK_RECV * lpMsg, int aIndex);
	void AntiHackRecvMoves(PMSG_ANTI_HACK_MOVE_RECV * lpMsg, int aIndex);
	void AntiHackRecvPotions(PMSG_ANTI_HACK_POTION_RECV * lpMsg, int aIndex);
	void AntiHackDisconnectType(PMSG_ANTI_HACK_DISCONNECT_RECV * lpMsg, int aIndex);
	void ClientKeySend(int aIndex);
	void ClientKeyRecv(PMSG_ANTI_CLIENT_KEY_RECV * lpMsg, int aIndex);

	void CheckMacAddress(LPOBJ lpObj);
};

extern CAntiHack gAntiHack;