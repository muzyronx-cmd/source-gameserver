#include "stdafx.h"
#include "CustomNpcMaluco.h"
#include "ScheduleManager.h"
#include "MemScript.h"
#include "Notice.h"
#include "Util.h"
#include "ShopManager.h"
#include "ServerInfo.h"

CCustomNpcMaluco gCustomNpcMaluco;

CCustomNpcMaluco::CCustomNpcMaluco()
{
	CUSTOM_NPC_MALUCO_INFO* lpInfo = &this->m_CustomNpcMalucoInfo;

	lpInfo->State = CUSTOM_NPC_MALUCO_STATE_BLANK;
	lpInfo->RemainTime = 0;
	lpInfo->TargetTime = 0;
	lpInfo->TickCount = GetTickCount();
	lpInfo->AlarmMinSave = -1;
	lpInfo->AlarmMinLeft = -1;
}

CCustomNpcMaluco::~CCustomNpcMaluco()
{

}

void CCustomNpcMaluco::Init() // OK
{
	if (this->m_CustomNpcMalucoSwitch == 0)
	{
		this->SetState(&this->m_CustomNpcMalucoInfo, CUSTOM_NPC_MALUCO_STATE_BLANK);
	}
	else
	{
		this->SetState(&this->m_CustomNpcMalucoInfo, CUSTOM_NPC_MALUCO_STATE_EMPTY);
	}
}

void CCustomNpcMaluco::ReadCustomNpcMalucoInfo(char* section, char* path) // OK
{
	this->m_CustomNpcMalucoSwitch = GetPrivateProfileInt(section, "CustomNpcMalucoSwitch", 0, path);

	GetPrivateProfileString(section, "CustomNpcMalucoText1", "", this->m_CustomNpcMalucoText1, sizeof(this->m_CustomNpcMalucoText1), path);

	GetPrivateProfileString(section, "CustomNpcMalucoText2", "", this->m_CustomNpcMalucoText2, sizeof(this->m_CustomNpcMalucoText2), path);

	GetPrivateProfileString(section, "CustomNpcMalucoText3", "", this->m_CustomNpcMalucoText3, sizeof(this->m_CustomNpcMalucoText3), path);
}

void CCustomNpcMaluco::Load(char* path) // OK
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			int section = lpMemScript->GetNumber();

			while (true)
			{
				if (section == 0)
				{
					if (strcmp("end", lpMemScript->GetAsString()) == 0)
					{
						break;
					}

					CUSTOM_NPC_MALUCO_START_TIME info;

					info.Year = lpMemScript->GetNumber();

					info.Month = lpMemScript->GetAsNumber();

					info.Day = lpMemScript->GetAsNumber();

					info.DayOfWeek = lpMemScript->GetAsNumber();

					info.Hour = lpMemScript->GetAsNumber();

					info.Minute = lpMemScript->GetAsNumber();

					info.Second = lpMemScript->GetAsNumber();

					this->m_CustomNpcMalucoInfo.StartTime.push_back(info);
				}
				else if (section == 1)
				{
					if (strcmp("end", lpMemScript->GetAsString()) == 0)
					{
						break;
					}

					this->m_CustomNpcMalucoInfo.RuleInfo.AlarmTime = lpMemScript->GetNumber();

					this->m_CustomNpcMalucoInfo.RuleInfo.EventTime = lpMemScript->GetAsNumber();
				}
				else if (section == 2)
				{
					if (strcmp("end", lpMemScript->GetAsString()) == 0)
					{
						break;
					}

					SHOP_MANAGER_NPC_MALUCO_INFO info;

					info.Index = lpMemScript->GetNumber();

					info.MonsterClass = lpMemScript->GetAsNumber();

					gShopManager.m_ShopManagerNpcMalucoInfo.insert(std::pair<int, SHOP_MANAGER_NPC_MALUCO_INFO>(info.Index, info));
				}
				else
				{
					break;
				}
			}
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;

	gShopManager.LoadShopNpcMaluco();
}

void CCustomNpcMaluco::MainProc() // OK
{
	CUSTOM_NPC_MALUCO_INFO* lpInfo = &this->m_CustomNpcMalucoInfo;

	if ((GetTickCount() - lpInfo->TickCount) >= 1000)
	{
		lpInfo->TickCount = GetTickCount();

		lpInfo->RemainTime = (int)difftime(lpInfo->TargetTime, time(0));

		switch (lpInfo->State)
		{
		case CUSTOM_NPC_MALUCO_STATE_BLANK:
			this->ProcState_BLANK(lpInfo);
			break;
		case CUSTOM_NPC_MALUCO_STATE_EMPTY:
			this->ProcState_EMPTY(lpInfo);
			break;
		case CUSTOM_NPC_MALUCO_STATE_START:
			this->ProcState_START(lpInfo);
			break;
		case CUSTOM_NPC_MALUCO_STATE_CLEAN:
			this->ProcState_CLEAN(lpInfo);
			break;
		}
	}
}

void CCustomNpcMaluco::ProcState_BLANK(CUSTOM_NPC_MALUCO_INFO* lpInfo) // OK
{

}

void CCustomNpcMaluco::ProcState_EMPTY(CUSTOM_NPC_MALUCO_INFO* lpInfo) // OK
{
	if (lpInfo->RemainTime > 0 && lpInfo->RemainTime <= (lpInfo->RuleInfo.AlarmTime * 60))
	{
		if ((lpInfo->AlarmMinSave = (((lpInfo->RemainTime % 60) == 0) ? ((lpInfo->RemainTime / 60) - 1) : (lpInfo->RemainTime / 60))) != lpInfo->AlarmMinLeft)
		{
			lpInfo->AlarmMinLeft = lpInfo->AlarmMinSave;

			gNotice.GCNoticeSendToAll(0, 0, 0, 0, 0, 0, this->m_CustomNpcMalucoText1, (lpInfo->AlarmMinLeft + 1));
		}
	}

	if (lpInfo->RemainTime <= 0)
	{
		gNotice.GCNoticeSendToAll(0, 0, 0, 0, 0, 0, this->m_CustomNpcMalucoText2);
		this->SetState(lpInfo, CUSTOM_NPC_MALUCO_STATE_START);
	}
}

void CCustomNpcMaluco::ProcState_START(CUSTOM_NPC_MALUCO_INFO* lpInfo) // OK
{
	if (lpInfo->RemainTime <= 0)
	{
		gNotice.GCNoticeSendToAll(0, 0, 0, 0, 0, 0, this->m_CustomNpcMalucoText3);
		this->SetState(lpInfo, CUSTOM_NPC_MALUCO_STATE_CLEAN);
	}
}

void CCustomNpcMaluco::ProcState_CLEAN(CUSTOM_NPC_MALUCO_INFO * lpInfo)
{
	this->SetState(lpInfo, CUSTOM_NPC_MALUCO_STATE_EMPTY);
}

void CCustomNpcMaluco::SetState(CUSTOM_NPC_MALUCO_INFO* lpInfo, int state) // OK
{
	switch ((lpInfo->State = state))
	{
	case CUSTOM_NPC_MALUCO_STATE_BLANK:
		this->SetState_BLANK(lpInfo);
		break;
	case CUSTOM_NPC_MALUCO_STATE_EMPTY:
		this->SetState_EMPTY(lpInfo);
		break;
	case CUSTOM_NPC_MALUCO_STATE_START:
		this->SetState_START(lpInfo);
		break;
	case CUSTOM_NPC_MALUCO_STATE_CLEAN:
		this->SetState_CLEAN(lpInfo);
		break;
	}
}

void CCustomNpcMaluco::SetState_BLANK(CUSTOM_NPC_MALUCO_INFO* lpInfo) // OK
{

}

void CCustomNpcMaluco::SetState_EMPTY(CUSTOM_NPC_MALUCO_INFO* lpInfo) // OK
{
	lpInfo->AlarmMinSave = -1;
	lpInfo->AlarmMinLeft = -1;

	this->CheckSync(lpInfo);
}

void CCustomNpcMaluco::SetState_START(CUSTOM_NPC_MALUCO_INFO* lpInfo) // OK
{
	this->SetMonsterNumber();

	lpInfo->AlarmMinSave = -1;
	lpInfo->AlarmMinLeft = -1;

	lpInfo->RemainTime = lpInfo->RuleInfo.EventTime * 60;

	lpInfo->TargetTime = (int)(time(0) + lpInfo->RemainTime);
}

void CCustomNpcMaluco::SetState_CLEAN(CUSTOM_NPC_MALUCO_INFO * lpInfo)
{
	this->SetMonsterNumber();
}

void CCustomNpcMaluco::CheckSync(CUSTOM_NPC_MALUCO_INFO* lpInfo) // OK
{
	if (lpInfo->StartTime.empty() != 0)
	{
		this->SetState(lpInfo, CUSTOM_NPC_MALUCO_STATE_BLANK);
		return;
	}

	CTime ScheduleTime;

	CScheduleManager ScheduleManager;

	for (std::vector<CUSTOM_NPC_MALUCO_START_TIME>::iterator it = lpInfo->StartTime.begin(); it != lpInfo->StartTime.end(); it++)
	{
		ScheduleManager.AddSchedule(it->Year, it->Month, it->Day, it->Hour, it->Minute, it->Second, it->DayOfWeek);
	}

	if (ScheduleManager.GetSchedule(&ScheduleTime) == 0)
	{
		this->SetState(lpInfo, CUSTOM_NPC_MALUCO_STATE_BLANK);
		return;
	}

	lpInfo->RemainTime = (int)difftime(ScheduleTime.GetTime(), time(0));

	lpInfo->TargetTime = (int)ScheduleTime.GetTime();
}

int CCustomNpcMaluco::GetState()
{
	return this->m_CustomNpcMalucoInfo.State;
}

void CCustomNpcMaluco::SetMonsterNumber()
{
	int MonsterClass = 0;

	for (int n = OBJECT_START_MONSTER; n < MAX_OBJECT_MONSTER; n++)
	{
		if (gObj[n].Type != OBJECT_NPC)
		{
			continue;
		}

		MonsterClass = gObj[n].Class;

		if ((MonsterClass >= 204 && MonsterClass <= 259) || (MonsterClass >= 367 && MonsterClass <= 371) || (MonsterClass >= 375 && MonsterClass <= 385) || MonsterClass == 406 || MonsterClass == 407 || MonsterClass == 408 || MonsterClass == 415 || MonsterClass == 416 || MonsterClass == 417 || (MonsterClass >= 450 && MonsterClass <= 453) || MonsterClass == 464 || MonsterClass == 465 || (MonsterClass >= 467 && MonsterClass <= 475) || MonsterClass == 478 || MonsterClass == 479 || MonsterClass == 492 || MonsterClass == 522 || (MonsterClass >= 540 && MonsterClass <= 547) || (MonsterClass >= 566 && MonsterClass <= 568) || (MonsterClass >= 577 && MonsterClass <= 584) || MonsterClass == 604 || MonsterClass == 643 || MonsterClass == 651)
		{
			gObj[n].ShopNumber = (short)gShopManager.GetShopNumber(MonsterClass, gObj[n].Map, gObj[n].X, gObj[n].Y);
		}
	}
}
