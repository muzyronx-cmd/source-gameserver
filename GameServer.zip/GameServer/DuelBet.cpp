// Duel.cpp: implementation of the CDuelBet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DuelBet.h"
#include "CastleSiege.h"
#include "DarkSpirit.h"
#include "DSProtocol.h"
#include "EffectManager.h"
#include "Guild.h"
#include "MapServerManager.h"
#include "User.h"
#include "Util.h"
#include "GameMain.h"
#include "ChaosCastle.h"
#include "DevilSquare.h"
#include "BloodCastle.h"
#include "Notice.h"
#include "ItemManager.h"
#include "Log.h"
#include "Trade.h"
#include "ServerInfo.h"
#include "ObjectManager.h"
#include "Message.h"

#ifdef CUSTOM_GAMESERVER

CDuelBet gDuelBet;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDuelBet::CDuelBet()
{

}

CDuelBet::~CDuelBet()
{

}

bool CDuelBet::CheckDuel(LPOBJ lpObj, LPOBJ lpTarget)
{
	if (lpObj->Type != OBJECT_USER || lpTarget->Type != OBJECT_USER)
	{
		return 0;
	}

	if (lpObj->Dueling != 1 && lpTarget->Dueling != 1) {
		return 0;
	}

	if (OBJECT_RANGE(lpObj->DuelUser) == 0 || OBJECT_RANGE(lpTarget->DuelUser) == 0)
	{
		return 0;
	}

	if (lpObj->DuelUser == lpTarget->Index && lpTarget->DuelUser == lpObj->Index)
	{
		return 1;
	}

	return 0;
}

bool CDuelBet::CheckDuelUser(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (lpObj->Type != OBJECT_USER)
	{
		return 0;
	}

	if (OBJECT_RANGE(lpObj->DuelUser) == 0)
	{
		return 0;
	}

	return 1;
}

void CDuelBet::CheckDuelScore(LPOBJ lpObj, LPOBJ lpTarget)
{
	if (this->CheckDuel(lpObj, lpTarget) == 0)
	{
		return;
	}

	lpTarget->KillerType = 3;

	if (lpObj->DuelScore >= 5)
	{
		lpTarget->KillerType = 0;

		this->DuelSendItemWinner(lpObj->Index);

		this->DuelFinish(lpObj, true);

		GDRankingDuelSaveSend(lpObj->Index, 1, 0);

		this->ResetDuel(lpObj);

		this->GCDuelBetEndSend(lpObj->Index, 0);

		this->ResetDuel(lpTarget);

		GDRankingDuelSaveSend(lpTarget->Index, 0, 1);

		this->GCDuelBetEndSend(lpTarget->Index, 0);
	}
}

void CDuelBet::CheckDuelUser()
{
	for (int n = OBJECT_START_USER; n < MAX_OBJECT; n++)
	{
		if (gObjIsConnected(n) == 0)
		{
			continue;
		}

		LPOBJ lpObj = &gObj[n];

		if (OBJECT_RANGE(lpObj->DuelUserReserved) != 0)
		{
			if ((GetTickCount() - lpObj->DuelTickCount) > 20000)
			{
				this->ResetDuel(&gObj[lpObj->DuelUserReserved]);
				this->GCDuelBetStartSend(lpObj->Index, 0, lpObj->DuelUserReserved);
				this->ResetDuel(lpObj);
			}
		}

		if (OBJECT_RANGE(lpObj->DuelUserRequested) != 0)
		{
			if ((GetTickCount() - lpObj->DuelTickCount) > 20000)
			{
				this->ResetDuel(&gObj[lpObj->DuelUserRequested]);
				this->GCDuelBetStartSend(lpObj->DuelUserRequested, 0, lpObj->Index);
				this->ResetDuel(lpObj);
			}
		}

		if (OBJECT_RANGE(lpObj->DuelUser) != 0)
		{
			if (lpObj->Map != 6 && lpObj->Interface.use == 0 && lpObj->Interface.type != INTERFACE_TRADE && lpObj->Interface.state != 0)
			{
				if (lpObj->DuelScore != gObj[lpObj->DuelUser].DuelScore)
				{
					if (lpObj->DuelScore > gObj[lpObj->DuelUser].DuelScore)
					{
						this->DuelSendItemWinner(lpObj->Index);
					}
					else if (gObj[lpObj->DuelUser].DuelScore > lpObj->DuelScore)
					{
						this->DuelSendItemWinner(lpObj->DuelUser);
					}
				}

				gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2300));
				gNotice.GCNoticeSend(lpObj->DuelUser, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2301));

				this->DuelFinish(lpObj, false);

				this->ResetDuel(&gObj[lpObj->DuelUser]);
				this->GCDuelBetEndSend(lpObj->DuelUser, 0);
				this->ResetDuel(lpObj);
				this->GCDuelBetEndSend(lpObj->Index, 0);
				continue;
			}

			if (lpObj->Guild != 0)
			{
				if (lpObj->Guild->WarState != 0)
				{
					gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2302));
					gNotice.GCNoticeSend(lpObj->DuelUser, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2303));

					this->DuelFinish(lpObj, false);

					this->ResetDuel(&gObj[lpObj->DuelUser]);
					this->GCDuelBetEndSend(lpObj->DuelUser, 0);
					this->ResetDuel(lpObj);
					this->GCDuelBetEndSend(lpObj->Index, 0);
					continue;
				}
			}

			if ((GetTickCount() - lpObj->DuelTickCount) > (60000 * 4))
			{
				if (lpObj->DuelScore != gObj[lpObj->DuelUser].DuelScore)
				{
					if (lpObj->DuelScore > gObj[lpObj->DuelUser].DuelScore)
					{
						this->DuelSendItemWinner(lpObj->Index);
					}
					else if (gObj[lpObj->DuelUser].DuelScore > lpObj->DuelScore)
					{
						this->DuelSendItemWinner(lpObj->DuelUser);
					}
				}

				this->DuelFinish(lpObj, false);

				this->ResetDuel(&gObj[lpObj->DuelUser]);
				this->GCDuelBetEndSend(lpObj->DuelUser, 0);
				this->ResetDuel(lpObj);
				this->GCDuelBetEndSend(lpObj->Index, 0);
			}
		}
	}
}

void CDuelBet::ResetDuel(LPOBJ lpObj)
{
	gDarkSpirit[lpObj->Index].ResetTarget(lpObj->DuelUser);

	lpObj->DuelUserReserved = -1;
	lpObj->DuelUserRequested = -1;
	lpObj->DuelScore = 0;
	lpObj->DuelUser = -1;
	lpObj->DuelTickCount = 0;

	lpObj->Dueling = 0;

	memset(lpObj->Dueling_bets, 0xFF, 32);
	memset(lpObj->Dueling_inventory, 0xFF, 64);
}

void CDuelBet::RespawnDuelUser(LPOBJ lpObj)
{
	lpObj->Map = 6;
	lpObj->X = 11;
	lpObj->Y = 244;

	gMap[lpObj->Map].GetMapRandomPos(&lpObj->X, &lpObj->Y, 2);
}

void CDuelBet::UserDieProc(LPOBJ lpObj, LPOBJ lpTarget)
{
	if (this->CheckDuel(lpObj, lpTarget) == 0)
	{
		return;
	}

	lpTarget->DuelScore++;

	this->GCDuelBetScoreSend(lpObj->Index, lpTarget->Index);
}

void CDuelBet::CGDuelStartRecv(PMSG_DUEL_START_RECV* lpMsg, int aIndex)
{
	if (gServerInfo.m_DuelSwitch != 1)
	{
		return;
	}

	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return;
	}

	int bIndex = MAKE_NUMBERW(lpMsg->index[0], lpMsg->index[1]);

	if (gObjIsConnectedGP(bIndex) == 0 || aIndex == bIndex)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2304));
		return;
	}

	LPOBJ lpTarget = &gObj[bIndex];

	if (lpObj->Interface.use != 0 || lpObj->State == OBJECT_DELCMD || lpObj->DieRegen != 0 || lpObj->Teleport != 0 || lpObj->PShopOpen != 0 || lpObj->SkillSummonPartyTime != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2305));
		return;
	}

	if ((lpTarget->Option & 2) == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2306));
		return;
	}

	if (OBJECT_RANGE(lpObj->DuelUserReserved) != 0 || OBJECT_RANGE(lpObj->DuelUserRequested) != 0 || OBJECT_RANGE(lpObj->DuelUser) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2307));
		return;
	}

	if (OBJECT_RANGE(lpTarget->DuelUserReserved) != 0 || OBJECT_RANGE(lpTarget->DuelUserRequested) != 0 || OBJECT_RANGE(lpTarget->DuelUser) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2308));
		return;
	}

	if (lpTarget->PShopOpen != 0 || lpObj->PShopOpen != 0)
	{
		return;
	}

	if (lpObj->Map != lpTarget->Map) {
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2309));
		return;
	}

	if ((lpObj->X < lpTarget->X - 2) || (lpObj->X > lpTarget->X + 2) ||
		(lpObj->Y < lpTarget->Y - 2) || (lpObj->Y > lpTarget->Y + 2))
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2310));
		return;
	}

	if (lpObj->Guild != 0 && lpObj->Guild->WarState == 1)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2311));
		return;
	}

	if (lpTarget->Guild != 0 && lpTarget->Guild->WarState == 1)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2312));
		return;
	}

	if (DS_MAP_RANGE(lpObj->Map) != 0 || BC_MAP_RANGE(lpObj->Map) != 0 || CC_MAP_RANGE(lpObj->Map) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2313));
		return;
	}

#if(GAMESERVER_TYPE==1)

	if (gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_NOTIFY || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_READYSIEGE || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_STARTSIEGE)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2314));
		return;
	}

#endif

	char name[11] = { 0 };

	memcpy(name, lpMsg->name, sizeof(lpMsg->name));

	if (strcmp(lpTarget->Name, name) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2315));
		return;
	}

	for (int n = 0; n < MAX_SELF_DEFENSE; n++)
	{
		if (lpObj->SelfDefense[n] >= 0)
		{
			gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2316));
			return;
		}

		if (lpTarget->SelfDefense[n] >= 0)
		{
			gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2317));
			return;
		}
	}

	gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2318));

	gLog.Output(LOG_DUEL, "[Duel] Send (%s - %s) vs (%s - %s)", lpObj->Account, lpObj->Name, lpTarget->Account, lpTarget->Name);

	lpObj->DuelUserReserved = bIndex;
	lpObj->DuelUserRequested = -1;
	lpObj->DuelScore = 0;
	lpObj->DuelUser = -1;
	lpObj->DuelTickCount = GetTickCount();

	lpTarget->DuelUserReserved = -1;
	lpTarget->DuelUserRequested = aIndex;
	lpTarget->DuelScore = 0;
	lpTarget->DuelUser = -1;
	lpTarget->DuelTickCount = GetTickCount();

	this->GCDuelBetOkSend(bIndex, aIndex);
}

void CDuelBet::CGDuelOkRecv(PMSG_DUEL_OK_RECV* lpMsg, int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return;
	}

	int bIndex = MAKE_NUMBERW(lpMsg->index[0], lpMsg->index[1]);

	if (gObjIsConnectedGP(bIndex) == 0)
	{
		return;
	}

	LPOBJ lpTarget = &gObj[bIndex];

	if (lpMsg->flag == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2319));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	if (lpObj->Interface.use != 0 || lpTarget->Interface.use != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2320));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	if (lpTarget->PShopOpen != 0 || lpObj->PShopOpen != 0)
	{
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	if (OBJECT_RANGE(lpObj->DuelUserReserved) != 0 || OBJECT_RANGE(lpObj->DuelUser) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2321));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	if (OBJECT_RANGE(lpTarget->DuelUserRequested) != 0 || OBJECT_RANGE(lpTarget->DuelUser) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2322));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	if (lpTarget->DuelUserReserved != aIndex)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2322));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	if ((lpObj->X < lpTarget->X - 2) || (lpObj->X > lpTarget->X + 2) ||
		(lpObj->Y < lpTarget->Y - 2) || (lpObj->Y > lpTarget->Y + 2))
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2323));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	if (DS_MAP_RANGE(lpTarget->Map) != 0 || BC_MAP_RANGE(lpTarget->Map) != 0 || CC_MAP_RANGE(lpTarget->Map) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2324));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

#if(GAMESERVER_TYPE==1)

	if (gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_NOTIFY || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_READYSIEGE || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_STARTSIEGE)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2325));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

#endif

	char name[11] = { 0 };

	memcpy(name, lpMsg->name, 10);

	if (strcmp(lpTarget->Name, name) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2326));
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelBetStartSend(bIndex, 0, aIndex);
		return;
	}

	lpObj->DuelUserReserved = -1;
	lpObj->DuelUserRequested = -1;
	lpObj->DuelScore = 0;
	lpObj->DuelUser = bIndex;
	lpObj->DuelTickCount = GetTickCount();

	lpTarget->DuelUserReserved = -1;
	lpTarget->DuelUserRequested = -1;
	lpTarget->DuelScore = 0;
	lpTarget->DuelUser = aIndex;
	lpTarget->DuelTickCount = GetTickCount();


	//Enviar Trade
	//Variaveis que fingem o trade (dwIndex)
	lpObj->Interface.use = 1;
	lpObj->Interface.state = 0;
	lpObj->Interface.type = INTERFACE_TRADE;
	lpObj->TargetNumber = bIndex;
	lpObj->InterfaceTime = GetTickCount();
	//Variaveis que fingem o trade (wdIndex)
	lpTarget->Interface.use = 1;
	lpTarget->Interface.state = 0;
	lpTarget->Interface.type = INTERFACE_TRADE;
	lpTarget->TargetNumber = aIndex;
	lpTarget->InterfaceTime = GetTickCount();

	gLog.Output(LOG_DUEL, "[Duel] Start (%s - %s) vs (%s - %s)", lpObj->Account, lpObj->Name, lpTarget->Account, lpTarget->Name);

	this->GCSendDuelTrade(aIndex, bIndex);

	//Copia invent�rio ao abrir o trade
	memcpy(lpObj->Dueling_inventory, lpObj->InventoryMap, 64);
	memcpy(lpTarget->Dueling_inventory, lpTarget->InventoryMap, 64);
}

void CDuelBet::CGDuelEndRecv(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return;
	}

	if (OBJECT_RANGE(lpObj->DuelUserReserved) != 0)
	{
		this->ResetDuel(&gObj[lpObj->DuelUserReserved]);
		this->GCDuelBetStartSend(aIndex, 0, lpObj->DuelUserReserved);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->DuelUserRequested) != 0)
	{
		this->ResetDuel(&gObj[lpObj->DuelUserRequested]);
		this->GCDuelBetStartSend(lpObj->DuelUserRequested, 0, aIndex);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->DuelUser) != 0)
	{
		this->ResetDuel(&gObj[lpObj->DuelUser]);
		this->GCDuelBetEndSend(lpObj->DuelUser, 0);
		this->ResetDuel(lpObj);
		this->GCDuelBetEndSend(aIndex, 0);
		return;
	}
}

void CDuelBet::CGDuelEnd(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (OBJECT_RANGE(lpObj->DuelUserReserved) != 0)
	{
		this->ResetDuel(&gObj[lpObj->DuelUserReserved]);
		this->GCDuelBetStartSend(aIndex, 0, lpObj->DuelUserReserved);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->DuelUserRequested) != 0)
	{
		this->ResetDuel(&gObj[lpObj->DuelUserRequested]);
		this->GCDuelBetStartSend(lpObj->DuelUserRequested, 0, aIndex);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->DuelUser) != 0)
	{
		this->ResetDuel(&gObj[lpObj->DuelUser]);
		this->GCDuelBetEndSend(lpObj->DuelUser, 0);
		this->ResetDuel(lpObj);
		this->GCDuelBetEndSend(aIndex, 0);
		return;
	}
}

bool CDuelBet::GCDuelBetTradeOkButton(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return 0;
	}

	if (OBJECT_RANGE(lpObj->DuelUser) != 0)
	{
		lpObj->DuelTickCount = GetTickCount();

		if (OBJECT_RANGE(lpObj->TargetNumber) != 0)
		{
			if (lpObj->DuelUser != lpObj->TargetNumber)
			{
				this->GCDuelBetTradeCancel(lpObj);
				return 1;
			}

			LPOBJ lpTarget = &gObj[lpObj->DuelUser];

			if (gObjIsConnectedGP(lpObj->DuelUser) == 0)
			{
				this->GCDuelBetTradeCancel(lpObj);
				return 1;
			}

			if (lpObj->Map != lpTarget->Map)
			{
				this->GCDuelBetTradeCancel(lpObj);
				return 1;
			}

			if (lpObj->TradeOk == 1 && lpTarget->TradeOk == 1)
			{
				if (this->CheckDuelUserSpace(lpObj) == 0)
				{
					gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2327));
					gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2328));
					gNotice.GCNoticeSend(lpTarget->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpTarget->m_Language, 2329));

					this->GCDuelBetTradeCancel(lpObj);
					return 1;
				}

				if (this->CheckDuelUserSpace(lpTarget) == 0)
				{
					gNotice.GCNoticeSend(lpTarget->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpTarget->m_Language, 2330));
					gNotice.GCNoticeSend(lpTarget->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpTarget->m_Language, 2331));
					gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2332));

					this->GCDuelBetTradeCancel(lpObj);
					return 1;
				}

				for (int n = 0; n < 32; n++)
				{
					//Copia o item
					lpObj->Dueling_bets[n] = lpObj->Trade[n];
				}

				for (int n = 0; n < 32; n++)
				{
					//Copia o item
					lpTarget->Dueling_bets[n] = lpTarget->Trade[n];
				}

				lpObj->Dueling = 1;
				lpTarget->Dueling = 1;

				gTrade.ResetTrade(aIndex);
				gTrade.ResetTrade(lpTarget->Index);


				this->GCDuelBetStartSend(aIndex, 1, lpTarget->Index);

				this->GCDuelBetStartSend(lpTarget->Index, 1, aIndex);

				this->GCDuelBetScoreSend(aIndex, lpTarget->Index);

				lpObj->DuelTickCount = GetTickCount();
				lpTarget->DuelTickCount = GetTickCount();

				gLog.Output(LOG_DUEL, "[Duel] Bet OK (%s - %s) vs (%s - %s)", lpObj->Account, lpObj->Name, lpTarget->Account, lpTarget->Name);
				return 1;
			}
		}
	}

	return 0;
}

void CDuelBet::GCDuelBetTradeCancel(LPOBJ lpObj)
{
	if (lpObj->Live == 1)
	{
		gTrade.ResetTrade(lpObj->Index);
		gTrade.GCTradeResultSend(lpObj->Index, 0);
		gTrade.ResetTrade(lpObj->DuelUser);
		gTrade.GCTradeResultSend(lpObj->DuelUser, 0);
		this->CGDuelEndRecv(lpObj->Index);
	}
}

bool CDuelBet::CheckDuelUserSpace(LPOBJ lpObj)
{
	LPOBJ lpTarget = &gObj[lpObj->TargetNumber];

	if (gObjIsConnectedGP(lpTarget->Index) == 0)
	{
		return 0;
	}

	BYTE TemInventoryMap[64];

	memcpy(TemInventoryMap, lpObj->Dueling_inventory, 64);

	for (int n = 0; n < 32; n++)
	{
		if (lpTarget->Trade[n].IsItem() != 0)
		{
			if (gItemManager.InventoryInsertItemTemp(lpObj, lpTarget->Trade[n], (BYTE*)&TemInventoryMap) == 0xFF)
			{
				return 0;
			}
		}
	}

	return 1;
}

void CDuelBet::DuelFinish(LPOBJ lpObj, bool finished)
{
	gObjMoveGate(lpObj->Index, 17);
	gObjMoveGate(lpObj->DuelUser, 17);

	if (finished)
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2333));
		gNotice.GCNoticeSend(lpObj->DuelUser, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(gObj[lpObj->DuelUser].m_Language, 2334));

		gLog.Output(LOG_DUEL, "[Duel] Finish - Winner (%s - %s) Looser (%s - %s)", lpObj->Account, lpObj->Name, gObj[lpObj->DuelUser].Account, gObj[lpObj->DuelUser].Name);
	}
	else
	{
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 2335));
		gNotice.GCNoticeSend(lpObj->DuelUser, 0, 0, 0, 0, 0, 0, gMessage.GetMessage(gObj[lpObj->DuelUser].m_Language, 2335));

		gLog.Output(LOG_DUEL, "[Duel] Canceled - (%s - %s) (%s - %s)", lpObj->Account, lpObj->Name, gObj[lpObj->DuelUser].Account, gObj[lpObj->DuelUser].Name);
	}
}

void CDuelBet::DuelSendItemWinner(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	//Se ainda estou online
	if (lpObj->Connected < 3) { return; }

	LPOBJ lpTarget = &gObj[lpObj->DuelUser];

	//Se quem estou dando trade est� conectado ainda
	if (lpTarget->Connected < 3) { return; }

	for (int n = 0; n < 32; n++)
	{
		//Se tiver um item
		if (lpTarget->Dueling_bets[n].IsItem() == 1)
		{
			if (gItemManager.InventoryInsertItem(lpObj->Index, lpTarget->Dueling_bets[n]) != 0xFF)
			{
				gLog.Output(LOG_DUEL, "[%s][%s] (%d | %d) Insert Item From [%s][%s]", lpObj->Name, lpObj->Account, lpTarget->Dueling_bets[n].m_Index, lpTarget->Dueling_bets[n].m_Serial, lpTarget->Name, lpTarget->Account);

				//Item inserido, ent�o deletar do invent�rio do outro que perdeu o duelo
				for (int a = 0; a < 76; a++)
				{
					if (lpTarget->Inventory[a].IsItem() == 1) {
						//Faz por serial (simple way)
						if (lpTarget->Inventory[a].m_Serial > 0) {
							if (lpTarget->Dueling_bets[n].m_Serial == lpTarget->Inventory[a].m_Serial) {
								//Item encontrado e sendo deletado 
								gItemManager.InventoryDelItem(lpTarget->Index, a);
							}
						}
						else {
							if (lpTarget->Dueling_bets[n].m_Index == lpTarget->Inventory[a].m_Index) {
								if (lpTarget->Dueling_bets[n].m_Option1 == lpTarget->Inventory[a].m_Option1) {
									if (lpTarget->Dueling_bets[n].m_NewOption == lpTarget->Inventory[a].m_NewOption) {
										//Item encontrado e sendo deletado
										gItemManager.InventoryDelItem(lpTarget->Index, a);
									}
								}
							}
						}
					}
				}
			}
			else {
				LogAdd(LOG_RED, "[DUEL-INSERTITEM / NO SPACE] [%s][%s]", lpObj->Account, lpObj->Name);
			}
		}
	}

	gObjectManager.CharacterMakePreviewCharSet(lpTarget->Index);
	gItemManager.GCItemListSend(lpTarget->Index);
	gTrade.GCTradeResultSend(lpTarget->Index, 1);

	gObjectManager.CharacterMakePreviewCharSet(lpObj->Index);
	gItemManager.GCItemListSend(lpObj->Index);
	gTrade.GCTradeResultSend(lpObj->Index, 1);
}

void CDuelBet::GCDuelBetStartSend(int aIndex, BYTE result, int bIndex)
{
	PMSG_DUEL_START_SEND pMsg;

	pMsg.header.set(0xAA, sizeof(pMsg));

	pMsg.result = result;

	pMsg.index[0] = SET_NUMBERHB(bIndex);
	pMsg.index[1] = SET_NUMBERLB(bIndex);

	memcpy(pMsg.name, gObj[bIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
}

void CDuelBet::GCDuelBetOkSend(int aIndex, int bIndex)
{
	PMSG_DUEL_OK_SEND pMsg;

	pMsg.header.set(0xAC, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(bIndex);
	pMsg.index[1] = SET_NUMBERLB(bIndex);

	memcpy(pMsg.name, gObj[bIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
}

void CDuelBet::GCDuelBetEndSend(int aIndex, BYTE result)
{
	PMSG_DUEL_END_SEND pMsg;

	pMsg.header.set(0xAB, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(aIndex);
	pMsg.index[1] = SET_NUMBERLB(aIndex);

	memcpy(pMsg.name, gObj[aIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
}

void CDuelBet::GCDuelBetScoreSend(int aIndex, int bIndex)
{
	PMSG_DUEL_SCORE_SEND pMsg;

	pMsg.header.set(0xAD, sizeof(pMsg));

	pMsg.index1[0] = SET_NUMBERHB(aIndex);
	pMsg.index1[1] = SET_NUMBERLB(aIndex);

	pMsg.index2[0] = SET_NUMBERHB(bIndex);
	pMsg.index2[1] = SET_NUMBERLB(bIndex);

	pMsg.score[0] = gObj[aIndex].DuelScore;
	pMsg.score[1] = gObj[bIndex].DuelScore;

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
	DataSend(bIndex, (BYTE*)&pMsg, pMsg.header.size);
}

void CDuelBet::GCSendDuelTrade(int aIndex, int bIsndex)
{
	PMSG_TRADE_RESPONSE_RECV pMsg;

	pMsg.header.setE(0x37, sizeof(pMsg));

	pMsg.response = 1;

	memcpy(pMsg.name, gObj[aIndex].Name, 10);

	gTrade.CGTradeResponseRecv(&pMsg, aIndex);
}
#endif