#pragma once

#if GAMESERVER_UPDATE == 603
#include "Protocol.h"
#include "User.h"

struct PMSG_MUHELPER_OFFLINE_RECV
{
	PSBMSG_HEAD header;
	WORD HuntingRange;
	//-- Potion
	BYTE RecoveryPotionOn;
	BYTE RecoveryPotionPercent;
	BYTE RecoveryHealOn; //-> CLASS_ELF
	BYTE RecoveryHealPercent; //-> CLASS_ELF
	BYTE RecoveryDrainOn; //-> CLASS_SUMMONER
	BYTE RecoveryDrainPercent; //-> CLASS_SUMMONER
							   //-- Attack
	BYTE DistanceLongOn;
	BYTE DistanceReturnOn;
	WORD DistanceMin;//-- tiempo
	WORD SkillBasicID;
	WORD SkillSecondID;
	WORD SkillThirdID;
	BYTE ComboOn;				//-> CLASS_KNIGHT
	BYTE PartyModeOn;
	BYTE PartyModeHealOn;		//-> CLASS_ELF
	BYTE PartyModeHealPercent;	//-> CLASS_ELF
	BYTE PartyModeBuffOn;
	BYTE BuffOn;
	WORD BuffSkill[3];
	//-- Obtaing
	WORD ObtainRange;
	BYTE ObtainRepairOn;
	BYTE ObtainPickNear;
	BYTE ObtainPickSelected;
	BYTE ObtainPickMoney;
	BYTE ObtainPickJewels;
	BYTE ObtainPickExcellent;
	BYTE ObtainPickAncient;
	BYTE ObtainPickExtra;
	int ObtainPickExtraCount;
	char ObtainPickItemList[12][16];
};

class CMuHelperOffline {
public:
	CMuHelperOffline();
	~CMuHelperOffline();

	void Load(char* section, char* path);
	void MuHelperOfflineRecv(PMSG_MUHELPER_OFFLINE_RECV * lpMsg, int aIndex);
	void OnAttackHelperAlreadyConnected(LPOBJ lpObj);
	void OnAttackHelperSecondProc(LPOBJ lpObj);
	void OnAttackMsgProc(LPOBJ lpObj);
	void AutoPotionProc(LPOBJ lpObj);
	void AutoBuffProc(LPOBJ lpObj);
	bool GetTargetMonster(LPOBJ lpObj, int SkillNumber, int* MonsterIndex);
	void AutoAttackProc(LPOBJ lpObj);
	void AutoRepairProc(LPOBJ lpObj);
	void AnimationMove(LPOBJ lpObj, int x, int y);
	void AutoTurnBack(int aIndex);
	void AutoPickProc(int aIndex);
	bool checkJewel(int ItemIndex);
	bool checkListPickUp(int Index, int Level, LPOBJ lpObj);

private:
	int m_MuHelperOfflineSwitch;
	int m_MuHelperOfflineEnable[MAX_ACCOUNT_LEVEL];
	int m_MuHelperOfflineTime[MAX_ACCOUNT_LEVEL];
	int m_MuHelperOfflineAutoPickVip[MAX_ACCOUNT_LEVEL];
	int m_MuHelperOfflineRequireLevel[MAX_ACCOUNT_LEVEL];
	int m_MuHelperOfflineRequireReset[MAX_ACCOUNT_LEVEL];
};

extern CMuHelperOffline gMuHelperOffline;
#endif