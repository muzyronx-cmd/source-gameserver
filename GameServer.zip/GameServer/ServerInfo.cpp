// ServerInfo.cpp: implementation of the CServerInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ServerInfo.h"
#include "380ItemOption.h"
#include "380ItemType.h"
#include "BloodCastle.h"
#include "BonusManager.h"
#include "CashShop.h"
#include "CastleDeep.h"
#include "CastleSiege.h"
#include "ChaosCastle.h"
#include "Crywolf.h"
#include "CrywolfSync.h"
#include "CustomArena.h"
#include "CustomAttack.h"
#include "CustomEventDrop.h"
#include "CustomJewel.h"
#include "CustomMonster.h"
#include "CustomStore.h"
#include "CustomWing.h"
#include "CustomPet.h"
#include "CustomNpcMaluco.h"
#include "DefaultClassInfo.h"
#include "DevilSquare.h"
#include "DoubleGoer.h"
#include "EffectManager.h"
#include "ExperienceTable.h"
#include "Filter.h"
#include "Gate.h"
#include "HackPacketCheck.h"
#include "SkillHackCheck.h"
#include "SkillHackSpeedCheck.h"
#include "IllusionTemple.h"
#include "ImperialGuardian.h"
#include "InvasionManager.h"
#include "ItemBagManager.h"
#include "ItemDrop.h"
#include "ItemMove.h"
#include "ItemOption.h"
#include "ItemOptionRate.h"
#include "ItemStack.h"
#include "ItemValue.h"
#include "ItemAttribute.h"
#include "ItemBuffSkill.h"
#include "ItemPetDamage.h"
#include "ItemPetDamageZone.h"
#include "ItemWingDamageZone.h"
#include "JewelOfHarmonyOption.h"
#include "JewelOfHarmonyType.h"
#include "Kanturu.h"
#include "KanturuMonsterMng.h"
#include "LuckyItem.h"
#include "MapManager.h"
#include "MapServerManager.h"
#include "MasterSkillTree.h"
#include "Message.h"
#include "MiniMap.h"
#include "MiningSystem.h"
#include "MonsterAIAutomata.h"
#include "MonsterAIElement.h"
#include "MonsterAIGroup.h"
#include "MonsterAIRule.h"
#include "MonsterAIUnit.h"
#include "MonsterManager.h"
#include "MonsterSetBase.h"
#include "MonsterSkillElement.h"
#include "MonsterSkillManager.h"
#include "MonsterSkillUnit.h"
#include "MossMerchant.h"
#include "Move.h"
#include "MoveSummon.h"
#include "MuunSystem.h"
#include "Notice.h"
#include "PacketManager.h"
#include "Path.h"
#include "PcPoint.h"
#include "PentagramSystem.h"
#include "Quest.h"
#include "QuestObjective.h"
#include "QuestReward.h"
#include "QuestWorld.h"
#include "QuestWorldObjective.h"
#include "QuestWorldReward.h"
#include "Raklion.h"
#include "SetItemOption.h"
#include "SetItemType.h"
#include "ShopManager.h"
#include "SkillHitBox.h"
#include "SkillManager.h"
#include "SocketItemOption.h"
#include "SocketItemType.h"
#include "SummonScroll.h"
#include "Util.h"
#include "DeathSystem.h"
#include "SkillDamage.h"
#include "MuHelperOffline.h"
#include "LuaGameServer.h"
#include "ZenTable.h"
#include "PKZone.h"
#include "HappyHourZen.h"
#include "ObjectManager.h"

CServerInfo gServerInfo;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CServerInfo::CServerInfo() // OK
{

}

CServerInfo::~CServerInfo() // OK
{

}

bool CServerInfo::ValidateLordGamingLicense(const char* path) // LordGaming License
{
	char LicenseIP[64] = {0};

	GetPrivateProfileStringA("GameServerInfo", "LicenseIP", "", LicenseIP, sizeof(LicenseIP), path);

	// Remove espacos e quebras de linha que possam existir no valor do INI.
	char* begin = LicenseIP;
	while (*begin == ' ' || *begin == '\t')
	{
		++begin;
	}

	char* end = begin + strlen(begin);
	while (end > begin && (end[-1] == ' ' || end[-1] == '\t' || end[-1] == '\r' || end[-1] == '\n'))
	{
		--end;
	}
	*end = 0;

	if (begin[0] == 0 || _stricmp(begin, LORDGAMING_LICENSE_IP) != 0)
	{
		MessageBoxA(0, "Erro de Licença LordGaming entre em contato com o suporte", "LordGaming", MB_OK | MB_ICONERROR);
		return false;
	}

	return true;
}

void CServerInfo::ReadInit() // OK
{
	gPath.SetMainPath(MAIN_PATH);

	this->ReadCashShopInfo();

	this->ReadChaosMixInfo();

	this->ReadCharacterInfo();

	this->ReadCommonInfo();

	this->ReadCustomInfo();

	this->ReadEventInfo();

	this->ReadEventItemBagInfo();

	this->ReadHackInfo();

	this->ReadItemInfo();

	this->ReadMapInfo();

	this->ReadMonsterInfo();

	this->ReadMonsterSetBaseInfo();

	this->ReadMoveInfo();

	this->ReadQuestInfo();

	this->ReadShopInfo();

	this->ReadSkillInfo();

	this->ReadUtilInfo();
}

void CServerInfo::ReadCashShopInfo() // OK
{
	this->ReadCashShopInfo("GameServerInfo",".\\Data\\GameServerInfo - Common.dat");

	#if(GAMESERVER_UPDATE>=501)

	gCashShop.LoadPackage(gPath.GetFullPath("CashShop\\CashShopPackage.txt"));

	gCashShop.LoadProduct(gPath.GetFullPath("CashShop\\CashShopProduct.txt"));

	#endif

	LogAdd(LOG_BLUE,"[ServerInfo] CashShop loaded successfully");
}

void CServerInfo::ReadChaosMixInfo() // OK
{
	this->ReadChaosMixInfo("GameServerInfo",".\\Data\\GameServerInfo - ChaosMix.dat");

	LogAdd(LOG_BLUE,"[ServerInfo] ChaosMix loaded successfully");
}

void CServerInfo::ReadCharacterInfo() // OK
{
	this->ReadCharacterInfo("GameServerInfo",".\\Data\\GameServerInfo - Character.dat");

	gDefaultClassInfo.Load(gPath.GetFullPath("Character\\DefaultClassInfo.txt"));

	for (int i = OBJECT_START_USER; i < MAX_OBJECT; i++) {
		if (gObj[i].Connected == OBJECT_ONLINE) {
			gObjectManager.CharacterCalcAttribute(i);
		}
	}

	LogAdd(LOG_BLUE,"[ServerInfo] Character loaded successfully");
}

void CServerInfo::ReadCommonInfo() // OK
{
	this->ReadCommonInfo("GameServerInfo",".\\Data\\GameServerInfo - Common.dat");

	gEffectManager.Load(gPath.GetFullPath("Effect.txt"));

	gMapManager.Load(gPath.GetFullPath("MapManager.txt"));

#if(GAMESERVER_UPDATE>=99)
	gMapServerManager.Load(gPath.GetFullPath("MapServerInfo.dat"));
#endif

	gMessage.LoadMsgEng(gPath.GetFullPath("Message\\Message_Eng.txt"));

	gMessage.LoadMsgPor(gPath.GetFullPath("Message\\Message_Por.txt"));

	gMessage.LoadMsgSpn(gPath.GetFullPath("Message\\Message_Spn.txt"));

	#if(GAMESERVER_UPDATE>=802)

	gMiniMap.Load(gPath.GetFullPath("MiniMap.txt"));

	#endif

	#if(GAMESERVER_UPDATE>=801)

	gMiningSystem.Load(gPath.GetFullPath("Mining.txt"));

	#endif

	LogAdd(LOG_BLUE,"[ServerInfo] Common loaded successfully");
}

void CServerInfo::ReadCustomInfo() // OK
{
	this->ReadCustomInfo("GameServerInfo",".\\Data\\GameServerInfo - Custom.dat");

	#if(GAMESERVER_UPDATE>=401)
	gCustomArena.ReadCustomArenaInfo("GameServerInfo",".\\Data\\GameServerInfo - Custom.dat");
	#endif

	gCustomAttack.ReadCustomAttackInfo("GameServerInfo",".\\Data\\GameServerInfo - Custom.dat");

	gCustomEventDrop.ReadCustomEventDropInfo("GameServerInfo",".\\Data\\GameServerInfo - Custom.dat");

	gCustomStore.ReadCustomStoreInfo("GameServerInfo",".\\Data\\GameServerInfo - Custom.dat");

	gCustomNpcMaluco.ReadCustomNpcMalucoInfo("GameServerInfo", ".\\Data\\GameServerInfo - Custom.dat");

	#if(GAMESERVER_UPDATE>=401)
	gCustomArena.Load(gPath.GetFullPath("Custom\\CustomArena.txt"));
	#endif

	gCustomEventDrop.Load(gPath.GetFullPath("Custom\\CustomEventDrop.txt"));

#ifdef CUSTOM_GAMESERVER
	gHappyHourZen.Load(gPath.GetFullPath("Custom\\HappyHourZen.txt"));
#endif

	#if(GAMESERVER_UPDATE >= 101)
	gCustomJewel.Load(gPath.GetFullPath("Custom\\CustomJewel.txt"));
	#endif

	gCustomMonster.Load(gPath.GetFullPath("Custom\\CustomMonster.txt"));

	gCustomNpcMaluco.Load(gPath.GetFullPath("Custom\\CustomNpcMaluco.txt"));

	#if(GAMESERVER_UPDATE>=401)
	gCustomWing.Load(gPath.GetFullPath("Custom\\CustomWing.txt"));

	gCustomPets.Load(gPath.GetFullPath("Custom\\CustomPets.txt"));
	#endif

#if GAMESERVER_UPDATE == 603
	gDeathSystem.Load(gPath.GetFullPath("Custom\\CounterItem.txt"));
#else
#if(GAMESERVER_UPDATE >= 201)
	gDeathSystem.Load(gPath.GetFullPath("Custom\\DeathSystem.txt"));
#endif
#endif

	#if (GAMESERVER_UPDATE == 603)
	gMuHelperOffline.Load("GameServerInfo", ".\\Data\\GameServerInfo - Custom.dat");
	#endif

	LogAdd(LOG_BLUE,"[ServerInfo] Custom loaded successfully");
}

void CServerInfo::ReadEventInfo() // OK
{
	this->ReadEventInfo("GameServerInfo",".\\Data\\GameServerInfo - Event.dat");

	gBloodCastle.Load(gPath.GetFullPath("Event\\BloodCastle.dat"));

	gBonusManager.Load(gPath.GetFullPath("Event\\BonusManager.dat"));

#if(GAMESERVER_UPDATE>=99)
	gCastleDeep.Load(gPath.GetFullPath("Event\\CastleDeepEvent.dat"));
#endif

#if(GAMESERVER_UPDATE>=99)
	gChaosCastle.Load(gPath.GetFullPath("Event\\ChaosCastle.dat"));
#endif

	#if(GAMESERVER_TYPE==1)
	#if(GAMESERVER_UPDATE>=201)
	gCrywolf.Load(gPath.GetFullPath("Event\\Crywolf.dat"));
	#endif
	#endif

	gDevilSquare.Load(gPath.GetFullPath("Event\\DevilSquare.dat"));

	#if(GAMESERVER_UPDATE>=501)

	gDoubleGoer.Load(gPath.GetFullPath("Event\\DoubleGoer.dat"));

	#endif

	#if(GAMESERVER_UPDATE>=301)

	gIllusionTemple.Load(gPath.GetFullPath("Event\\IllusionTemple.dat"));

	#endif

	#if(GAMESERVER_UPDATE>=501)

	gImperialGuardian.Load(gPath.GetFullPath("Event\\ImperialGuardian.dat"));

	#endif

	gInvasionManager.Load(gPath.GetFullPath("Event\\InvasionManager.dat"));

	#if(GAMESERVER_UPDATE>=201)

	gKanturu.Load(gPath.GetFullPath("Event\\Kanturu.dat"));

	#endif

	#if(GAMESERVER_UPDATE>=402)

	gMossMerchant.Load(gPath.GetFullPath("Event\\MossMerchant.dat"));

	#endif

	#if(GAMESERVER_UPDATE>=401)

	gRaklion.Load(gPath.GetFullPath("Event\\Raklion.dat"));

	#endif

	#if(GAMESERVER_UPDATE>=601)

	gSummonScroll.Load(gPath.GetFullPath("Event\\SummonScroll.dat"));

	#endif

	#if(GAMESERVER_TYPE==1)

	if(gCastleSiege.Ready(gMapServerManager.GetMapServerGroup()) != 0)
	{
		if(gCastleSiege.LoadData(gPath.GetFullPath("Event\\MuCastleData.dat")) != 0)
		{
			gCastleSiege.LoadPreFixData(".\\Data\\GameServerInfo - Event.dat");
			gCastleSiege.SetDataLoadState(CASTLESIEGE_DATALOAD_2);
		}
	}

	#endif

	LogAdd(LOG_BLUE,"[ServerInfo] Event loaded successfully");

	gBloodCastle.Init();

	gBonusManager.Init();

	gCastleDeep.Init();

	gChaosCastle.Init();

#if(GAMESERVER_UPDATE>=401)
	gCustomArena.Init();
#endif

	gCustomEventDrop.Init();

#ifdef CUSTOM_GAMESERVER
	gHappyHourZen.Init();
#endif

	gDevilSquare.Init();

#if(GAMESERVER_UPDATE>=301)
	gIllusionTemple.Init();
#endif

	gInvasionManager.Init();

	gMossMerchant.Init();

#if(GAMESERVER_UPDATE>=402)
	gRaklion.SetState(RAKLION_STATE_END);
#endif

	gCustomNpcMaluco.Init();
}

void CServerInfo::ReadEventItemBagInfo() // OK
{
	gItemBagManager.Load(gPath.GetFullPath("EventItemBagManager.txt"));

	gItemBagManager.LoadEventItemBag();

	LogAdd(LOG_BLUE,"[ServerInfo] EventItemBag loaded successfully");
}

void CServerInfo::ReadHackInfo() // OK
{
	this->ReadHackInfo("GameServerInfo",".\\Data\\GameServerInfo - Common.dat");

	gHackPacketCheck.Load(gPath.GetFullPath("Hack\\HackPacketCheck.txt"));

	gSkillHackCheck.Load(gPath.GetFullPath("Hack\\SkillHackCheck.txt"));

	gSkillHackSpeedCheck.Load(gPath.GetFullPath("Hack\\SkillHackSpeedCheck.txt"));

	gPacketManager.LoadEncryptionKey(gPath.GetFullPath("Hack\\Enc2.dat"));

	gPacketManager.LoadDecryptionKey(gPath.GetFullPath("Hack\\Dec1.dat"));

	LogAdd(LOG_BLUE,"[ServerInfo] Hack loaded successfully");
}

void CServerInfo::ReadItemInfo() // OK
{
	#if(GAMESERVER_UPDATE>=201)

	g380ItemOption.Load(gPath.GetFullPath("Item\\380ItemOption.txt"));

	g380ItemType.Load(gPath.GetFullPath("Item\\380ItemType.txt"));

	#endif

	gItemManager.Load(gPath.GetFullPath("Item\\Item.txt"));

	gItemDrop.Load(gPath.GetFullPath("Item\\ItemDrop.txt"));

	gItemMove.Load(gPath.GetFullPath("Item\\ItemMove.txt"));

	gItemOption.Load(gPath.GetFullPath("Item\\ItemOption.txt"));

	gItemOptionRate.Load(gPath.GetFullPath("Item\\ItemOptionRate.txt"));

	gItemStack.Load(gPath.GetFullPath("Item\\ItemStack.txt"));

	gItemValue.Load(gPath.GetFullPath("Item\\ItemValue.txt"));

	#if(GAMESERVER_UPDATE>=201)

	gJewelOfHarmonyOption.Load(gPath.GetFullPath("Item\\JewelOfHarmonyOption.txt"));

	gJewelOfHarmonyType.Load(gPath.GetFullPath("Item\\JewelOfHarmonyType.txt"));

	#endif

	#if(GAMESERVER_UPDATE>=602)

	gLuckyItem.Load(gPath.GetFullPath("Item\\LuckyItem.txt"));

	#endif

	#if(GAMESERVER_UPDATE>=803)

	gMuunSystem.Load(gPath.GetFullPath("Item\\MuunOption.txt"));

	#endif

	#if(GAMESERVER_UPDATE>=701)

	gPentagramSystem.Load(gPath.GetFullPath("Item\\PentagramOption.txt"));

	gPentagramSystem.LoadJewel(gPath.GetFullPath("Item\\PentagramJewelOption.txt"));

	gPentagramSystem.LoadMixRate(gPath.GetFullPath("Item\\PentagramJewelMixRate.txt"));

	#endif

	#if(GAMESERVER_UPDATE>=99)
	gSetItemOption.Load(gPath.GetFullPath("Item\\SetItemOption.txt"));

	gSetItemType.Load(gPath.GetFullPath("Item\\SetItemType.txt"));
	#endif

	#if(GAMESERVER_UPDATE>=401)

	gSocketItemOption.Load(gPath.GetFullPath("Item\\SocketItemOption.txt"));

	gSocketItemType.Load(gPath.GetFullPath("Item\\SocketItemType.txt"));

	#endif

	gItemAttribute.Load(gPath.GetFullPath("Item\\ItemAttribute.txt"));

	gItemBuffSkill.Load(gPath.GetFullPath("Item\\ItemBuffSkill.txt"));

	gItemPetDamage.Load(gPath.GetFullPath("Item\\ItemPetDamage.txt"));

	gItemPetDamageZone.Load(gPath.GetFullPath("Item\\ItemPetDamageZone.txt"));

	gItemWingDamageZone.Load(gPath.GetFullPath("Item\\ItemWingDamageZone.txt"));

	LogAdd(LOG_BLUE,"[ServerInfo] Item loaded successfully");
}

void CServerInfo::ReadMapInfo() // OK
{
	FILE* file;

	char path[256] = {0};

	char temp[256] = {0};

	for(int n=0;n < MAX_MAP;n++)
	{
		wsprintf(temp,"Terrain\\terrain%d.att",(n+1));

		if(fopen_s(&file,gPath.GetFullPath(temp),"r") == 0)
		{
			strcpy_s(path,temp);
			fclose(file);
		}

		gMap[n].Load(gPath.GetFullPath(path),n);
	}

	#if(GAMESERVER_UPDATE>=201)
	gCrywolf.LoadCrywolfMapAttr(gPath.GetFullPath("Terrain\\terrain35_PEACE.att"),0);

	gCrywolf.LoadCrywolfMapAttr(gPath.GetFullPath("Terrain\\terrain35_OCCUPIED.att"),1);

	gCrywolf.LoadCrywolfMapAttr(gPath.GetFullPath("Terrain\\terrain35_WAR.att"),2);

	gKanturu.LoadKanturuMapAttr(gPath.GetFullPath("Terrain\\terrain40_CLOSE.att"),0);

	gKanturu.LoadKanturuMapAttr(gPath.GetFullPath("Terrain\\terrain40_OPEN.att"),1);
	#endif
}

void CServerInfo::ReadMonsterInfo() // OK
{
	#if(GAMESERVER_UPDATE>=201)
	gKanturuMonsterMng.Load(gPath.GetFullPath("Monster\\KanturuMonsterSetBase.txt"));
	#endif

	#if(GAMESERVER_UPDATE>=201)
	CMonsterAIAutomata::LoadData(gPath.GetFullPath("Monster\\MonsterAIAutomata.txt"));

	CMonsterAIElement::LoadData(gPath.GetFullPath("Monster\\MonsterAIElement.txt"));

	CMonsterAIGroup::LoadData(gPath.GetFullPath("Monster\\MonsterAIGroup.txt"));

	CMonsterAIRule::LoadData(gPath.GetFullPath("Monster\\MonsterAIRule.txt"));

	CMonsterAIUnit::LoadData(gPath.GetFullPath("Monster\\MonsterAIUnit.txt"));
	#endif

	gMonsterManager.Load(gPath.GetFullPath("Monster\\Monster.txt"));

	#if(GAMESERVER_UPDATE>=201)
	CMonsterSkillElement::LoadData(gPath.GetFullPath("Monster\\MonsterSkillElement.txt"));

	CMonsterSkillUnit::LoadData(gPath.GetFullPath("Monster\\MonsterSkillUnit.txt"));

	CMonsterSkillManager::LoadData(gPath.GetFullPath("Monster\\MonsterSkill.txt"));
	#endif

	LogAdd(LOG_BLUE,"[ServerInfo] Monster loaded successfully");
}

void CServerInfo::ReadMonsterSetBaseInfo()
{
	gMonsterSetBase.Load();

	LogAdd(LOG_BLUE, "[ServerInfo] MonsterSetBase loaded successfully");
}

void CServerInfo::ReadMoveInfo() // OK
{
	gGate.Load(gPath.GetFullPath("Move\\Gate.txt"));

	gMove.Load(gPath.GetFullPath("Move\\Move.txt"));

#if(GAMESERVER_UPDATE>=99)
	gMoveSummon.Load(gPath.GetFullPath("Move\\MoveSummon.txt"));
#endif

	LogAdd(LOG_BLUE,"[ServerInfo] Move loaded successfully");
}

void CServerInfo::ReadQuestInfo() // OK
{
	gQuest.Load(gPath.GetFullPath("Quest\\Quest.txt"));

	gQuestObjective.Load(gPath.GetFullPath("Quest\\QuestObjective.txt"));

	gQuestReward.Load(gPath.GetFullPath("Quest\\QuestReward.txt"));

	#if(GAMESERVER_UPDATE>=501)

	gQuestWorld.Load(gPath.GetFullPath("QuestWorld\\QuestWorld.txt"));

	gQuestWorldObjective.Load(gPath.GetFullPath("QuestWorld\\QuestWorldObjective.txt"));

	gQuestWorldReward.Load(gPath.GetFullPath("QuestWorld\\QuestWorldReward.txt"));

	#endif

	LogAdd(LOG_BLUE,"[ServerInfo] Quest loaded successfully");
}

void CServerInfo::ReadShopInfo() // OK
{
	#if(GAMESERVER_UPDATE>=250 && GAMESERVER_UPDATE<=402)
	gPcPoint.Load(gPath.GetFullPath("PcPoint.txt"));
	#endif

	gShopManager.Load(gPath.GetFullPath("ShopManager.txt"));

	gShopManager.LoadShop();

	gShopManager.ReloadShopInterface();

	LogAdd(LOG_BLUE,"[ServerInfo] Shop loaded successfully");
}

void CServerInfo::ReadSkillInfo() // OK
{
	this->ReadSkillInfo("GameServerInfo",".\\Data\\GameServerInfo - Skill.dat");

	#if(GAMESERVER_UPDATE>=401)

	gMasterSkillTree.Load(gPath.GetFullPath("Skill\\MasterSkillTree.txt"));

	#endif

	gSkillDamage.Load(gPath.GetFullPath("Skill\\SkillDamage.txt"));

	#if(GAMESERVER_UPDATE>=99)
	gSkillHitBox.Load(gPath.GetFullPath("Skill\\SkillElect.hit"));
	#endif

	gSkillManager.Load(gPath.GetFullPath("Skill\\Skill.txt"));

	LogAdd(LOG_BLUE,"[ServerInfo] Skill loaded successfully");
}

void CServerInfo::ReadUtilInfo() // OK
{
	gExperienceTable.Load(gPath.GetFullPath("Util\\ExperienceTable.txt"));

	#ifdef CUSTOM_GAMESERVER
	gZenTable.Load(gPath.GetFullPath("Util\\ZenTable.txt"));
	#endif

	gPKZone.Load(gPath.GetFullPath("Util\\PkZone.txt"));

	gFilter.Load(gPath.GetFullPath("Util\\Filter.txt"));

	LogAdd(LOG_BLUE,"[ServerInfo] Util loaded successfully");
}

void CServerInfo::ReloadMonsterInfo() // OK
{
	this->ReadMonsterInfo();
}

void CServerInfo::ReloadMonsterSetBaseInfo()
{
	for (int n = 0; n < MAX_OBJECT_MONSTER; n++)
	{
		if (gObj[n].Type != OBJECT_MONSTER && gObj[n].Type != OBJECT_NPC)
		{
			continue;
		}

#if(GAMESERVER_TYPE==1)

		if (gObj[n].CsNpcType != 0)
		{
			continue;
		}

#endif

		gObjDel(n);
	}

	gObjMonCount = 0;

#if(GAMESERVER_UPDATE>=201)
	gCrywolf.m_ObjCommonNPC.Reset();

	gCrywolf.m_ObjSpecialNPC.Reset();

	gCrywolf.m_ObjCommonMonster.Reset();

	gCrywolf.m_ObjSpecialMonster.Reset();
#endif

	gMonsterSetBase.Load();

	gMonsterManager.SetMonsterData();

	gLuaGameServer.MonsterReload();

	LogAdd(LOG_BLUE, "[ServerInfo] MonsterSetBase reloaded successfully");
}

void CServerInfo::ReloadMonsterMap(int map)
{
	static CCriticalSection m_locker;

	m_locker.lock();

	int CountReduce = 0;

	for (int n = 0; n < MAX_OBJECT_MONSTER; n++)
	{
		if (gObj[n].Type != OBJECT_MONSTER && gObj[n].Type != OBJECT_NPC)
		{
			continue;
		}

		if (gObj[n].Map != map || gObj[n].Connected == 0) {
			continue;
		}

#if(GAMESERVER_TYPE==1)
		if (gObj[n].CsNpcType != 0)
		{
			continue;
		}
#endif

		gObjDel(n);

		CountReduce++;
	}

	gObjMonCount -= CountReduce;

	gObjMonCount = (gObjMonCount < 0 ? 0 : gObjMonCount);

	gMonsterSetBase.Reload(map);

	gMonsterManager.SetMonsterDataMap(map);

	gLuaGameServer.MonsterReload();

	m_locker.unlock();

	LogAdd(LOG_BLUE, "[ServerInfo] MonsterSetBase (%d) reloaded successfully", map);
}

void CServerInfo::ReadStartupInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	GetPrivateProfileString(section,"UserEmail","",this->m_CustomerName,sizeof(this->m_CustomerName),path);

	GetPrivateProfileString(section,"ServerName","",this->m_ServerName,sizeof(this->m_ServerName),path);

	this->m_ServerCode = GetPrivateProfileInt(section,"ServerCode",0,path);

	this->m_ServerLock = GetPrivateProfileInt(section,"ServerLock",0,path);

	this->m_ServerPort = GetPrivateProfileInt(section,"ServerPort",0,path);

	wsprintf(this->m_ServerMutex,"WZ_MU_GS_MUTEX_%d",this->m_ServerCode);

	GetPrivateProfileString(section,"ServerVersion","",GameServerInfo,sizeof(GameServerInfo),path);

	gServerInfo.m_ServerVersion[0] = GameServerInfo[0];

	gServerInfo.m_ServerVersion[1] = GameServerInfo[2];

	gServerInfo.m_ServerVersion[2] = GameServerInfo[3];

	gServerInfo.m_ServerVersion[3] = GameServerInfo[5];

	gServerInfo.m_ServerVersion[4] = GameServerInfo[6];

	gServerInfo.m_ServerVersion[5] = 0;

	GetPrivateProfileString(section,"ServerSerial","",this->m_ServerSerial,sizeof(this->m_ServerSerial),path);

	this->m_ServerMaxUserNumber = GetPrivateProfileInt(section,"ServerMaxUserNumber",0,path);

	this->m_ServerMaxUserNumber = ((this->m_ServerMaxUserNumber>MAX_OBJECT_USER)?MAX_OBJECT_USER:this->m_ServerMaxUserNumber);

	GetPrivateProfileString(section,"DataServerAddress","",this->m_DataServerAddress,sizeof(this->m_DataServerAddress),path);

	this->m_DataServerPort = GetPrivateProfileInt(section,"DataServerPort",0,path);

	GetPrivateProfileString(section,"JoinServerAddress","",this->m_JoinServerAddress,sizeof(this->m_JoinServerAddress),path);

	this->m_JoinServerPort = GetPrivateProfileInt(section,"JoinServerPort",0,path);

	GetPrivateProfileString(section,"ConnectServerAddress","",this->m_ConnectServerAddress,sizeof(this->m_ConnectServerAddress),path);

	this->m_ConnectServerPort = GetPrivateProfileInt(section,"ConnectServerPort",0,path);

	this->m_WriteChatLog = GetPrivateProfileInt(section,"WriteChatLog",0,path);

	this->m_WriteTradeLog = GetPrivateProfileInt(section,"WriteTradeLog",0,path);

	this->m_WriteConnectLog = GetPrivateProfileInt(section,"WriteConnectLog",0,path);

	this->m_WriteHackLog = GetPrivateProfileInt(section,"WriteHackLog",0,path);

	this->m_WriteCashShopLog = GetPrivateProfileInt(section,"WriteCashShopLog",0,path);

	this->m_WriteChaosMixLog = GetPrivateProfileInt(section,"WriteChaosMixLog",0,path);

	this->m_WriteSkillHackLog = GetPrivateProfileInt(section, "WriteSkillHackLog", 0, path);

	this->m_WriteInventoryLog = GetPrivateProfileInt(section, "WriteInventoryLog", 0, path);

	this->m_WriteWarehouseLog = GetPrivateProfileInt(section, "WriteWarehouseLog", 0, path);

	this->m_WriteTradeXLog = GetPrivateProfileInt(section, "WriteTradeXLog", 0, path);
}

void CServerInfo::ReadCashShopInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	#if(GAMESERVER_UPDATE>=501)

	this->m_CashShopSwitch = GetPrivateProfileInt(section,"CashShopSwitch",0,path);

	this->m_CashShopScriptVersion1 = GetPrivateProfileInt(section,"CashShopScriptVersion1",0,path);

	this->m_CashShopScriptVersion2 = GetPrivateProfileInt(section,"CashShopScriptVersion2",0,path);

	this->m_CashShopScriptVersion3 = GetPrivateProfileInt(section,"CashShopScriptVersion3",0,path);

	this->m_CashShopBannerVersion1 = GetPrivateProfileInt(section,"CashShopBannerVersion1",0,path);

	this->m_CashShopBannerVersion2 = GetPrivateProfileInt(section,"CashShopBannerVersion2",0,path);

	this->m_CashShopBannerVersion3 = GetPrivateProfileInt(section,"CashShopBannerVersion3",0,path);

	this->m_CashShopGoblinPointDelay = GetPrivateProfileInt(section,"CashShopGoblinPointDelay",0,path);

	this->m_CashShopGoblinPointValue[0] = GetPrivateProfileInt(section,"CashShopGoblinPointValue_FREE",0,path);

	this->m_CashShopGoblinPointValue[1] = GetPrivateProfileInt(section,"CashShopGoblinPointValue_VIP1",0,path);

	this->m_CashShopGoblinPointValue[2] = GetPrivateProfileInt(section,"CashShopGoblinPointValue_VIP2",0,path);

	this->m_CashShopGoblinPointValue[3] = GetPrivateProfileInt(section,"CashShopGoblinPointValue_VIP3",0,path);

	#endif
}

void CServerInfo::ReadChaosMixInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	this->m_ChaosItemMixRate[0] = GetPrivateProfileInt(section,"ChaosItemMixRate_FREE",0,path);

	this->m_ChaosItemMixRate[1] = GetPrivateProfileInt(section,"ChaosItemMixRate_VIP1",0,path);

	this->m_ChaosItemMixRate[2] = GetPrivateProfileInt(section,"ChaosItemMixRate_VIP2",0,path);

	this->m_ChaosItemMixRate[3] = GetPrivateProfileInt(section,"ChaosItemMixRate_VIP3",0,path);

	this->m_DevilSquareMixRate1[0] = GetPrivateProfileInt(section,"DevilSquareMixRate1_FREE",0,path);

	this->m_DevilSquareMixRate1[1] = GetPrivateProfileInt(section,"DevilSquareMixRate1_VIP1",0,path);

	this->m_DevilSquareMixRate1[2] = GetPrivateProfileInt(section,"DevilSquareMixRate1_VIP2",0,path);

	this->m_DevilSquareMixRate1[3] = GetPrivateProfileInt(section,"DevilSquareMixRate1_VIP3",0,path);

	this->m_DevilSquareMixRate2[0] = GetPrivateProfileInt(section,"DevilSquareMixRate2_FREE",0,path);

	this->m_DevilSquareMixRate2[1] = GetPrivateProfileInt(section,"DevilSquareMixRate2_VIP1",0,path);

	this->m_DevilSquareMixRate2[2] = GetPrivateProfileInt(section,"DevilSquareMixRate2_VIP2",0,path);

	this->m_DevilSquareMixRate2[3] = GetPrivateProfileInt(section,"DevilSquareMixRate2_VIP3",0,path);

	this->m_DevilSquareMixRate3[0] = GetPrivateProfileInt(section,"DevilSquareMixRate3_FREE",0,path);

	this->m_DevilSquareMixRate3[1] = GetPrivateProfileInt(section,"DevilSquareMixRate3_VIP1",0,path);

	this->m_DevilSquareMixRate3[2] = GetPrivateProfileInt(section,"DevilSquareMixRate3_VIP2",0,path);

	this->m_DevilSquareMixRate3[3] = GetPrivateProfileInt(section,"DevilSquareMixRate3_VIP3",0,path);

	this->m_DevilSquareMixRate4[0] = GetPrivateProfileInt(section,"DevilSquareMixRate4_FREE",0,path);

	this->m_DevilSquareMixRate4[1] = GetPrivateProfileInt(section,"DevilSquareMixRate4_VIP1",0,path);

	this->m_DevilSquareMixRate4[2] = GetPrivateProfileInt(section,"DevilSquareMixRate4_VIP2",0,path);

	this->m_DevilSquareMixRate4[3] = GetPrivateProfileInt(section,"DevilSquareMixRate4_VIP3",0,path);

	this->m_DevilSquareMixRate5[0] = GetPrivateProfileInt(section,"DevilSquareMixRate5_FREE",0,path);

	this->m_DevilSquareMixRate5[1] = GetPrivateProfileInt(section,"DevilSquareMixRate5_VIP1",0,path);

	this->m_DevilSquareMixRate5[2] = GetPrivateProfileInt(section,"DevilSquareMixRate5_VIP2",0,path);

	this->m_DevilSquareMixRate5[3] = GetPrivateProfileInt(section,"DevilSquareMixRate5_VIP3",0,path);

	this->m_DevilSquareMixRate6[0] = GetPrivateProfileInt(section,"DevilSquareMixRate6_FREE",0,path);

	this->m_DevilSquareMixRate6[1] = GetPrivateProfileInt(section,"DevilSquareMixRate6_VIP1",0,path);

	this->m_DevilSquareMixRate6[2] = GetPrivateProfileInt(section,"DevilSquareMixRate6_VIP2",0,path);

	this->m_DevilSquareMixRate6[3] = GetPrivateProfileInt(section,"DevilSquareMixRate6_VIP3",0,path);

	this->m_DevilSquareMixRate7[0] = GetPrivateProfileInt(section,"DevilSquareMixRate7_FREE",0,path);

	this->m_DevilSquareMixRate7[1] = GetPrivateProfileInt(section,"DevilSquareMixRate7_VIP1",0,path);

	this->m_DevilSquareMixRate7[2] = GetPrivateProfileInt(section,"DevilSquareMixRate7_VIP2",0,path);

	this->m_DevilSquareMixRate7[3] = GetPrivateProfileInt(section,"DevilSquareMixRate7_VIP3",0,path);

	this->m_PlusItemLevelMixRate1[0] = GetPrivateProfileInt(section,"PlusItemLevelMixRate1_FREE",0,path);

	this->m_PlusItemLevelMixRate1[1] = GetPrivateProfileInt(section,"PlusItemLevelMixRate1_VIP1",0,path);

	this->m_PlusItemLevelMixRate1[2] = GetPrivateProfileInt(section,"PlusItemLevelMixRate1_VIP2",0,path);

	this->m_PlusItemLevelMixRate1[3] = GetPrivateProfileInt(section,"PlusItemLevelMixRate1_VIP3",0,path);

	this->m_PlusItemLevelMixRate2[0] = GetPrivateProfileInt(section,"PlusItemLevelMixRate2_FREE",0,path);

	this->m_PlusItemLevelMixRate2[1] = GetPrivateProfileInt(section,"PlusItemLevelMixRate2_VIP1",0,path);

	this->m_PlusItemLevelMixRate2[2] = GetPrivateProfileInt(section,"PlusItemLevelMixRate2_VIP2",0,path);

	this->m_PlusItemLevelMixRate2[3] = GetPrivateProfileInt(section,"PlusItemLevelMixRate2_VIP3",0,path);

	this->m_PlusItemLevelMixRate3[0] = GetPrivateProfileInt(section,"PlusItemLevelMixRate3_FREE",0,path);

	this->m_PlusItemLevelMixRate3[1] = GetPrivateProfileInt(section,"PlusItemLevelMixRate3_VIP1",0,path);

	this->m_PlusItemLevelMixRate3[2] = GetPrivateProfileInt(section,"PlusItemLevelMixRate3_VIP2",0,path);

	this->m_PlusItemLevelMixRate3[3] = GetPrivateProfileInt(section,"PlusItemLevelMixRate3_VIP3",0,path);

	this->m_PlusItemLevelMixRate4[0] = GetPrivateProfileInt(section,"PlusItemLevelMixRate4_FREE",0,path);

	this->m_PlusItemLevelMixRate4[1] = GetPrivateProfileInt(section,"PlusItemLevelMixRate4_VIP1",0,path);

	this->m_PlusItemLevelMixRate4[2] = GetPrivateProfileInt(section,"PlusItemLevelMixRate4_VIP2",0,path);

	this->m_PlusItemLevelMixRate4[3] = GetPrivateProfileInt(section,"PlusItemLevelMixRate4_VIP3",0,path);

	#if(GAMESERVER_UPDATE>=501)

	this->m_PlusItemLevelMixRate5[0] = GetPrivateProfileInt(section,"PlusItemLevelMixRate5_FREE",0,path);

	this->m_PlusItemLevelMixRate5[1] = GetPrivateProfileInt(section,"PlusItemLevelMixRate5_VIP1",0,path);

	this->m_PlusItemLevelMixRate5[2] = GetPrivateProfileInt(section,"PlusItemLevelMixRate5_VIP2",0,path);

	this->m_PlusItemLevelMixRate5[3] = GetPrivateProfileInt(section,"PlusItemLevelMixRate5_VIP3",0,path);

	this->m_PlusItemLevelMixRate6[0] = GetPrivateProfileInt(section,"PlusItemLevelMixRate6_FREE",0,path);

	this->m_PlusItemLevelMixRate6[1] = GetPrivateProfileInt(section,"PlusItemLevelMixRate6_VIP1",0,path);

	this->m_PlusItemLevelMixRate6[2] = GetPrivateProfileInt(section,"PlusItemLevelMixRate6_VIP2",0,path);

	this->m_PlusItemLevelMixRate6[3] = GetPrivateProfileInt(section,"PlusItemLevelMixRate6_VIP3",0,path);

	#endif

	this->m_DinorantMixRate[0] = GetPrivateProfileInt(section,"DinorantMixRate_FREE",0,path);

	this->m_DinorantMixRate[1] = GetPrivateProfileInt(section,"DinorantMixRate_VIP1",0,path);

	this->m_DinorantMixRate[2] = GetPrivateProfileInt(section,"DinorantMixRate_VIP2",0,path);

	this->m_DinorantMixRate[3] = GetPrivateProfileInt(section,"DinorantMixRate_VIP3",0,path);

	this->m_FruitMixRate[0] = GetPrivateProfileInt(section,"FruitMixRate_FREE",0,path);

	this->m_FruitMixRate[1] = GetPrivateProfileInt(section,"FruitMixRate_VIP1",0,path);

	this->m_FruitMixRate[2] = GetPrivateProfileInt(section,"FruitMixRate_VIP2",0,path);

	this->m_FruitMixRate[3] = GetPrivateProfileInt(section,"FruitMixRate_VIP3",0,path);

	this->m_Wing2MixRate[0] = GetPrivateProfileInt(section,"Wing2MixRate_FREE",0,path);

	this->m_Wing2MixRate[1] = GetPrivateProfileInt(section,"Wing2MixRate_VIP1",0,path);

	this->m_Wing2MixRate[2] = GetPrivateProfileInt(section,"Wing2MixRate_VIP2",0,path);

	this->m_Wing2MixRate[3] = GetPrivateProfileInt(section,"Wing2MixRate_VIP3",0,path);

	this->m_BloodCastleMixRate1[0] = GetPrivateProfileInt(section,"BloodCastleMixRate1_FREE",0,path);

	this->m_BloodCastleMixRate1[1] = GetPrivateProfileInt(section,"BloodCastleMixRate1_VIP1",0,path);

	this->m_BloodCastleMixRate1[2] = GetPrivateProfileInt(section,"BloodCastleMixRate1_VIP2",0,path);

	this->m_BloodCastleMixRate1[3] = GetPrivateProfileInt(section,"BloodCastleMixRate1_VIP3",0,path);

	this->m_BloodCastleMixRate2[0] = GetPrivateProfileInt(section,"BloodCastleMixRate2_FREE",0,path);

	this->m_BloodCastleMixRate2[1] = GetPrivateProfileInt(section,"BloodCastleMixRate2_VIP1",0,path);

	this->m_BloodCastleMixRate2[2] = GetPrivateProfileInt(section,"BloodCastleMixRate2_VIP2",0,path);

	this->m_BloodCastleMixRate2[3] = GetPrivateProfileInt(section,"BloodCastleMixRate2_VIP3",0,path);

	this->m_BloodCastleMixRate3[0] = GetPrivateProfileInt(section,"BloodCastleMixRate3_FREE",0,path);

	this->m_BloodCastleMixRate3[1] = GetPrivateProfileInt(section,"BloodCastleMixRate3_VIP1",0,path);

	this->m_BloodCastleMixRate3[2] = GetPrivateProfileInt(section,"BloodCastleMixRate3_VIP2",0,path);

	this->m_BloodCastleMixRate3[3] = GetPrivateProfileInt(section,"BloodCastleMixRate3_VIP3",0,path);

	this->m_BloodCastleMixRate4[0] = GetPrivateProfileInt(section,"BloodCastleMixRate4_FREE",0,path);

	this->m_BloodCastleMixRate4[1] = GetPrivateProfileInt(section,"BloodCastleMixRate4_VIP1",0,path);

	this->m_BloodCastleMixRate4[2] = GetPrivateProfileInt(section,"BloodCastleMixRate4_VIP2",0,path);

	this->m_BloodCastleMixRate4[3] = GetPrivateProfileInt(section,"BloodCastleMixRate4_VIP3",0,path);

	this->m_BloodCastleMixRate5[0] = GetPrivateProfileInt(section,"BloodCastleMixRate5_FREE",0,path);

	this->m_BloodCastleMixRate5[1] = GetPrivateProfileInt(section,"BloodCastleMixRate5_VIP1",0,path);

	this->m_BloodCastleMixRate5[2] = GetPrivateProfileInt(section,"BloodCastleMixRate5_VIP2",0,path);

	this->m_BloodCastleMixRate5[3] = GetPrivateProfileInt(section,"BloodCastleMixRate5_VIP3",0,path);

	this->m_BloodCastleMixRate6[0] = GetPrivateProfileInt(section,"BloodCastleMixRate6_FREE",0,path);

	this->m_BloodCastleMixRate6[1] = GetPrivateProfileInt(section,"BloodCastleMixRate6_VIP1",0,path);

	this->m_BloodCastleMixRate6[2] = GetPrivateProfileInt(section,"BloodCastleMixRate6_VIP2",0,path);

	this->m_BloodCastleMixRate6[3] = GetPrivateProfileInt(section,"BloodCastleMixRate6_VIP3",0,path);

	this->m_BloodCastleMixRate7[0] = GetPrivateProfileInt(section,"BloodCastleMixRate7_FREE",0,path);

	this->m_BloodCastleMixRate7[1] = GetPrivateProfileInt(section,"BloodCastleMixRate7_VIP1",0,path);

	this->m_BloodCastleMixRate7[2] = GetPrivateProfileInt(section,"BloodCastleMixRate7_VIP2",0,path);

	this->m_BloodCastleMixRate7[3] = GetPrivateProfileInt(section,"BloodCastleMixRate7_VIP3",0,path);

	this->m_BloodCastleMixRate8[0] = GetPrivateProfileInt(section,"BloodCastleMixRate8_FREE",0,path);

	this->m_BloodCastleMixRate8[1] = GetPrivateProfileInt(section,"BloodCastleMixRate8_VIP1",0,path);

	this->m_BloodCastleMixRate8[2] = GetPrivateProfileInt(section,"BloodCastleMixRate8_VIP2",0,path);

	this->m_BloodCastleMixRate8[3] = GetPrivateProfileInt(section,"BloodCastleMixRate8_VIP3",0,path);

	this->m_Wing1MixRate[0] = GetPrivateProfileInt(section,"Wing1MixRate_FREE",0,path);

	this->m_Wing1MixRate[1] = GetPrivateProfileInt(section,"Wing1MixRate_VIP1",0,path);

	this->m_Wing1MixRate[2] = GetPrivateProfileInt(section,"Wing1MixRate_VIP2",0,path);

	this->m_Wing1MixRate[3] = GetPrivateProfileInt(section,"Wing1MixRate_VIP3",0,path);

	this->m_PetMixRate[0] = GetPrivateProfileInt(section,"PetMixRate_FREE",0,path);

	this->m_PetMixRate[1] = GetPrivateProfileInt(section,"PetMixRate_VIP1",0,path);

	this->m_PetMixRate[2] = GetPrivateProfileInt(section,"PetMixRate_VIP2",0,path);

	this->m_PetMixRate[3] = GetPrivateProfileInt(section,"PetMixRate_VIP3",0,path);

	this->m_PieceOfHornMixRate[0] = GetPrivateProfileInt(section,"PieceOfHornMixRate_FREE",0,path);

	this->m_PieceOfHornMixRate[1] = GetPrivateProfileInt(section,"PieceOfHornMixRate_VIP1",0,path);

	this->m_PieceOfHornMixRate[2] = GetPrivateProfileInt(section,"PieceOfHornMixRate_VIP2",0,path);

	this->m_PieceOfHornMixRate[3] = GetPrivateProfileInt(section,"PieceOfHornMixRate_VIP3",0,path);

	this->m_BrokenHornMixRate[0] = GetPrivateProfileInt(section,"BrokenHornMixRate_FREE",0,path);

	this->m_BrokenHornMixRate[1] = GetPrivateProfileInt(section,"BrokenHornMixRate_VIP1",0,path);

	this->m_BrokenHornMixRate[2] = GetPrivateProfileInt(section,"BrokenHornMixRate_VIP2",0,path);

	this->m_BrokenHornMixRate[3] = GetPrivateProfileInt(section,"BrokenHornMixRate_VIP3",0,path);

	this->m_HornOfFenrirMixRate[0] = GetPrivateProfileInt(section,"HornOfFenrirMixRate_FREE",0,path);

	this->m_HornOfFenrirMixRate[1] = GetPrivateProfileInt(section,"HornOfFenrirMixRate_VIP1",0,path);

	this->m_HornOfFenrirMixRate[2] = GetPrivateProfileInt(section,"HornOfFenrirMixRate_VIP2",0,path);

	this->m_HornOfFenrirMixRate[3] = GetPrivateProfileInt(section,"HornOfFenrirMixRate_VIP3",0,path);

	this->m_HornOfFenrirUpgradeMixRate[0] = GetPrivateProfileInt(section,"HornOfFenrirUpgradeMixRate_FREE",0,path);

	this->m_HornOfFenrirUpgradeMixRate[1] = GetPrivateProfileInt(section,"HornOfFenrirUpgradeMixRate_VIP1",0,path);

	this->m_HornOfFenrirUpgradeMixRate[2] = GetPrivateProfileInt(section,"HornOfFenrirUpgradeMixRate_VIP2",0,path);

	this->m_HornOfFenrirUpgradeMixRate[3] = GetPrivateProfileInt(section,"HornOfFenrirUpgradeMixRate_VIP3",0,path);

	this->m_ShieldPotionMixRate1[0] = GetPrivateProfileInt(section,"ShieldPotionMixRate1_FREE",0,path);

	this->m_ShieldPotionMixRate1[1] = GetPrivateProfileInt(section,"ShieldPotionMixRate1_VIP1",0,path);

	this->m_ShieldPotionMixRate1[2] = GetPrivateProfileInt(section,"ShieldPotionMixRate1_VIP2",0,path);

	this->m_ShieldPotionMixRate1[3] = GetPrivateProfileInt(section,"ShieldPotionMixRate1_VIP3",0,path);

	this->m_ShieldPotionMixRate2[0] = GetPrivateProfileInt(section,"ShieldPotionMixRate2_FREE",0,path);

	this->m_ShieldPotionMixRate2[1] = GetPrivateProfileInt(section,"ShieldPotionMixRate2_VIP1",0,path);

	this->m_ShieldPotionMixRate2[2] = GetPrivateProfileInt(section,"ShieldPotionMixRate2_VIP2",0,path);

	this->m_ShieldPotionMixRate2[3] = GetPrivateProfileInt(section,"ShieldPotionMixRate2_VIP3",0,path);

	this->m_ShieldPotionMixRate3[0] = GetPrivateProfileInt(section,"ShieldPotionMixRate3_FREE",0,path);

	this->m_ShieldPotionMixRate3[1] = GetPrivateProfileInt(section,"ShieldPotionMixRate3_VIP1",0,path);

	this->m_ShieldPotionMixRate3[2] = GetPrivateProfileInt(section,"ShieldPotionMixRate3_VIP2",0,path);

	this->m_ShieldPotionMixRate3[3] = GetPrivateProfileInt(section,"ShieldPotionMixRate3_VIP3",0,path);

	this->m_JewelOfHarmonyItemPurityMixRate[0] = GetPrivateProfileInt(section,"JewelOfHarmonyItemPurityMixRate_FREE",0,path);

	this->m_JewelOfHarmonyItemPurityMixRate[1] = GetPrivateProfileInt(section,"JewelOfHarmonyItemPurityMixRate_VIP1",0,path);

	this->m_JewelOfHarmonyItemPurityMixRate[2] = GetPrivateProfileInt(section,"JewelOfHarmonyItemPurityMixRate_VIP2",0,path);

	this->m_JewelOfHarmonyItemPurityMixRate[3] = GetPrivateProfileInt(section,"JewelOfHarmonyItemPurityMixRate_VIP3",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate1[0] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate1_FREE",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate1[1] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate1_VIP1",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate1[2] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate1_VIP2",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate1[3] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate1_VIP3",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate2[0] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate2_FREE",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate2[1] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate2_VIP1",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate2[2] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate2_VIP2",0,path);

	this->m_JewelOfHarmonyItemSmeltMixRate2[3] = GetPrivateProfileInt(section,"JewelOfHarmonyItemSmeltMixRate2_VIP3",0,path);

	this->m_JewelOfHarmonyItemRestoreMixRate[0] = GetPrivateProfileInt(section,"JewelOfHarmonyItemRestoreMixRate_FREE",0,path);

	this->m_JewelOfHarmonyItemRestoreMixRate[1] = GetPrivateProfileInt(section,"JewelOfHarmonyItemRestoreMixRate_VIP1",0,path);

	this->m_JewelOfHarmonyItemRestoreMixRate[2] = GetPrivateProfileInt(section,"JewelOfHarmonyItemRestoreMixRate_VIP2",0,path);

	this->m_JewelOfHarmonyItemRestoreMixRate[3] = GetPrivateProfileInt(section,"JewelOfHarmonyItemRestoreMixRate_VIP3",0,path);

	this->m_Item380MixRate1[0] = GetPrivateProfileInt(section,"Item380MixRate1_FREE",0,path);

	this->m_Item380MixRate1[1] = GetPrivateProfileInt(section,"Item380MixRate1_VIP1",0,path);

	this->m_Item380MixRate1[2] = GetPrivateProfileInt(section,"Item380MixRate1_VIP2",0,path);

	this->m_Item380MixRate1[3] = GetPrivateProfileInt(section,"Item380MixRate1_VIP3",0,path);

	this->m_Item380MixRate2[0] = GetPrivateProfileInt(section,"Item380MixRate2_FREE",0,path);

	this->m_Item380MixRate2[1] = GetPrivateProfileInt(section,"Item380MixRate2_VIP1",0,path);

	this->m_Item380MixRate2[2] = GetPrivateProfileInt(section,"Item380MixRate2_VIP2",0,path);

	this->m_Item380MixRate2[3] = GetPrivateProfileInt(section,"Item380MixRate2_VIP3",0,path);

	this->m_IllusionTempleMixRate1[0] = GetPrivateProfileInt(section,"IllusionTempleMixRate1_FREE",0,path);

	this->m_IllusionTempleMixRate1[1] = GetPrivateProfileInt(section,"IllusionTempleMixRate1_VIP1",0,path);

	this->m_IllusionTempleMixRate1[2] = GetPrivateProfileInt(section,"IllusionTempleMixRate1_VIP2",0,path);

	this->m_IllusionTempleMixRate1[3] = GetPrivateProfileInt(section,"IllusionTempleMixRate1_VIP3",0,path);

	this->m_IllusionTempleMixRate2[0] = GetPrivateProfileInt(section,"IllusionTempleMixRate2_FREE",0,path);

	this->m_IllusionTempleMixRate2[1] = GetPrivateProfileInt(section,"IllusionTempleMixRate2_VIP1",0,path);

	this->m_IllusionTempleMixRate2[2] = GetPrivateProfileInt(section,"IllusionTempleMixRate2_VIP2",0,path);

	this->m_IllusionTempleMixRate2[3] = GetPrivateProfileInt(section,"IllusionTempleMixRate2_VIP3",0,path);

	this->m_IllusionTempleMixRate3[0] = GetPrivateProfileInt(section,"IllusionTempleMixRate3_FREE",0,path);

	this->m_IllusionTempleMixRate3[1] = GetPrivateProfileInt(section,"IllusionTempleMixRate3_VIP1",0,path);

	this->m_IllusionTempleMixRate3[2] = GetPrivateProfileInt(section,"IllusionTempleMixRate3_VIP2",0,path);

	this->m_IllusionTempleMixRate3[3] = GetPrivateProfileInt(section,"IllusionTempleMixRate3_VIP3",0,path);

	this->m_IllusionTempleMixRate4[0] = GetPrivateProfileInt(section,"IllusionTempleMixRate4_FREE",0,path);

	this->m_IllusionTempleMixRate4[1] = GetPrivateProfileInt(section,"IllusionTempleMixRate4_VIP1",0,path);

	this->m_IllusionTempleMixRate4[2] = GetPrivateProfileInt(section,"IllusionTempleMixRate4_VIP2",0,path);

	this->m_IllusionTempleMixRate4[3] = GetPrivateProfileInt(section,"IllusionTempleMixRate4_VIP3",0,path);

	this->m_IllusionTempleMixRate5[0] = GetPrivateProfileInt(section,"IllusionTempleMixRate5_FREE",0,path);

	this->m_IllusionTempleMixRate5[1] = GetPrivateProfileInt(section,"IllusionTempleMixRate5_VIP1",0,path);

	this->m_IllusionTempleMixRate5[2] = GetPrivateProfileInt(section,"IllusionTempleMixRate5_VIP2",0,path);

	this->m_IllusionTempleMixRate5[3] = GetPrivateProfileInt(section,"IllusionTempleMixRate5_VIP3",0,path);

	this->m_IllusionTempleMixRate6[0] = GetPrivateProfileInt(section,"IllusionTempleMixRate6_FREE",0,path);

	this->m_IllusionTempleMixRate6[1] = GetPrivateProfileInt(section,"IllusionTempleMixRate6_VIP1",0,path);

	this->m_IllusionTempleMixRate6[2] = GetPrivateProfileInt(section,"IllusionTempleMixRate6_VIP2",0,path);

	this->m_IllusionTempleMixRate6[3] = GetPrivateProfileInt(section,"IllusionTempleMixRate6_VIP3",0,path);

	this->m_FeatherOfCondorMixRate[0] = GetPrivateProfileInt(section,"FeatherOfCondorMixRate_FREE",0,path);

	this->m_FeatherOfCondorMixRate[1] = GetPrivateProfileInt(section,"FeatherOfCondorMixRate_VIP1",0,path);

	this->m_FeatherOfCondorMixRate[2] = GetPrivateProfileInt(section,"FeatherOfCondorMixRate_VIP2",0,path);

	this->m_FeatherOfCondorMixRate[3] = GetPrivateProfileInt(section,"FeatherOfCondorMixRate_VIP3",0,path);

	this->m_Wing3MixRate[0] = GetPrivateProfileInt(section,"Wing3MixRate_FREE",0,path);

	this->m_Wing3MixRate[1] = GetPrivateProfileInt(section,"Wing3MixRate_VIP1",0,path);

	this->m_Wing3MixRate[2] = GetPrivateProfileInt(section,"Wing3MixRate_VIP2",0,path);

	this->m_Wing3MixRate[3] = GetPrivateProfileInt(section,"Wing3MixRate_VIP3",0,path);

	#if(GAMESERVER_UPDATE>=401)

	this->m_SocketItemCreateSeedMixRate[0] = GetPrivateProfileInt(section,"SocketItemCreateSeedMixRate_FREE",0,path);

	this->m_SocketItemCreateSeedMixRate[1] = GetPrivateProfileInt(section,"SocketItemCreateSeedMixRate_VIP1",0,path);

	this->m_SocketItemCreateSeedMixRate[2] = GetPrivateProfileInt(section,"SocketItemCreateSeedMixRate_VIP2",0,path);

	this->m_SocketItemCreateSeedMixRate[3] = GetPrivateProfileInt(section,"SocketItemCreateSeedMixRate_VIP3",0,path);

	this->m_SocketItemCreateSeedSphereMixRate[0] = GetPrivateProfileInt(section,"SocketItemCreateSeedSphereMixRate_FREE",0,path);

	this->m_SocketItemCreateSeedSphereMixRate[1] = GetPrivateProfileInt(section,"SocketItemCreateSeedSphereMixRate_VIP1",0,path);

	this->m_SocketItemCreateSeedSphereMixRate[2] = GetPrivateProfileInt(section,"SocketItemCreateSeedSphereMixRate_VIP2",0,path);

	this->m_SocketItemCreateSeedSphereMixRate[3] = GetPrivateProfileInt(section,"SocketItemCreateSeedSphereMixRate_VIP3",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=801)

	this->m_SummonScrollMixRate1[0] = GetPrivateProfileInt(section,"SummonScrollMixRate1_FREE",0,path);

	this->m_SummonScrollMixRate1[1] = GetPrivateProfileInt(section,"SummonScrollMixRate1_VIP1",0,path);

	this->m_SummonScrollMixRate1[2] = GetPrivateProfileInt(section,"SummonScrollMixRate1_VIP2",0,path);

	this->m_SummonScrollMixRate1[3] = GetPrivateProfileInt(section,"SummonScrollMixRate1_VIP3",0,path);

	this->m_SummonScrollMixRate2[0] = GetPrivateProfileInt(section,"SummonScrollMixRate2_FREE",0,path);

	this->m_SummonScrollMixRate2[1] = GetPrivateProfileInt(section,"SummonScrollMixRate2_VIP1",0,path);

	this->m_SummonScrollMixRate2[2] = GetPrivateProfileInt(section,"SummonScrollMixRate2_VIP2",0,path);

	this->m_SummonScrollMixRate2[3] = GetPrivateProfileInt(section,"SummonScrollMixRate2_VIP3",0,path);

	this->m_SummonScrollMixRate3[0] = GetPrivateProfileInt(section,"SummonScrollMixRate3_FREE",0,path);

	this->m_SummonScrollMixRate3[1] = GetPrivateProfileInt(section,"SummonScrollMixRate3_VIP1",0,path);

	this->m_SummonScrollMixRate3[2] = GetPrivateProfileInt(section,"SummonScrollMixRate3_VIP2",0,path);

	this->m_SummonScrollMixRate3[3] = GetPrivateProfileInt(section,"SummonScrollMixRate3_VIP3",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=602)

	this->m_LuckyItemRefineMixRate1[0] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate1_FREE",0,path);

	this->m_LuckyItemRefineMixRate1[1] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate1_VIP1",0,path);

	this->m_LuckyItemRefineMixRate1[2] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate1_VIP2",0,path);

	this->m_LuckyItemRefineMixRate1[3] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate1_VIP3",0,path);

	this->m_LuckyItemRefineMixRate2[0] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate2_FREE",0,path);

	this->m_LuckyItemRefineMixRate2[1] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate2_VIP1",0,path);

	this->m_LuckyItemRefineMixRate2[2] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate2_VIP2",0,path);

	this->m_LuckyItemRefineMixRate2[3] = GetPrivateProfileInt(section,"LuckyItemRefineMixRate2_VIP3",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=701)

	this->m_MonsterWingMixRate[0] = GetPrivateProfileInt(section,"MonsterWingMixRate_FREE",0,path);

	this->m_MonsterWingMixRate[1] = GetPrivateProfileInt(section,"MonsterWingMixRate_VIP1",0,path);

	this->m_MonsterWingMixRate[2] = GetPrivateProfileInt(section,"MonsterWingMixRate_VIP2",0,path);

	this->m_MonsterWingMixRate[3] = GetPrivateProfileInt(section,"MonsterWingMixRate_VIP3",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=701)

	this->m_SocketWeaponMixRate[0] = GetPrivateProfileInt(section,"SocketWeaponMixRate_FREE",0,path);

	this->m_SocketWeaponMixRate[1] = GetPrivateProfileInt(section,"SocketWeaponMixRate_VIP1",0,path);

	this->m_SocketWeaponMixRate[2] = GetPrivateProfileInt(section,"SocketWeaponMixRate_VIP2",0,path);

	this->m_SocketWeaponMixRate[3] = GetPrivateProfileInt(section,"SocketWeaponMixRate_VIP3",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=701)

	this->m_PentagramMithrilMixRate[0] = GetPrivateProfileInt(section,"PentagramMithrilMixRate_FREE",0,path);

	this->m_PentagramMithrilMixRate[1] = GetPrivateProfileInt(section,"PentagramMithrilMixRate_VIP1",0,path);

	this->m_PentagramMithrilMixRate[2] = GetPrivateProfileInt(section,"PentagramMithrilMixRate_VIP2",0,path);

	this->m_PentagramMithrilMixRate[3] = GetPrivateProfileInt(section,"PentagramMithrilMixRate_VIP3",0,path);

	this->m_PentagramElixirMixRate[0] = GetPrivateProfileInt(section,"PentagramElixirMixRate_FREE",0,path);

	this->m_PentagramElixirMixRate[1] = GetPrivateProfileInt(section,"PentagramElixirMixRate_VIP1",0,path);

	this->m_PentagramElixirMixRate[2] = GetPrivateProfileInt(section,"PentagramElixirMixRate_VIP2",0,path);

	this->m_PentagramElixirMixRate[3] = GetPrivateProfileInt(section,"PentagramElixirMixRate_VIP3",0,path);

	this->m_PentagramJewelMixRate[0] = GetPrivateProfileInt(section,"PentagramJewelMixRate_FREE",0,path);

	this->m_PentagramJewelMixRate[1] = GetPrivateProfileInt(section,"PentagramJewelMixRate_VIP1",0,path);

	this->m_PentagramJewelMixRate[2] = GetPrivateProfileInt(section,"PentagramJewelMixRate_VIP2",0,path);

	this->m_PentagramJewelMixRate[3] = GetPrivateProfileInt(section,"PentagramJewelMixRate_VIP3",0,path);

	this->m_PentagramDecompositeMixRate[0] = GetPrivateProfileInt(section,"PentagramDecompositeMixRate_FREE",0,path);

	this->m_PentagramDecompositeMixRate[1] = GetPrivateProfileInt(section,"PentagramDecompositeMixRate_VIP1",0,path);

	this->m_PentagramDecompositeMixRate[2] = GetPrivateProfileInt(section,"PentagramDecompositeMixRate_VIP2",0,path);

	this->m_PentagramDecompositeMixRate[3] = GetPrivateProfileInt(section,"PentagramDecompositeMixRate_VIP3",0,path);

	#endif
}

void CServerInfo::ReadCharacterInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	this->m_DuelDamageRate = GetPrivateProfileInt(section,"DuelDamageRate",0,path);

	#if(GAMESERVER_UPDATE>=501)

	this->m_GensDamageRate = GetPrivateProfileInt(section,"GensDamageRate",0,path);

	#endif

	this->m_CustomArenaDamageRate = GetPrivateProfileInt(section,"CustomArenaDamageRate",0,path);

	this->m_ChaosCastleDamageRate = GetPrivateProfileInt(section,"ChaosCastleDamageRate",0,path);

	this->m_IllusionTempleDamageRate = GetPrivateProfileInt(section,"IllusionTempleDamageRate",0,path);

	this->m_CastleSiegeDamageRate1 = GetPrivateProfileInt(section,"CastleSiegeDamageRate1",0,path);

	this->m_CastleSiegeDamageRate2 = GetPrivateProfileInt(section,"CastleSiegeDamageRate2",0,path);

	this->m_CastleSiegeDamageRate3 = GetPrivateProfileInt(section,"CastleSiegeDamageRate3",0,path);

	this->m_GeneralDamageRatePvP = GetPrivateProfileInt(section,"GeneralDamageRatePvP",0,path);

	this->m_GeneralDamageRatePvM = GetPrivateProfileInt(section,"GeneralDamageRatePvM",0,path);

	this->m_ReflectDamageRatePvP = GetPrivateProfileInt(section,"ReflectDamageRatePvP",0,path);

	this->m_ReflectDamageRatePvM = GetPrivateProfileInt(section,"ReflectDamageRatePvM",0,path);

	this->m_DamageRatePvP[0] = GetPrivateProfileInt(section,"DWDamageRatePvP",0,path);

	this->m_DamageRatePvP[1] = GetPrivateProfileInt(section,"DKDamageRatePvP",0,path);

	this->m_DamageRatePvP[2] = GetPrivateProfileInt(section,"FEDamageRatePvP",0,path);

	this->m_DamageRatePvP[3] = GetPrivateProfileInt(section,"MGDamageRatePvP",0,path);

	this->m_DamageRatePvP[4] = GetPrivateProfileInt(section,"DLDamageRatePvP",0,path);

	this->m_DamageRatePvP[5] = GetPrivateProfileInt(section,"SUDamageRatePvP",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRatePvP[6] = GetPrivateProfileInt(section,"RFDamageRatePvP",0,path);

	#endif

	this->m_DamageRatePvM[0] = GetPrivateProfileInt(section,"DWDamageRatePvM",0,path);

	this->m_DamageRatePvM[1] = GetPrivateProfileInt(section,"DKDamageRatePvM",0,path);

	this->m_DamageRatePvM[2] = GetPrivateProfileInt(section,"FEDamageRatePvM",0,path);

	this->m_DamageRatePvM[3] = GetPrivateProfileInt(section,"MGDamageRatePvM",0,path);

	this->m_DamageRatePvM[4] = GetPrivateProfileInt(section,"DLDamageRatePvM",0,path);

	this->m_DamageRatePvM[5] = GetPrivateProfileInt(section,"SUDamageRatePvM",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRatePvM[6] = GetPrivateProfileInt(section,"RFDamageRatePvM",0,path);

	#endif

	this->m_DamageRateTo[0][0] = GetPrivateProfileInt(section,"DWDamageRateToDW",0,path);

	this->m_DamageRateTo[0][1] = GetPrivateProfileInt(section,"DWDamageRateToDK",0,path);

	this->m_DamageRateTo[0][2] = GetPrivateProfileInt(section,"DWDamageRateToFE",0,path);

	this->m_DamageRateTo[0][3] = GetPrivateProfileInt(section,"DWDamageRateToMG",0,path);

	this->m_DamageRateTo[0][4] = GetPrivateProfileInt(section,"DWDamageRateToDL",0,path);

	this->m_DamageRateTo[0][5] = GetPrivateProfileInt(section,"DWDamageRateToSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRateTo[0][6] = GetPrivateProfileInt(section,"DWDamageRateToRF",0,path);

	#endif

	this->m_DamageRateTo[1][0] = GetPrivateProfileInt(section,"DKDamageRateToDW",0,path);

	this->m_DamageRateTo[1][1] = GetPrivateProfileInt(section,"DKDamageRateToDK",0,path);

	this->m_DamageRateTo[1][2] = GetPrivateProfileInt(section,"DKDamageRateToFE",0,path);

	this->m_DamageRateTo[1][3] = GetPrivateProfileInt(section,"DKDamageRateToMG",0,path);

	this->m_DamageRateTo[1][4] = GetPrivateProfileInt(section,"DKDamageRateToDL",0,path);

	this->m_DamageRateTo[1][5] = GetPrivateProfileInt(section,"DKDamageRateToSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRateTo[1][6] = GetPrivateProfileInt(section,"DKDamageRateToRF",0,path);

	#endif

	this->m_DamageRateTo[2][0] = GetPrivateProfileInt(section,"FEDamageRateToDW",0,path);

	this->m_DamageRateTo[2][1] = GetPrivateProfileInt(section,"FEDamageRateToDK",0,path);

	this->m_DamageRateTo[2][2] = GetPrivateProfileInt(section,"FEDamageRateToFE",0,path);

	this->m_DamageRateTo[2][3] = GetPrivateProfileInt(section,"FEDamageRateToMG",0,path);

	this->m_DamageRateTo[2][4] = GetPrivateProfileInt(section,"FEDamageRateToDL",0,path);

	this->m_DamageRateTo[2][5] = GetPrivateProfileInt(section,"FEDamageRateToSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRateTo[2][6] = GetPrivateProfileInt(section,"FEDamageRateToRF",0,path);

	#endif

	this->m_DamageRateTo[3][0] = GetPrivateProfileInt(section,"MGDamageRateToDW",0,path);

	this->m_DamageRateTo[3][1] = GetPrivateProfileInt(section,"MGDamageRateToDK",0,path);

	this->m_DamageRateTo[3][2] = GetPrivateProfileInt(section,"MGDamageRateToFE",0,path);

	this->m_DamageRateTo[3][3] = GetPrivateProfileInt(section,"MGDamageRateToMG",0,path);

	this->m_DamageRateTo[3][4] = GetPrivateProfileInt(section,"MGDamageRateToDL",0,path);

	this->m_DamageRateTo[3][5] = GetPrivateProfileInt(section,"MGDamageRateToSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRateTo[3][6] = GetPrivateProfileInt(section,"MGDamageRateToRF",0,path);

	#endif

	this->m_DamageRateTo[4][0] = GetPrivateProfileInt(section,"DLDamageRateToDW",0,path);

	this->m_DamageRateTo[4][1] = GetPrivateProfileInt(section,"DLDamageRateToDK",0,path);

	this->m_DamageRateTo[4][2] = GetPrivateProfileInt(section,"DLDamageRateToFE",0,path);

	this->m_DamageRateTo[4][3] = GetPrivateProfileInt(section,"DLDamageRateToMG",0,path);

	this->m_DamageRateTo[4][4] = GetPrivateProfileInt(section,"DLDamageRateToDL",0,path);

	this->m_DamageRateTo[4][5] = GetPrivateProfileInt(section,"DLDamageRateToSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRateTo[4][6] = GetPrivateProfileInt(section,"DLDamageRateToRF",0,path);

	#endif

	this->m_DamageRateTo[5][0] = GetPrivateProfileInt(section,"SUDamageRateToDW",0,path);

	this->m_DamageRateTo[5][1] = GetPrivateProfileInt(section,"SUDamageRateToDK",0,path);

	this->m_DamageRateTo[5][2] = GetPrivateProfileInt(section,"SUDamageRateToFE",0,path);

	this->m_DamageRateTo[5][3] = GetPrivateProfileInt(section,"SUDamageRateToMG",0,path);

	this->m_DamageRateTo[5][4] = GetPrivateProfileInt(section,"SUDamageRateToDL",0,path);

	this->m_DamageRateTo[5][5] = GetPrivateProfileInt(section,"SUDamageRateToSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRateTo[5][6] = GetPrivateProfileInt(section,"SUDamageRateToRF",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageRateTo[6][0] = GetPrivateProfileInt(section,"RFDamageRateToDW",0,path);

	this->m_DamageRateTo[6][1] = GetPrivateProfileInt(section,"RFDamageRateToDK",0,path);

	this->m_DamageRateTo[6][2] = GetPrivateProfileInt(section,"RFDamageRateToFE",0,path);

	this->m_DamageRateTo[6][3] = GetPrivateProfileInt(section,"RFDamageRateToMG",0,path);

	this->m_DamageRateTo[6][4] = GetPrivateProfileInt(section,"RFDamageRateToDL",0,path);

	this->m_DamageRateTo[6][5] = GetPrivateProfileInt(section,"RFDamageRateToSU",0,path);

	this->m_DamageRateTo[6][6] = GetPrivateProfileInt(section,"RFDamageRateToRF",0,path);

	#endif

	this->m_DamageStuckRate[0] = GetPrivateProfileInt(section,"DWDamageStuckRate",0,path);

	this->m_DamageStuckRate[1] = GetPrivateProfileInt(section,"DKDamageStuckRate",0,path);

	this->m_DamageStuckRate[2] = GetPrivateProfileInt(section,"FEDamageStuckRate",0,path);

	this->m_DamageStuckRate[3] = GetPrivateProfileInt(section,"MGDamageStuckRate",0,path);

	this->m_DamageStuckRate[4] = GetPrivateProfileInt(section,"DLDamageStuckRate",0,path);

	this->m_DamageStuckRate[5] = GetPrivateProfileInt(section,"SUDamageStuckRate",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_DamageStuckRate[6] = GetPrivateProfileInt(section,"RFDamageStuckRate",0,path);

	#endif

	this->m_MaxAttackSpeed[0] = GetPrivateProfileInt(section, "DWMaxAttackSpeed", -1, path);

	this->m_MaxAttackSpeed[1] = GetPrivateProfileInt(section, "DKMaxAttackSpeed", -1, path);

	this->m_MaxAttackSpeed[2] = GetPrivateProfileInt(section, "FEMaxAttackSpeed", -1, path);

	this->m_MaxAttackSpeed[3] = GetPrivateProfileInt(section, "MGMaxAttackSpeed", -1, path);

	this->m_MaxAttackSpeed[4] = GetPrivateProfileInt(section, "DLMaxAttackSpeed", -1, path);

	this->m_MaxAttackSpeed[5] = GetPrivateProfileInt(section, "SUMaxAttackSpeed", -1, path);

#if(GAMESERVER_UPDATE>=601)

	this->m_MaxAttackSpeed[6] = GetPrivateProfileInt(section, "RFMaxAttackSpeed", -1, path);

#endif

	this->m_DKDamageMultiplierConstA = GetPrivateProfileInt(section,"DKDamageMultiplierConstA",0,path);

	this->m_DLDamageMultiplierConstA = GetPrivateProfileInt(section,"DLDamageMultiplierConstA",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFDamageMultiplierConstA = GetPrivateProfileInt(section,"RFDamageMultiplierConstA",0,path);

	this->m_RFDamageMultiplierConstB = GetPrivateProfileInt(section,"RFDamageMultiplierConstB",0,path);

	this->m_RFDamageMultiplierConstC = GetPrivateProfileInt(section,"RFDamageMultiplierConstC",0,path);

	#endif

	this->m_DKDamageMultiplierMaxRate = GetPrivateProfileInt(section,"DKDamageMultiplierMaxRate",0,path);

	this->m_DLDamageMultiplierMaxRate = GetPrivateProfileInt(section,"DLDamageMultiplierMaxRate",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFDamageMultiplierMaxRate = GetPrivateProfileInt(section,"RFDamageMultiplierMaxRate",0,path);

	#endif

	this->m_DarkSpiritRangeAttackRate = GetPrivateProfileInt(section,"DarkSpiritRangeAttackRate",0,path);

	this->m_DarkSpiritCriticalDamageRate = GetPrivateProfileInt(section,"DarkSpiritCriticalDamageRate",0,path);

	this->m_DarkSpiritExcellentDamageRate = GetPrivateProfileInt(section,"DarkSpiritExcellentDamageRate",0,path);

	this->m_DarkSpiritAttackDamageMinConstA = GetPrivateProfileInt(section,"DarkSpiritAttackDamageMinConstA",0,path);

	this->m_DarkSpiritAttackDamageMinConstB = GetPrivateProfileInt(section,"DarkSpiritAttackDamageMinConstB",0,path);

	this->m_DarkSpiritAttackDamageMinConstC = GetPrivateProfileInt(section,"DarkSpiritAttackDamageMinConstC",0,path);

	this->m_DarkSpiritAttackDamageMaxConstA = GetPrivateProfileInt(section,"DarkSpiritAttackDamageMaxConstA",0,path);

	this->m_DarkSpiritAttackDamageMaxConstB = GetPrivateProfileInt(section,"DarkSpiritAttackDamageMaxConstB",0,path);

	this->m_DarkSpiritAttackDamageMaxConstC = GetPrivateProfileInt(section,"DarkSpiritAttackDamageMaxConstC",0,path);

	this->m_DarkSpiritAttackSpeedConstA = GetPrivateProfileInt(section,"DarkSpiritAttackSpeedConstA",0,path);

	this->m_DarkSpiritAttackSpeedConstB = GetPrivateProfileInt(section,"DarkSpiritAttackSpeedConstB",0,path);

	this->m_DarkSpiritAttackSpeedConstC = GetPrivateProfileInt(section,"DarkSpiritAttackSpeedConstC",0,path);

	this->m_DarkSpiritAttackSpeedConstD = GetPrivateProfileInt(section,"DarkSpiritAttackSpeedConstD",0,path);

	this->m_DarkSpiritAttackSuccessRateConstA = GetPrivateProfileInt(section,"DarkSpiritAttackSuccessRateConstA",0,path);

	this->m_DarkSpiritAttackSuccessRateConstB = GetPrivateProfileInt(section,"DarkSpiritAttackSuccessRateConstB",0,path);

	this->m_DarkSpiritAttackSuccessRateConstC = GetPrivateProfileInt(section,"DarkSpiritAttackSuccessRateConstC",0,path);

	this->m_SatanIncDamageConstA = GetPrivateProfileInt(section, "SatanIncDamageConstA", 1, path);

	this->m_DinorantIncDamageConstA = GetPrivateProfileInt(section, "DinorantIncDamageConstA", 1, path);

	this->m_BlackFenrirIncDamageConstA = GetPrivateProfileInt(section, "BlackFenrirIncDamageConstA", 1, path);

	this->m_DemonIncDamageConstA = GetPrivateProfileInt(section, "DemonIncDamageConstA", 1, path);

	this->m_SkeletonIncDamageConstA = GetPrivateProfileInt(section, "SkeletonIncDamageConstA", 1, path);

	this->m_AngelDecDamageConstA = GetPrivateProfileInt(section, "AngelDecDamageConstA", 1, path);

	this->m_DinorantDecDamageConstA = GetPrivateProfileInt(section, "DinorantDecDamageConstA", 1, path);

	this->m_DinorantDecDamageConstB = GetPrivateProfileInt(section, "DinorantDecDamageConstB", 1, path);

	this->m_DarkHorseDecDamageConstA = GetPrivateProfileInt(section, "DarkHorseDecDamageConstA", 1, path);

	this->m_DarkHorseDecDamageConstB = GetPrivateProfileInt(section, "DarkHorseDecDamageConstB", 1, path);

	this->m_BlueFenrirDecDamageConstA = GetPrivateProfileInt(section, "BlueFenrirDecDamageConstA", 1, path);

	this->m_MariaDecDamageConstA = GetPrivateProfileInt(section, "MariaDecDamageConstA", 1, path);

	this->m_ComboDamageConstA = GetPrivateProfileInt(section,"ComboDamageConstA",1,path);

	this->m_ComboDamageConstB = GetPrivateProfileInt(section,"ComboDamageConstB",1,path);

	this->m_EarthquakeDamageConstA = GetPrivateProfileInt(section,"EarthquakeDamageConstA",0,path);

	this->m_EarthquakeDamageConstB = GetPrivateProfileInt(section,"EarthquakeDamageConstB",0,path);

	this->m_EarthquakeDamageConstC = GetPrivateProfileInt(section,"EarthquakeDamageConstC",0,path);

	this->m_ElectricSparkDamageConstA = GetPrivateProfileInt(section,"ElectricSparkDamageConstA",0,path);

	this->m_ElectricSparkDamageConstB = GetPrivateProfileInt(section,"ElectricSparkDamageConstB",0,path);

	this->m_DLSkillDamageConstA = GetPrivateProfileInt(section,"DLSkillDamageConstA",0,path);

	this->m_DLSkillDamageConstB = GetPrivateProfileInt(section,"DLSkillDamageConstB",0,path);

	this->m_NovaDamageConstA = GetPrivateProfileInt(section,"NovaDamageConstA",0,path);

	this->m_NovaDamageConstB = GetPrivateProfileInt(section,"NovaDamageConstB",0,path);

	this->m_NovaDamageConstC = GetPrivateProfileInt(section,"NovaDamageConstC",0,path);

	this->m_HPRecoveryRate[0] = GetPrivateProfileInt(section,"DWHPRecoveryRate",0,path);

	this->m_HPRecoveryRate[1] = GetPrivateProfileInt(section,"DKHPRecoveryRate",0,path);

	this->m_HPRecoveryRate[2] = GetPrivateProfileInt(section,"FEHPRecoveryRate",0,path);

	this->m_HPRecoveryRate[3] = GetPrivateProfileInt(section,"MGHPRecoveryRate",0,path);

	this->m_HPRecoveryRate[4] = GetPrivateProfileInt(section,"DLHPRecoveryRate",0,path);

	this->m_HPRecoveryRate[5] = GetPrivateProfileInt(section,"SUHPRecoveryRate",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_HPRecoveryRate[6] = GetPrivateProfileInt(section,"RFHPRecoveryRate",0,path);

	#endif

	this->m_MPRecoveryRate[0] = GetPrivateProfileInt(section,"DWMPRecoveryRate",0,path);

	this->m_MPRecoveryRate[1] = GetPrivateProfileInt(section,"DKMPRecoveryRate",0,path);

	this->m_MPRecoveryRate[2] = GetPrivateProfileInt(section,"FEMPRecoveryRate",0,path);

	this->m_MPRecoveryRate[3] = GetPrivateProfileInt(section,"MGMPRecoveryRate",0,path);

	this->m_MPRecoveryRate[4] = GetPrivateProfileInt(section,"DLMPRecoveryRate",0,path);

	this->m_MPRecoveryRate[5] = GetPrivateProfileInt(section,"SUMPRecoveryRate",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_MPRecoveryRate[6] = GetPrivateProfileInt(section,"RFMPRecoveryRate",0,path);

	#endif

	this->m_BPRecoveryRate[0] = GetPrivateProfileInt(section,"DWBPRecoveryRate",0,path);

	this->m_BPRecoveryRate[1] = GetPrivateProfileInt(section,"DKBPRecoveryRate",0,path);

	this->m_BPRecoveryRate[2] = GetPrivateProfileInt(section,"FEBPRecoveryRate",0,path);

	this->m_BPRecoveryRate[3] = GetPrivateProfileInt(section,"MGBPRecoveryRate",0,path);

	this->m_BPRecoveryRate[4] = GetPrivateProfileInt(section,"DLBPRecoveryRate",0,path);

	this->m_BPRecoveryRate[5] = GetPrivateProfileInt(section,"SUBPRecoveryRate",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_BPRecoveryRate[6] = GetPrivateProfileInt(section,"RFBPRecoveryRate",0,path);

	#endif

	this->m_SDRecoveryRate[0] = GetPrivateProfileInt(section,"DWSDRecoveryRate",0,path);

	this->m_SDRecoveryRate[1] = GetPrivateProfileInt(section,"DKSDRecoveryRate",0,path);

	this->m_SDRecoveryRate[2] = GetPrivateProfileInt(section,"FESDRecoveryRate",0,path);

	this->m_SDRecoveryRate[3] = GetPrivateProfileInt(section,"MGSDRecoveryRate",0,path);

	this->m_SDRecoveryRate[4] = GetPrivateProfileInt(section,"DLSDRecoveryRate",0,path);

	this->m_SDRecoveryRate[5] = GetPrivateProfileInt(section,"SUSDRecoveryRate",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_SDRecoveryRate[6] = GetPrivateProfileInt(section,"RFSDRecoveryRate",0,path);

	#endif

	this->m_DWPlasmaStormDamageConstA = GetPrivateProfileInt(section,"DWPlasmaStormDamageConstA",0,path);

	this->m_DWPlasmaStormDamageConstB = GetPrivateProfileInt(section,"DWPlasmaStormDamageConstB",0,path);

	this->m_DWPlasmaStormDamageConstC = GetPrivateProfileInt(section,"DWPlasmaStormDamageConstC",0,path);

	this->m_DWPlasmaStormDamageConstD = GetPrivateProfileInt(section,"DWPlasmaStormDamageConstD",0,path);

	this->m_DKPlasmaStormDamageConstA = GetPrivateProfileInt(section,"DKPlasmaStormDamageConstA",0,path);

	this->m_DKPlasmaStormDamageConstB = GetPrivateProfileInt(section,"DKPlasmaStormDamageConstB",0,path);

	this->m_DKPlasmaStormDamageConstC = GetPrivateProfileInt(section,"DKPlasmaStormDamageConstC",0,path);

	this->m_DKPlasmaStormDamageConstD = GetPrivateProfileInt(section,"DKPlasmaStormDamageConstD",0,path);

	this->m_FEPlasmaStormDamageConstA = GetPrivateProfileInt(section,"FEPlasmaStormDamageConstA",0,path);

	this->m_FEPlasmaStormDamageConstB = GetPrivateProfileInt(section,"FEPlasmaStormDamageConstB",0,path);

	this->m_FEPlasmaStormDamageConstC = GetPrivateProfileInt(section,"FEPlasmaStormDamageConstC",0,path);

	this->m_FEPlasmaStormDamageConstD = GetPrivateProfileInt(section,"FEPlasmaStormDamageConstD",0,path);

	this->m_MGPlasmaStormDamageConstA = GetPrivateProfileInt(section,"MGPlasmaStormDamageConstA",0,path);

	this->m_MGPlasmaStormDamageConstB = GetPrivateProfileInt(section,"MGPlasmaStormDamageConstB",0,path);

	this->m_MGPlasmaStormDamageConstC = GetPrivateProfileInt(section,"MGPlasmaStormDamageConstC",0,path);

	this->m_MGPlasmaStormDamageConstD = GetPrivateProfileInt(section,"MGPlasmaStormDamageConstD",0,path);

	this->m_DLPlasmaStormDamageConstA = GetPrivateProfileInt(section,"DLPlasmaStormDamageConstA",0,path);

	this->m_DLPlasmaStormDamageConstB = GetPrivateProfileInt(section,"DLPlasmaStormDamageConstB",0,path);

	this->m_DLPlasmaStormDamageConstC = GetPrivateProfileInt(section,"DLPlasmaStormDamageConstC",0,path);

	this->m_DLPlasmaStormDamageConstD = GetPrivateProfileInt(section,"DLPlasmaStormDamageConstD",0,path);

	this->m_DLPlasmaStormDamageConstE = GetPrivateProfileInt(section,"DLPlasmaStormDamageConstE",0,path);

	this->m_SUPlasmaStormDamageConstA = GetPrivateProfileInt(section,"SUPlasmaStormDamageConstA",0,path);

	this->m_SUPlasmaStormDamageConstB = GetPrivateProfileInt(section,"SUPlasmaStormDamageConstB",0,path);

	this->m_SUPlasmaStormDamageConstC = GetPrivateProfileInt(section,"SUPlasmaStormDamageConstC",0,path);

	this->m_SUPlasmaStormDamageConstD = GetPrivateProfileInt(section,"SUPlasmaStormDamageConstD",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFPlasmaStormDamageConstA = GetPrivateProfileInt(section,"RFPlasmaStormDamageConstA",0,path);

	this->m_RFPlasmaStormDamageConstB = GetPrivateProfileInt(section,"RFPlasmaStormDamageConstB",0,path);

	this->m_RFPlasmaStormDamageConstC = GetPrivateProfileInt(section,"RFPlasmaStormDamageConstC",0,path);

	this->m_RFPlasmaStormDamageConstD = GetPrivateProfileInt(section,"RFPlasmaStormDamageConstD",0,path);

	#endif

	this->m_DWPhysiDamageMinConstA = GetPrivateProfileInt(section,"DWPhysiDamageMinConstA",0,path);

	this->m_DWPhysiDamageMaxConstA = GetPrivateProfileInt(section,"DWPhysiDamageMaxConstA",0,path);

	this->m_DWMagicDamageMinConstA = GetPrivateProfileInt(section,"DWMagicDamageMinConstA",0,path);

	this->m_DWMagicDamageMaxConstA = GetPrivateProfileInt(section,"DWMagicDamageMaxConstA",0,path);

	this->m_DKPhysiDamageMinConstA = GetPrivateProfileInt(section,"DKPhysiDamageMinConstA",0,path);

	this->m_DKPhysiDamageMaxConstA = GetPrivateProfileInt(section,"DKPhysiDamageMaxConstA",0,path);

	this->m_DKMagicDamageMinConstA = GetPrivateProfileInt(section,"DKMagicDamageMinConstA",0,path);

	this->m_DKMagicDamageMaxConstA = GetPrivateProfileInt(section,"DKMagicDamageMaxConstA",0,path);

	this->m_FEPhysiDamageMinConstA = GetPrivateProfileInt(section,"FEPhysiDamageMinConstA",0,path);

	this->m_FEPhysiDamageMaxConstA = GetPrivateProfileInt(section,"FEPhysiDamageMaxConstA",0,path);

	this->m_FEPhysiDamageMinBowConstA = GetPrivateProfileInt(section,"FEPhysiDamageMinBowConstA",0,path);

	this->m_FEPhysiDamageMinBowConstB = GetPrivateProfileInt(section,"FEPhysiDamageMinBowConstB",0,path);

	this->m_FEPhysiDamageMaxBowConstA = GetPrivateProfileInt(section,"FEPhysiDamageMaxBowConstA",0,path);

	this->m_FEPhysiDamageMaxBowConstB = GetPrivateProfileInt(section,"FEPhysiDamageMaxBowConstB",0,path);

	this->m_FEMagicDamageMinConstA = GetPrivateProfileInt(section,"FEMagicDamageMinConstA",0,path);

	this->m_FEMagicDamageMaxConstA = GetPrivateProfileInt(section,"FEMagicDamageMaxConstA",0,path);

	this->m_MGPhysiDamageMinConstA = GetPrivateProfileInt(section,"MGPhysiDamageMinConstA",0,path);

	this->m_MGPhysiDamageMinConstB = GetPrivateProfileInt(section,"MGPhysiDamageMinConstB",0,path);

	this->m_MGPhysiDamageMaxConstA = GetPrivateProfileInt(section,"MGPhysiDamageMaxConstA",0,path);

	this->m_MGPhysiDamageMaxConstB = GetPrivateProfileInt(section,"MGPhysiDamageMaxConstB",0,path);

	this->m_MGMagicDamageMinConstA = GetPrivateProfileInt(section,"MGMagicDamageMinConstA",0,path);

	this->m_MGMagicDamageMaxConstA = GetPrivateProfileInt(section,"MGMagicDamageMaxConstA",0,path);

	this->m_DLPhysiDamageMinConstA = GetPrivateProfileInt(section,"DLPhysiDamageMinConstA",0,path);

	this->m_DLPhysiDamageMinConstB = GetPrivateProfileInt(section,"DLPhysiDamageMinConstB",0,path);

	this->m_DLPhysiDamageMaxConstA = GetPrivateProfileInt(section,"DLPhysiDamageMaxConstA",0,path);

	this->m_DLPhysiDamageMaxConstB = GetPrivateProfileInt(section,"DLPhysiDamageMaxConstB",0,path);

	this->m_DLMagicDamageMinConstA = GetPrivateProfileInt(section,"DLMagicDamageMinConstA",0,path);

	this->m_DLMagicDamageMaxConstA = GetPrivateProfileInt(section,"DLMagicDamageMaxConstA",0,path);

	this->m_SUPhysiDamageMinConstA = GetPrivateProfileInt(section,"SUPhysiDamageMinConstA",0,path);

	this->m_SUPhysiDamageMaxConstA = GetPrivateProfileInt(section,"SUPhysiDamageMaxConstA",0,path);

	this->m_SUMagicDamageMinConstA = GetPrivateProfileInt(section,"SUMagicDamageMinConstA",0,path);

	this->m_SUMagicDamageMaxConstA = GetPrivateProfileInt(section,"SUMagicDamageMaxConstA",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFPhysiDamageMinConstA = GetPrivateProfileInt(section,"RFPhysiDamageMinConstA",0,path);

	this->m_RFPhysiDamageMinConstB = GetPrivateProfileInt(section,"RFPhysiDamageMinConstB",0,path);

	this->m_RFPhysiDamageMaxConstA = GetPrivateProfileInt(section,"RFPhysiDamageMaxConstA",0,path);

	this->m_RFPhysiDamageMaxConstB = GetPrivateProfileInt(section,"RFPhysiDamageMaxConstB",0,path);

	this->m_RFMagicDamageMinConstA = GetPrivateProfileInt(section,"RFMagicDamageMinConstA",0,path);

	this->m_RFMagicDamageMaxConstA = GetPrivateProfileInt(section,"RFMagicDamageMaxConstA",0,path);

	#endif

	this->m_DWAttackSuccessRateConstA = GetPrivateProfileInt(section,"DWAttackSuccessRateConstA",0,path);

	this->m_DWAttackSuccessRateConstB = GetPrivateProfileInt(section,"DWAttackSuccessRateConstB",0,path);

	this->m_DWAttackSuccessRateConstC = GetPrivateProfileInt(section,"DWAttackSuccessRateConstC",0,path);

	this->m_DWAttackSuccessRateConstD = GetPrivateProfileInt(section,"DWAttackSuccessRateConstD",0,path);

	this->m_DKAttackSuccessRateConstA = GetPrivateProfileInt(section,"DKAttackSuccessRateConstA",0,path);

	this->m_DKAttackSuccessRateConstB = GetPrivateProfileInt(section,"DKAttackSuccessRateConstB",0,path);

	this->m_DKAttackSuccessRateConstC = GetPrivateProfileInt(section,"DKAttackSuccessRateConstC",0,path);

	this->m_DKAttackSuccessRateConstD = GetPrivateProfileInt(section,"DKAttackSuccessRateConstD",0,path);

	this->m_FEAttackSuccessRateConstA = GetPrivateProfileInt(section,"FEAttackSuccessRateConstA",0,path);

	this->m_FEAttackSuccessRateConstB = GetPrivateProfileInt(section,"FEAttackSuccessRateConstB",0,path);

	this->m_FEAttackSuccessRateConstC = GetPrivateProfileInt(section,"FEAttackSuccessRateConstC",0,path);

	this->m_FEAttackSuccessRateConstD = GetPrivateProfileInt(section,"FEAttackSuccessRateConstD",0,path);

	this->m_MGAttackSuccessRateConstA = GetPrivateProfileInt(section,"MGAttackSuccessRateConstA",0,path);

	this->m_MGAttackSuccessRateConstB = GetPrivateProfileInt(section,"MGAttackSuccessRateConstB",0,path);

	this->m_MGAttackSuccessRateConstC = GetPrivateProfileInt(section,"MGAttackSuccessRateConstC",0,path);

	this->m_MGAttackSuccessRateConstD = GetPrivateProfileInt(section,"MGAttackSuccessRateConstD",0,path);

	this->m_DLAttackSuccessRateConstA = GetPrivateProfileInt(section,"DLAttackSuccessRateConstA",0,path);

	this->m_DLAttackSuccessRateConstB = GetPrivateProfileInt(section,"DLAttackSuccessRateConstB",0,path);

	this->m_DLAttackSuccessRateConstC = GetPrivateProfileInt(section,"DLAttackSuccessRateConstC",0,path);

	this->m_DLAttackSuccessRateConstD = GetPrivateProfileInt(section,"DLAttackSuccessRateConstD",0,path);

	this->m_DLAttackSuccessRateConstE = GetPrivateProfileInt(section,"DLAttackSuccessRateConstE",0,path);

	this->m_SUAttackSuccessRateConstA = GetPrivateProfileInt(section,"SUAttackSuccessRateConstA",0,path);

	this->m_SUAttackSuccessRateConstB = GetPrivateProfileInt(section,"SUAttackSuccessRateConstB",0,path);

	this->m_SUAttackSuccessRateConstC = GetPrivateProfileInt(section,"SUAttackSuccessRateConstC",0,path);

	this->m_SUAttackSuccessRateConstD = GetPrivateProfileInt(section,"SUAttackSuccessRateConstD",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFAttackSuccessRateConstA = GetPrivateProfileInt(section,"RFAttackSuccessRateConstA",0,path);

	this->m_RFAttackSuccessRateConstB = GetPrivateProfileInt(section,"RFAttackSuccessRateConstB",0,path);

	this->m_RFAttackSuccessRateConstC = GetPrivateProfileInt(section,"RFAttackSuccessRateConstC",0,path);

	this->m_RFAttackSuccessRateConstD = GetPrivateProfileInt(section,"RFAttackSuccessRateConstD",0,path);

	#endif

	this->m_DWAttackSuccessRatePvPConstA = GetPrivateProfileInt(section,"DWAttackSuccessRatePvPConstA",0,path);

	this->m_DWAttackSuccessRatePvPConstB = GetPrivateProfileInt(section,"DWAttackSuccessRatePvPConstB",0,path);

	this->m_DWAttackSuccessRatePvPConstC = GetPrivateProfileInt(section,"DWAttackSuccessRatePvPConstC",0,path);

	this->m_DWAttackSuccessRatePvPConstD = GetPrivateProfileInt(section,"DWAttackSuccessRatePvPConstD",0,path);

	this->m_DKAttackSuccessRatePvPConstA = GetPrivateProfileInt(section,"DKAttackSuccessRatePvPConstA",0,path);

	this->m_DKAttackSuccessRatePvPConstB = GetPrivateProfileInt(section,"DKAttackSuccessRatePvPConstB",0,path);

	this->m_DKAttackSuccessRatePvPConstC = GetPrivateProfileInt(section,"DKAttackSuccessRatePvPConstC",0,path);

	this->m_DKAttackSuccessRatePvPConstD = GetPrivateProfileInt(section,"DKAttackSuccessRatePvPConstD",0,path);

	this->m_FEAttackSuccessRatePvPConstA = GetPrivateProfileInt(section,"FEAttackSuccessRatePvPConstA",0,path);

	this->m_FEAttackSuccessRatePvPConstB = GetPrivateProfileInt(section,"FEAttackSuccessRatePvPConstB",0,path);

	this->m_FEAttackSuccessRatePvPConstC = GetPrivateProfileInt(section,"FEAttackSuccessRatePvPConstC",0,path);

	this->m_FEAttackSuccessRatePvPConstD = GetPrivateProfileInt(section,"FEAttackSuccessRatePvPConstD",0,path);

	this->m_MGAttackSuccessRatePvPConstA = GetPrivateProfileInt(section,"MGAttackSuccessRatePvPConstA",0,path);

	this->m_MGAttackSuccessRatePvPConstB = GetPrivateProfileInt(section,"MGAttackSuccessRatePvPConstB",0,path);

	this->m_MGAttackSuccessRatePvPConstC = GetPrivateProfileInt(section,"MGAttackSuccessRatePvPConstC",0,path);

	this->m_MGAttackSuccessRatePvPConstD = GetPrivateProfileInt(section,"MGAttackSuccessRatePvPConstD",0,path);

	this->m_DLAttackSuccessRatePvPConstA = GetPrivateProfileInt(section,"DLAttackSuccessRatePvPConstA",0,path);

	this->m_DLAttackSuccessRatePvPConstB = GetPrivateProfileInt(section,"DLAttackSuccessRatePvPConstB",0,path);

	this->m_DLAttackSuccessRatePvPConstC = GetPrivateProfileInt(section,"DLAttackSuccessRatePvPConstC",0,path);

	this->m_DLAttackSuccessRatePvPConstD = GetPrivateProfileInt(section,"DLAttackSuccessRatePvPConstD",0,path);

	this->m_SUAttackSuccessRatePvPConstA = GetPrivateProfileInt(section,"SUAttackSuccessRatePvPConstA",0,path);

	this->m_SUAttackSuccessRatePvPConstB = GetPrivateProfileInt(section,"SUAttackSuccessRatePvPConstB",0,path);

	this->m_SUAttackSuccessRatePvPConstC = GetPrivateProfileInt(section,"SUAttackSuccessRatePvPConstC",0,path);

	this->m_SUAttackSuccessRatePvPConstD = GetPrivateProfileInt(section,"SUAttackSuccessRatePvPConstD",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFAttackSuccessRatePvPConstA = GetPrivateProfileInt(section,"RFAttackSuccessRatePvPConstA",0,path);

	this->m_RFAttackSuccessRatePvPConstB = GetPrivateProfileInt(section,"RFAttackSuccessRatePvPConstB",0,path);

	this->m_RFAttackSuccessRatePvPConstC = GetPrivateProfileInt(section,"RFAttackSuccessRatePvPConstC",0,path);

	this->m_RFAttackSuccessRatePvPConstD = GetPrivateProfileInt(section,"RFAttackSuccessRatePvPConstD",0,path);

	#endif

	this->m_DWPhysiSpeedConstA = GetPrivateProfileInt(section,"DWPhysiSpeedConstA",0,path);

	this->m_DWMagicSpeedConstA = GetPrivateProfileInt(section,"DWMagicSpeedConstA",0,path);

	this->m_DKPhysiSpeedConstA = GetPrivateProfileInt(section,"DKPhysiSpeedConstA",0,path);

	this->m_DKMagicSpeedConstA = GetPrivateProfileInt(section,"DKMagicSpeedConstA",0,path);

	this->m_FEPhysiSpeedConstA = GetPrivateProfileInt(section,"FEPhysiSpeedConstA",0,path);

	this->m_FEMagicSpeedConstA = GetPrivateProfileInt(section,"FEMagicSpeedConstA",0,path);

	this->m_MGPhysiSpeedConstA = GetPrivateProfileInt(section,"MGPhysiSpeedConstA",0,path);

	this->m_MGMagicSpeedConstA = GetPrivateProfileInt(section,"MGMagicSpeedConstA",0,path);

	this->m_DLPhysiSpeedConstA = GetPrivateProfileInt(section,"DLPhysiSpeedConstA",0,path);

	this->m_DLMagicSpeedConstA = GetPrivateProfileInt(section,"DLMagicSpeedConstA",0,path);

	this->m_SUPhysiSpeedConstA = GetPrivateProfileInt(section,"SUPhysiSpeedConstA",0,path);

	this->m_SUMagicSpeedConstA = GetPrivateProfileInt(section,"SUMagicSpeedConstA",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFPhysiSpeedConstA = GetPrivateProfileInt(section,"RFPhysiSpeedConstA",0,path);

	this->m_RFMagicSpeedConstA = GetPrivateProfileInt(section,"RFMagicSpeedConstA",0,path);

	#endif

	this->m_DWDefenseSuccessRateConstA = GetPrivateProfileInt(section,"DWDefenseSuccessRateConstA",0,path);

	this->m_DKDefenseSuccessRateConstA = GetPrivateProfileInt(section,"DKDefenseSuccessRateConstA",0,path);

	this->m_FEDefenseSuccessRateConstA = GetPrivateProfileInt(section,"FEDefenseSuccessRateConstA",0,path);

	this->m_MGDefenseSuccessRateConstA = GetPrivateProfileInt(section,"MGDefenseSuccessRateConstA",0,path);

	this->m_DLDefenseSuccessRateConstA = GetPrivateProfileInt(section,"DLDefenseSuccessRateConstA",0,path);

	this->m_SUDefenseSuccessRateConstA = GetPrivateProfileInt(section,"SUDefenseSuccessRateConstA",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFDefenseSuccessRateConstA = GetPrivateProfileInt(section,"RFDefenseSuccessRateConstA",0,path);

	#endif

	this->m_DWDefenseSuccessRatePvPConstA = GetPrivateProfileInt(section,"DWDefenseSuccessRatePvPConstA",0,path);

	this->m_DWDefenseSuccessRatePvPConstB = GetPrivateProfileInt(section,"DWDefenseSuccessRatePvPConstB",0,path);

	this->m_DWDefenseSuccessRatePvPConstC = GetPrivateProfileInt(section,"DWDefenseSuccessRatePvPConstC",0,path);

	this->m_DKDefenseSuccessRatePvPConstA = GetPrivateProfileInt(section,"DKDefenseSuccessRatePvPConstA",0,path);

	this->m_DKDefenseSuccessRatePvPConstB = GetPrivateProfileInt(section,"DKDefenseSuccessRatePvPConstB",0,path);

	this->m_DKDefenseSuccessRatePvPConstC = GetPrivateProfileInt(section,"DKDefenseSuccessRatePvPConstC",0,path);

	this->m_FEDefenseSuccessRatePvPConstA = GetPrivateProfileInt(section,"FEDefenseSuccessRatePvPConstA",0,path);

	this->m_FEDefenseSuccessRatePvPConstB = GetPrivateProfileInt(section,"FEDefenseSuccessRatePvPConstB",0,path);

	this->m_FEDefenseSuccessRatePvPConstC = GetPrivateProfileInt(section,"FEDefenseSuccessRatePvPConstC",0,path);

	this->m_MGDefenseSuccessRatePvPConstA = GetPrivateProfileInt(section,"MGDefenseSuccessRatePvPConstA",0,path);

	this->m_MGDefenseSuccessRatePvPConstB = GetPrivateProfileInt(section,"MGDefenseSuccessRatePvPConstB",0,path);

	this->m_MGDefenseSuccessRatePvPConstC = GetPrivateProfileInt(section,"MGDefenseSuccessRatePvPConstC",0,path);

	this->m_DLDefenseSuccessRatePvPConstA = GetPrivateProfileInt(section,"DLDefenseSuccessRatePvPConstA",0,path);

	this->m_DLDefenseSuccessRatePvPConstB = GetPrivateProfileInt(section,"DLDefenseSuccessRatePvPConstB",0,path);

	this->m_DLDefenseSuccessRatePvPConstC = GetPrivateProfileInt(section,"DLDefenseSuccessRatePvPConstC",0,path);

	this->m_SUDefenseSuccessRatePvPConstA = GetPrivateProfileInt(section,"SUDefenseSuccessRatePvPConstA",0,path);

	this->m_SUDefenseSuccessRatePvPConstB = GetPrivateProfileInt(section,"SUDefenseSuccessRatePvPConstB",0,path);

	this->m_SUDefenseSuccessRatePvPConstC = GetPrivateProfileInt(section,"SUDefenseSuccessRatePvPConstC",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFDefenseSuccessRatePvPConstA = GetPrivateProfileInt(section,"RFDefenseSuccessRatePvPConstA",0,path);

	this->m_RFDefenseSuccessRatePvPConstB = GetPrivateProfileInt(section,"RFDefenseSuccessRatePvPConstB",0,path);

	this->m_RFDefenseSuccessRatePvPConstC = GetPrivateProfileInt(section,"RFDefenseSuccessRatePvPConstC",0,path);

	#endif

	this->m_DWDefenseConstA = GetPrivateProfileInt(section,"DWDefenseConstA",0,path);

	this->m_DKDefenseConstA = GetPrivateProfileInt(section,"DKDefenseConstA",0,path);

	this->m_FEDefenseConstA = GetPrivateProfileInt(section,"FEDefenseConstA",0,path);

	this->m_MGDefenseConstA = GetPrivateProfileInt(section,"MGDefenseConstA",0,path);

	this->m_DLDefenseConstA = GetPrivateProfileInt(section,"DLDefenseConstA",0,path);

	this->m_SUDefenseConstA = GetPrivateProfileInt(section,"SUDefenseConstA",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFDefenseConstA = GetPrivateProfileInt(section,"RFDefenseConstA",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=701)

	this->m_DuelElementalDamageRate = GetPrivateProfileInt(section,"DuelElementalDamageRate",0,path);

	this->m_GensElementalDamageRate = GetPrivateProfileInt(section,"GensElementalDamageRate",0,path);

	this->m_CustomArenaElementalDamageRate = GetPrivateProfileInt(section,"CustomArenaElementalDamageRate",0,path);

	this->m_ChaosCastleElementalDamageRate = GetPrivateProfileInt(section,"ChaosCastleElementalDamageRate",0,path);

	this->m_IllusionTempleElementalDamageRate = GetPrivateProfileInt(section,"IllusionTempleElementalDamageRate",0,path);

	this->m_CastleSiegeElementalDamageRate1 = GetPrivateProfileInt(section,"CastleSiegeElementalDamageRate1",0,path);

	this->m_CastleSiegeElementalDamageRate2 = GetPrivateProfileInt(section,"CastleSiegeElementalDamageRate2",0,path);

	this->m_GeneralElementalDamageRatePvP = GetPrivateProfileInt(section,"GeneralElementalDamageRatePvP",0,path);

	this->m_GeneralElementalDamageRatePvM = GetPrivateProfileInt(section,"GeneralElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRatePvP[0] = GetPrivateProfileInt(section,"DWElementalDamageRatePvP",0,path);

	this->m_ElementalDamageRatePvP[1] = GetPrivateProfileInt(section,"DKElementalDamageRatePvP",0,path);

	this->m_ElementalDamageRatePvP[2] = GetPrivateProfileInt(section,"FEElementalDamageRatePvP",0,path);

	this->m_ElementalDamageRatePvP[3] = GetPrivateProfileInt(section,"MGElementalDamageRatePvP",0,path);

	this->m_ElementalDamageRatePvP[4] = GetPrivateProfileInt(section,"DLElementalDamageRatePvP",0,path);

	this->m_ElementalDamageRatePvP[5] = GetPrivateProfileInt(section,"SUElementalDamageRatePvP",0,path);

	this->m_ElementalDamageRatePvP[6] = GetPrivateProfileInt(section,"RFElementalDamageRatePvP",0,path);

	this->m_ElementalDamageRatePvM[0] = GetPrivateProfileInt(section,"DWElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRatePvM[1] = GetPrivateProfileInt(section,"DKElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRatePvM[2] = GetPrivateProfileInt(section,"FEElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRatePvM[3] = GetPrivateProfileInt(section,"MGElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRatePvM[4] = GetPrivateProfileInt(section,"DLElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRatePvM[5] = GetPrivateProfileInt(section,"SUElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRatePvM[6] = GetPrivateProfileInt(section,"RFElementalDamageRatePvM",0,path);

	this->m_ElementalDamageRateTo[0][0] = GetPrivateProfileInt(section,"DWElementalDamageRateToDW",0,path);

	this->m_ElementalDamageRateTo[0][1] = GetPrivateProfileInt(section,"DWElementalDamageRateToDK",0,path);

	this->m_ElementalDamageRateTo[0][2] = GetPrivateProfileInt(section,"DWElementalDamageRateToFE",0,path);

	this->m_ElementalDamageRateTo[0][3] = GetPrivateProfileInt(section,"DWElementalDamageRateToMG",0,path);

	this->m_ElementalDamageRateTo[0][4] = GetPrivateProfileInt(section,"DWElementalDamageRateToDL",0,path);

	this->m_ElementalDamageRateTo[0][5] = GetPrivateProfileInt(section,"DWElementalDamageRateToSU",0,path);

	this->m_ElementalDamageRateTo[0][6] = GetPrivateProfileInt(section,"DWElementalDamageRateToRF",0,path);

	this->m_ElementalDamageRateTo[1][0] = GetPrivateProfileInt(section,"DKElementalDamageRateToDW",0,path);

	this->m_ElementalDamageRateTo[1][1] = GetPrivateProfileInt(section,"DKElementalDamageRateToDK",0,path);

	this->m_ElementalDamageRateTo[1][2] = GetPrivateProfileInt(section,"DKElementalDamageRateToFE",0,path);

	this->m_ElementalDamageRateTo[1][3] = GetPrivateProfileInt(section,"DKElementalDamageRateToMG",0,path);

	this->m_ElementalDamageRateTo[1][4] = GetPrivateProfileInt(section,"DKElementalDamageRateToDL",0,path);

	this->m_ElementalDamageRateTo[1][5] = GetPrivateProfileInt(section,"DKElementalDamageRateToSU",0,path);

	this->m_ElementalDamageRateTo[1][6] = GetPrivateProfileInt(section,"DKElementalDamageRateToRF",0,path);

	this->m_ElementalDamageRateTo[2][0] = GetPrivateProfileInt(section,"FEElementalDamageRateToDW",0,path);

	this->m_ElementalDamageRateTo[2][1] = GetPrivateProfileInt(section,"FEElementalDamageRateToDK",0,path);

	this->m_ElementalDamageRateTo[2][2] = GetPrivateProfileInt(section,"FEElementalDamageRateToFE",0,path);

	this->m_ElementalDamageRateTo[2][3] = GetPrivateProfileInt(section,"FEElementalDamageRateToMG",0,path);

	this->m_ElementalDamageRateTo[2][4] = GetPrivateProfileInt(section,"FEElementalDamageRateToDL",0,path);

	this->m_ElementalDamageRateTo[2][5] = GetPrivateProfileInt(section,"FEElementalDamageRateToSU",0,path);

	this->m_ElementalDamageRateTo[2][6] = GetPrivateProfileInt(section,"FEElementalDamageRateToRF",0,path);

	this->m_ElementalDamageRateTo[3][0] = GetPrivateProfileInt(section,"MGElementalDamageRateToDW",0,path);

	this->m_ElementalDamageRateTo[3][1] = GetPrivateProfileInt(section,"MGElementalDamageRateToDK",0,path);

	this->m_ElementalDamageRateTo[3][2] = GetPrivateProfileInt(section,"MGElementalDamageRateToFE",0,path);

	this->m_ElementalDamageRateTo[3][3] = GetPrivateProfileInt(section,"MGElementalDamageRateToMG",0,path);

	this->m_ElementalDamageRateTo[3][4] = GetPrivateProfileInt(section,"MGElementalDamageRateToDL",0,path);

	this->m_ElementalDamageRateTo[3][5] = GetPrivateProfileInt(section,"MGElementalDamageRateToSU",0,path);

	this->m_ElementalDamageRateTo[3][6] = GetPrivateProfileInt(section,"MGElementalDamageRateToRF",0,path);

	this->m_ElementalDamageRateTo[4][0] = GetPrivateProfileInt(section,"DLElementalDamageRateToDW",0,path);

	this->m_ElementalDamageRateTo[4][1] = GetPrivateProfileInt(section,"DLElementalDamageRateToDK",0,path);

	this->m_ElementalDamageRateTo[4][2] = GetPrivateProfileInt(section,"DLElementalDamageRateToFE",0,path);

	this->m_ElementalDamageRateTo[4][3] = GetPrivateProfileInt(section,"DLElementalDamageRateToMG",0,path);

	this->m_ElementalDamageRateTo[4][4] = GetPrivateProfileInt(section,"DLElementalDamageRateToDL",0,path);

	this->m_ElementalDamageRateTo[4][5] = GetPrivateProfileInt(section,"DLElementalDamageRateToSU",0,path);

	this->m_ElementalDamageRateTo[4][6] = GetPrivateProfileInt(section,"DLElementalDamageRateToRF",0,path);

	this->m_ElementalDamageRateTo[5][0] = GetPrivateProfileInt(section,"SUElementalDamageRateToDW",0,path);

	this->m_ElementalDamageRateTo[5][1] = GetPrivateProfileInt(section,"SUElementalDamageRateToDK",0,path);

	this->m_ElementalDamageRateTo[5][2] = GetPrivateProfileInt(section,"SUElementalDamageRateToFE",0,path);

	this->m_ElementalDamageRateTo[5][3] = GetPrivateProfileInt(section,"SUElementalDamageRateToMG",0,path);

	this->m_ElementalDamageRateTo[5][4] = GetPrivateProfileInt(section,"SUElementalDamageRateToDL",0,path);

	this->m_ElementalDamageRateTo[5][5] = GetPrivateProfileInt(section,"SUElementalDamageRateToSU",0,path);

	this->m_ElementalDamageRateTo[5][6] = GetPrivateProfileInt(section,"SUElementalDamageRateToRF",0,path);

	this->m_ElementalDamageRateTo[6][0] = GetPrivateProfileInt(section,"RFElementalDamageRateToDW",0,path);

	this->m_ElementalDamageRateTo[6][1] = GetPrivateProfileInt(section,"RFElementalDamageRateToDK",0,path);

	this->m_ElementalDamageRateTo[6][2] = GetPrivateProfileInt(section,"RFElementalDamageRateToFE",0,path);

	this->m_ElementalDamageRateTo[6][3] = GetPrivateProfileInt(section,"RFElementalDamageRateToMG",0,path);

	this->m_ElementalDamageRateTo[6][4] = GetPrivateProfileInt(section,"RFElementalDamageRateToDL",0,path);

	this->m_ElementalDamageRateTo[6][5] = GetPrivateProfileInt(section,"RFElementalDamageRateToSU",0,path);

	this->m_ElementalDamageRateTo[6][6] = GetPrivateProfileInt(section,"RFElementalDamageRateToRF",0,path);

	this->m_DWElementalDefenseConstA = GetPrivateProfileInt(section,"DWElementalDefenseConstA",0,path);

	this->m_DKElementalDefenseConstA = GetPrivateProfileInt(section,"DKElementalDefenseConstA",0,path);

	this->m_FEElementalDefenseConstA = GetPrivateProfileInt(section,"FEElementalDefenseConstA",0,path);

	this->m_MGElementalDefenseConstA = GetPrivateProfileInt(section,"MGElementalDefenseConstA",0,path);

	this->m_DLElementalDefenseConstA = GetPrivateProfileInt(section,"DLElementalDefenseConstA",0,path);

	this->m_SUElementalDefenseConstA = GetPrivateProfileInt(section,"SUElementalDefenseConstA",0,path);

	this->m_RFElementalDefenseConstA = GetPrivateProfileInt(section,"RFElementalDefenseConstA",0,path);

	this->m_DWElementalDamageMinConstA = GetPrivateProfileInt(section,"DWElementalDamageMinConstA",0,path);

	this->m_DWElementalDamageMaxConstA = GetPrivateProfileInt(section,"DWElementalDamageMaxConstA",0,path);

	this->m_DKElementalDamageMinConstA = GetPrivateProfileInt(section,"DKElementalDamageMinConstA",0,path);

	this->m_DKElementalDamageMaxConstA = GetPrivateProfileInt(section,"DKElementalDamageMaxConstA",0,path);

	this->m_FEElementalDamageMinConstA = GetPrivateProfileInt(section,"FEElementalDamageMinConstA",0,path);

	this->m_FEElementalDamageMinConstB = GetPrivateProfileInt(section,"FEElementalDamageMinConstB",0,path);

	this->m_FEElementalDamageMaxConstA = GetPrivateProfileInt(section,"FEElementalDamageMaxConstA",0,path);

	this->m_FEElementalDamageMaxConstB = GetPrivateProfileInt(section,"FEElementalDamageMaxConstB",0,path);

	this->m_MGElementalDamageMinConstA = GetPrivateProfileInt(section,"MGElementalDamageMinConstA",0,path);

	this->m_MGElementalDamageMinConstB = GetPrivateProfileInt(section,"MGElementalDamageMinConstB",0,path);

	this->m_MGElementalDamageMaxConstA = GetPrivateProfileInt(section,"MGElementalDamageMaxConstA",0,path);

	this->m_MGElementalDamageMaxConstB = GetPrivateProfileInt(section,"MGElementalDamageMaxConstB",0,path);

	this->m_DLElementalDamageMinConstA = GetPrivateProfileInt(section,"DLElementalDamageMinConstA",0,path);

	this->m_DLElementalDamageMinConstB = GetPrivateProfileInt(section,"DLElementalDamageMinConstB",0,path);

	this->m_DLElementalDamageMaxConstA = GetPrivateProfileInt(section,"DLElementalDamageMaxConstA",0,path);

	this->m_DLElementalDamageMaxConstB = GetPrivateProfileInt(section,"DLElementalDamageMaxConstB",0,path);

	this->m_SUElementalDamageMinConstA = GetPrivateProfileInt(section,"SUElementalDamageMinConstA",0,path);

	this->m_SUElementalDamageMaxConstA = GetPrivateProfileInt(section,"SUElementalDamageMaxConstA",0,path);

	this->m_RFElementalDamageMinConstA = GetPrivateProfileInt(section,"RFElementalDamageMinConstA",0,path);

	this->m_RFElementalDamageMinConstB = GetPrivateProfileInt(section,"RFElementalDamageMinConstB",0,path);

	this->m_RFElementalDamageMaxConstA = GetPrivateProfileInt(section,"RFElementalDamageMaxConstA",0,path);

	this->m_RFElementalDamageMaxConstB = GetPrivateProfileInt(section,"RFElementalDamageMaxConstB",0,path);

	this->m_DWElementalAttackSuccessRateConstA = GetPrivateProfileInt(section,"DWElementalAttackSuccessRateConstA",0,path);

	this->m_DWElementalAttackSuccessRateConstB = GetPrivateProfileInt(section,"DWElementalAttackSuccessRateConstB",0,path);

	this->m_DWElementalAttackSuccessRateConstC = GetPrivateProfileInt(section,"DWElementalAttackSuccessRateConstC",0,path);

	this->m_DWElementalAttackSuccessRateConstD = GetPrivateProfileInt(section,"DWElementalAttackSuccessRateConstD",0,path);
	
	this->m_DKElementalAttackSuccessRateConstA = GetPrivateProfileInt(section,"DKElementalAttackSuccessRateConstA",0,path);

	this->m_DKElementalAttackSuccessRateConstB = GetPrivateProfileInt(section,"DKElementalAttackSuccessRateConstB",0,path);

	this->m_DKElementalAttackSuccessRateConstC = GetPrivateProfileInt(section,"DKElementalAttackSuccessRateConstC",0,path);

	this->m_DKElementalAttackSuccessRateConstD = GetPrivateProfileInt(section,"DKElementalAttackSuccessRateConstD",0,path);
	
	this->m_FEElementalAttackSuccessRateConstA = GetPrivateProfileInt(section,"FEElementalAttackSuccessRateConstA",0,path);

	this->m_FEElementalAttackSuccessRateConstB = GetPrivateProfileInt(section,"FEElementalAttackSuccessRateConstB",0,path);

	this->m_FEElementalAttackSuccessRateConstC = GetPrivateProfileInt(section,"FEElementalAttackSuccessRateConstC",0,path);

	this->m_FEElementalAttackSuccessRateConstD = GetPrivateProfileInt(section,"FEElementalAttackSuccessRateConstD",0,path);
	
	this->m_MGElementalAttackSuccessRateConstA = GetPrivateProfileInt(section,"MGElementalAttackSuccessRateConstA",0,path);

	this->m_MGElementalAttackSuccessRateConstB = GetPrivateProfileInt(section,"MGElementalAttackSuccessRateConstB",0,path);

	this->m_MGElementalAttackSuccessRateConstC = GetPrivateProfileInt(section,"MGElementalAttackSuccessRateConstC",0,path);

	this->m_MGElementalAttackSuccessRateConstD = GetPrivateProfileInt(section,"MGElementalAttackSuccessRateConstD",0,path);
	
	this->m_DLElementalAttackSuccessRateConstA = GetPrivateProfileInt(section,"DLElementalAttackSuccessRateConstA",0,path);

	this->m_DLElementalAttackSuccessRateConstB = GetPrivateProfileInt(section,"DLElementalAttackSuccessRateConstB",0,path);

	this->m_DLElementalAttackSuccessRateConstC = GetPrivateProfileInt(section,"DLElementalAttackSuccessRateConstC",0,path);

	this->m_DLElementalAttackSuccessRateConstD = GetPrivateProfileInt(section,"DLElementalAttackSuccessRateConstD",0,path);
	
	this->m_SUElementalAttackSuccessRateConstA = GetPrivateProfileInt(section,"SUElementalAttackSuccessRateConstA",0,path);

	this->m_SUElementalAttackSuccessRateConstB = GetPrivateProfileInt(section,"SUElementalAttackSuccessRateConstB",0,path);

	this->m_SUElementalAttackSuccessRateConstC = GetPrivateProfileInt(section,"SUElementalAttackSuccessRateConstC",0,path);

	this->m_SUElementalAttackSuccessRateConstD = GetPrivateProfileInt(section,"SUElementalAttackSuccessRateConstD",0,path);
	
	this->m_RFElementalAttackSuccessRateConstA = GetPrivateProfileInt(section,"RFElementalAttackSuccessRateConstA",0,path);

	this->m_RFElementalAttackSuccessRateConstB = GetPrivateProfileInt(section,"RFElementalAttackSuccessRateConstB",0,path);

	this->m_RFElementalAttackSuccessRateConstC = GetPrivateProfileInt(section,"RFElementalAttackSuccessRateConstC",0,path);

	this->m_RFElementalAttackSuccessRateConstD = GetPrivateProfileInt(section,"RFElementalAttackSuccessRateConstD",0,path);

	this->m_DWElementalDefenseSuccessRateConstA = GetPrivateProfileInt(section,"DWElementalDefenseSuccessRateConstA",0,path);

	this->m_DKElementalDefenseSuccessRateConstA = GetPrivateProfileInt(section,"DKElementalDefenseSuccessRateConstA",0,path);

	this->m_FEElementalDefenseSuccessRateConstA = GetPrivateProfileInt(section,"FEElementalDefenseSuccessRateConstA",0,path);

	this->m_MGElementalDefenseSuccessRateConstA = GetPrivateProfileInt(section,"MGElementalDefenseSuccessRateConstA",0,path);

	this->m_DLElementalDefenseSuccessRateConstA = GetPrivateProfileInt(section,"DLElementalDefenseSuccessRateConstA",0,path);

	this->m_SUElementalDefenseSuccessRateConstA = GetPrivateProfileInt(section,"SUElementalDefenseSuccessRateConstA",0,path);

	this->m_RFElementalDefenseSuccessRateConstA = GetPrivateProfileInt(section,"RFElementalDefenseSuccessRateConstA",0,path);

	#endif
}

void CServerInfo::ReadCommonInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	this->m_PersonalShopCustom = GetPrivateProfileInt(section, "PersonalShopCustom", 0, path);

	this->m_RecycleSerial = GetPrivateProfileInt(section, "RecycleSerial", 0, path);

	this->m_DuelCount = GetPrivateProfileInt(section, "DuelFightCount", 5, path);

	this->m_ServerMaxUserNumber = GetPrivateProfileInt(section,"ServerMaxUserNumber",0,path);

	this->m_MainChecksum = GetPrivateProfileInt(section,"MainChecksum",0,path);

	this->m_MaxItemOption = GetPrivateProfileInt(section,"MaxItemOption",0,path);

	this->m_MaxIpConnection = GetPrivateProfileInt(section,"MaxIpConnection",0,path);

	this->m_PersonalCodeCheck = GetPrivateProfileInt(section,"PersonalCodeCheck",0,path);

	this->m_InfinitArrows = GetPrivateProfileInt(section, "InfinitArrows", 0, path);

	this->m_UserLoggoutTimer = GetPrivateProfileInt(section, "UserLoggoutTimer", 5, path);

	this->m_SelfDefenseTimer = GetPrivateProfileInt(section, "SelfDefenseTimer", 60, path);

	this->m_PlayerKillStaff = GetPrivateProfileInt(section, "StaffDeathPlayer", 1, path);

	this->m_StaffKillPlayer = GetPrivateProfileInt(section, "StaffKillPlayer", 0, path);

	this->m_StaffKillStaff = GetPrivateProfileInt(section, "StaffKillStaff", 1, path);

	this->m_ComboSwitch = GetPrivateProfileInt(section, "ComboSwitch", 1, path);

	this->m_SetItemAcceptHarmonySwitch = GetPrivateProfileInt(section,"SetItemAcceptHarmonySwitch",0,path);

	this->m_MonsterLifeRate = GetPrivateProfileInt(section,"MonsterLifeRate",0,path);

	#if(GAMESERVER_UPDATE<=603)

	this->m_MonsterHealthBarSwitch = GetPrivateProfileInt(section,"MonsterHealthBarSwitch",0,path);

	#endif

	this->m_NonPK = GetPrivateProfileInt(section,"NonPK",0,path);

	this->m_PKLimitFree = GetPrivateProfileInt(section,"PKLimitFree",0,path);

	this->m_PKDownTime1 = GetPrivateProfileInt(section,"PKDownTime1",0,path);

	this->m_PKDownTime2 = GetPrivateProfileInt(section,"PKDownTime2",0,path);

	this->m_SelfDefenseTime = GetPrivateProfileInt(section, "SelfDefenseTime", 0, path);

	this->m_TradeSwitch = GetPrivateProfileInt(section,"TradeSwitch",0,path);

	this->m_TradeXSwitch = GetPrivateProfileInt(section, "TradeXSwitch", 0, path);

	this->m_ChaosBoxGenesisSwitch = GetPrivateProfileInt(section, "ChaosBoxGenesisSwitch", 1, path);

	this->m_PersonalShopSwitch = GetPrivateProfileInt(section,"PersonalShopSwitch",0,path);

	#if(GAMESERVER_UPDATE>=802)

	this->m_PersonalShopMoneyCommisionRate = GetPrivateProfileInt(section,"PersonalShopMoneyCommisionRate",0,path);

	this->m_PersonalShopJewelCommisionRate = GetPrivateProfileInt(section,"PersonalShopJewelCommisionRate",0,path);

	#endif

	this->m_DuelSwitch = GetPrivateProfileInt(section,"DuelSwitch",0,path);

	#if(GAMESERVER_UPDATE>=402 || GAMESERVER_UPDATE == 201)
	this->m_DuelArenaAnnounceSwitch = GetPrivateProfileInt(section,"DuelArenaAnnounceSwitch",0,path);
	#endif

	this->m_GuildCreateSwitch = GetPrivateProfileInt(section,"GuildCreateSwitch",0,path);

	this->m_GuildDeleteSwitch = GetPrivateProfileInt(section,"GuildDeleteSwitch",0,path);

	this->m_GuildCreateMinLevel = GetPrivateProfileInt(section,"GuildCreateMinLevel",0,path);

	this->m_GuildInsertMaxUser1 = GetPrivateProfileInt(section,"GuildInsertMaxUser1",0,path);

	if (this->m_GuildInsertMaxUser1 >= MAX_GUILD_USER) { this->m_GuildInsertMaxUser1 = MAX_GUILD_USER; }

	this->m_GuildInsertMaxUser2 = GetPrivateProfileInt(section,"GuildInsertMaxUser2",0,path);

	if (this->m_GuildInsertMaxUser2 >= MAX_GUILD_USER) { this->m_GuildInsertMaxUser2 = MAX_GUILD_USER; }

	this->m_GuildAllianceMinUser = GetPrivateProfileInt(section,"GuildAllianceMinUser",0,path);

	this->m_GuildAllianceMaxCount = GetPrivateProfileInt(section,"GuildAllianceMaxCount",0,path);

	this->m_GuildOwnerDestroyLimit = GetPrivateProfileInt(section,"GuildOwnerDestroyLimit",0,path);

	this->m_ElfBufferMaxLevel[0] = GetPrivateProfileInt(section,"ElfBufferMaxLevel_FREE",0,path);

	this->m_ElfBufferMaxLevel[1] = GetPrivateProfileInt(section,"ElfBufferMaxLevel_VIP1",0,path);

	this->m_ElfBufferMaxLevel[2] = GetPrivateProfileInt(section,"ElfBufferMaxLevel_VIP2",0,path);

	this->m_ElfBufferMaxLevel[3] = GetPrivateProfileInt(section,"ElfBufferMaxLevel_VIP3",0,path);

	this->m_ElfBufferMaxReset[0] = GetPrivateProfileInt(section,"ElfBufferMaxReset_FREE",0,path);

	this->m_ElfBufferMaxReset[1] = GetPrivateProfileInt(section,"ElfBufferMaxReset_VIP1",0,path);

	this->m_ElfBufferMaxReset[2] = GetPrivateProfileInt(section,"ElfBufferMaxReset_VIP2",0,path);

	this->m_ElfBufferMaxReset[3] = GetPrivateProfileInt(section,"ElfBufferMaxReset_VIP3",0,path);

	this->m_ElfBufferDamageConstA = GetPrivateProfileInt(section,"ElfBufferDamageConstA",0,path);

	this->m_ElfBufferDamageConstB = GetPrivateProfileInt(section,"ElfBufferDamageConstB",0,path);

	this->m_ElfBufferDefenseConstA = GetPrivateProfileInt(section,"ElfBufferDefenseConstA",0,path);

	this->m_ElfBufferDefenseConstB = GetPrivateProfileInt(section,"ElfBufferDefenseConstB",0,path);

	this->m_AddExperienceRate[0] = GetPrivateProfileInt(section,"AddExperienceRate_FREE",0,path);

	this->m_AddExperienceRate[1] = GetPrivateProfileInt(section,"AddExperienceRate_VIP1",0,path);

	this->m_AddExperienceRate[2] = GetPrivateProfileInt(section,"AddExperienceRate_VIP2",0,path);

	this->m_AddExperienceRate[3] = GetPrivateProfileInt(section,"AddExperienceRate_VIP3",0,path);

	#if(GAMESERVER_UPDATE>=401)

	this->m_AddMasterExperienceRate[0] = GetPrivateProfileInt(section,"AddMasterExperienceRate_FREE",0,path);

	this->m_AddMasterExperienceRate[1] = GetPrivateProfileInt(section,"AddMasterExperienceRate_VIP1",0,path);

	this->m_AddMasterExperienceRate[2] = GetPrivateProfileInt(section,"AddMasterExperienceRate_VIP2",0,path);

	this->m_AddMasterExperienceRate[3] = GetPrivateProfileInt(section,"AddMasterExperienceRate_VIP3",0,path);

	this->m_MinMasterExperienceMonsterLevel[0] = GetPrivateProfileInt(section,"MinMasterExperienceMonsterLevel_FREE",0,path);

	this->m_MinMasterExperienceMonsterLevel[1] = GetPrivateProfileInt(section,"MinMasterExperienceMonsterLevel_VIP1",0,path);

	this->m_MinMasterExperienceMonsterLevel[2] = GetPrivateProfileInt(section,"MinMasterExperienceMonsterLevel_VIP2",0,path);

	this->m_MinMasterExperienceMonsterLevel[3] = GetPrivateProfileInt(section,"MinMasterExperienceMonsterLevel_VIP3",0,path);

	#endif

	this->m_AddEventExperienceRate[0] = GetPrivateProfileInt(section,"AddEventExperienceRate_FREE",0,path);

	this->m_AddEventExperienceRate[1] = GetPrivateProfileInt(section,"AddEventExperienceRate_VIP1",0,path);

	this->m_AddEventExperienceRate[2] = GetPrivateProfileInt(section,"AddEventExperienceRate_VIP2",0,path);

	this->m_AddEventExperienceRate[3] = GetPrivateProfileInt(section,"AddEventExperienceRate_VIP3",0,path);

	#if(GAMESERVER_UPDATE>=501)

	this->m_AddQuestExperienceRate[0] = GetPrivateProfileInt(section,"AddQuestExperienceRate_FREE",0,path);

	this->m_AddQuestExperienceRate[1] = GetPrivateProfileInt(section,"AddQuestExperienceRate_VIP1",0,path);

	this->m_AddQuestExperienceRate[2] = GetPrivateProfileInt(section,"AddQuestExperienceRate_VIP2",0,path);

	this->m_AddQuestExperienceRate[3] = GetPrivateProfileInt(section,"AddQuestExperienceRate_VIP3",0,path);

	#endif

	this->m_ItemDropTime = GetPrivateProfileInt(section,"ItemDropTime",0,path);

	this->m_ItemDropRate[0] = GetPrivateProfileInt(section,"ItemDropRate_FREE",0,path);

	this->m_ItemDropRate[1] = GetPrivateProfileInt(section,"ItemDropRate_VIP1",0,path);

	this->m_ItemDropRate[2] = GetPrivateProfileInt(section,"ItemDropRate_VIP2",0,path);

	this->m_ItemDropRate[3] = GetPrivateProfileInt(section,"ItemDropRate_VIP3",0,path);

	this->m_MoneyDropTime = GetPrivateProfileInt(section,"MoneyDropTime",0,path);

	this->m_MoneyAmountDropRate[0] = GetPrivateProfileInt(section,"MoneyAmountDropRate_FREE",0,path);

	this->m_MoneyAmountDropRate[1] = GetPrivateProfileInt(section,"MoneyAmountDropRate_VIP1",0,path);

	this->m_MoneyAmountDropRate[2] = GetPrivateProfileInt(section,"MoneyAmountDropRate_VIP2",0,path);

	this->m_MoneyAmountDropRate[3] = GetPrivateProfileInt(section,"MoneyAmountDropRate_VIP3",0,path);

	this->m_MoneyAdvancedValue[0] = GetPrivateProfileInt(section, "MoneyValue_FREE", 0, path);

	this->m_MoneyAdvancedValue[1] = GetPrivateProfileInt(section, "MoneyValue_VIP1", 0, path);

	this->m_MoneyAdvancedValue[2] = GetPrivateProfileInt(section, "MoneyValue_VIP2", 0, path);

	this->m_MoneyAdvancedValue[3] = GetPrivateProfileInt(section, "MoneyValue_VIP3", 0, path);

	this->m_PetsImortal = GetPrivateProfileInt(section, "PetsImortal", 0, path);

	this->m_NewPetsImortal = GetPrivateProfileInt(section, "NewPetsImortal", 0, path);

	this->m_WeaponDurabilityRate = GetPrivateProfileInt(section,"WeaponDurabilityRate",0,path);

	this->m_ArmorDurabilityRate = GetPrivateProfileInt(section,"ArmorDurabilityRate",0,path);

	this->m_WingDurabilityRate = GetPrivateProfileInt(section,"WingDurabilityRate",0,path);

	this->m_GuardianDurabilityRate = GetPrivateProfileInt(section,"GuardianDurabilityRate",0,path);

	this->m_PendantDurabilityRate = GetPrivateProfileInt(section,"PendantDurabilityRate",0,path);

	this->m_RingDurabilityRate = GetPrivateProfileInt(section,"RingDurabilityRate",0,path);

	this->m_PetDurabilityRate = GetPrivateProfileInt(section,"PetDurabilityRate",0,path);

	#if(GAMESERVER_UPDATE>=803)

	this->m_MuunDurabilityRate = GetPrivateProfileInt(section,"MuunDurabilityRate",0,path);

	#endif

	this->m_TradeItemBlock = GetPrivateProfileInt(section,"TradeItemBlock",0,path);

	this->m_TradeItemBlockExc = GetPrivateProfileInt(section,"TradeItemBlockExc",0,path);

	this->m_TradeItemBlockSet = GetPrivateProfileInt(section,"TradeItemBlockSet",0,path);

	this->m_TradeItemBlockHarmony = GetPrivateProfileInt(section,"TradeItemBlockHarmony",0,path);

	this->m_TradeItemBlockSell = GetPrivateProfileInt(section,"TradeItemBlockSell",0,path);

	this->m_MaxLevel = GetPrivateProfileInt(section, "MaxLevel", 400, path);

	this->m_MaxLevelUp = GetPrivateProfileInt(section,"MaxLevelUp",1,path);

	this->m_MaxLevelUpEvent = GetPrivateProfileInt(section,"MaxLevelUpEvent",1,path);

	#if(GAMESERVER_UPDATE>=501)

	this->m_MaxLevelUpQuest = GetPrivateProfileInt(section,"MaxLevelUpQuest",0,path);

	#endif

	this->m_MaxStatPoint[0] = GetPrivateProfileInt(section,"MaxStatPoint_FREE",0,path);

	this->m_MaxStatPoint[1] = GetPrivateProfileInt(section,"MaxStatPoint_VIP1",0,path);

	this->m_MaxStatPoint[2] = GetPrivateProfileInt(section,"MaxStatPoint_VIP2",0,path);

	this->m_MaxStatPoint[3] = GetPrivateProfileInt(section,"MaxStatPoint_VIP3",0,path);

	this->m_LevelUpPoint[0] = GetPrivateProfileInt(section,"DWLevelUpPoint",0,path);

	this->m_LevelUpPoint[1] = GetPrivateProfileInt(section,"DKLevelUpPoint",0,path);

	this->m_LevelUpPoint[2] = GetPrivateProfileInt(section,"FELevelUpPoint",0,path);

	this->m_LevelUpPoint[3] = GetPrivateProfileInt(section,"MGLevelUpPoint",0,path);

	this->m_LevelUpPoint[4] = GetPrivateProfileInt(section,"DLLevelUpPoint",0,path);

	#if(GAMESERVER_UPDATE>=301)

	this->m_LevelUpPoint[5] = GetPrivateProfileInt(section,"SULevelUpPoint",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=601)

	this->m_LevelUpPoint[6] = GetPrivateProfileInt(section,"RFLevelUpPoint",0,path);

	#endif

	this->m_PlusStatPoint = GetPrivateProfileInt(section,"PlusStatPoint",0,path);

	this->m_CharacterCreateSwitch = GetPrivateProfileInt(section,"CharacterCreateSwitch",0,path);

	this->m_MGCreateType = GetPrivateProfileInt(section,"MGCreateType",0,path);

	this->m_DLCreateType = GetPrivateProfileInt(section,"DLCreateType",0,path);

	#if(GAMESERVER_UPDATE>=301)

	this->m_SUCreateType = GetPrivateProfileInt(section,"SUCreateType",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFCreateType = GetPrivateProfileInt(section,"RFCreateType",0,path);

	#endif

	this->m_MGCreateLevel[0] = GetPrivateProfileInt(section,"MGCreateLevel_FREE",0,path);

	this->m_MGCreateLevel[1] = GetPrivateProfileInt(section,"MGCreateLevel_VIP1",0,path);

	this->m_MGCreateLevel[2] = GetPrivateProfileInt(section,"MGCreateLevel_VIP2",0,path);

	this->m_MGCreateLevel[3] = GetPrivateProfileInt(section,"MGCreateLevel_VIP3",0,path);

	this->m_DLCreateLevel[0] = GetPrivateProfileInt(section,"DLCreateLevel_FREE",0,path);

	this->m_DLCreateLevel[1] = GetPrivateProfileInt(section,"DLCreateLevel_VIP1",0,path);

	this->m_DLCreateLevel[2] = GetPrivateProfileInt(section,"DLCreateLevel_VIP2",0,path);

	this->m_DLCreateLevel[3] = GetPrivateProfileInt(section,"DLCreateLevel_VIP3",0,path);

	#if(GAMESERVER_UPDATE>=301)

	this->m_SUCreateLevel[0] = GetPrivateProfileInt(section,"SUCreateLevel_FREE",0,path);

	this->m_SUCreateLevel[1] = GetPrivateProfileInt(section,"SUCreateLevel_VIP1",0,path);

	this->m_SUCreateLevel[2] = GetPrivateProfileInt(section,"SUCreateLevel_VIP2",0,path);

	this->m_SUCreateLevel[3] = GetPrivateProfileInt(section,"SUCreateLevel_VIP3",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=601)

	this->m_RFCreateLevel[0] = GetPrivateProfileInt(section,"RFCreateLevel_FREE",0,path);

	this->m_RFCreateLevel[1] = GetPrivateProfileInt(section,"RFCreateLevel_VIP1",0,path);

	this->m_RFCreateLevel[2] = GetPrivateProfileInt(section,"RFCreateLevel_VIP2",0,path);

	this->m_RFCreateLevel[3] = GetPrivateProfileInt(section,"RFCreateLevel_VIP3",0,path);

	#endif

	this->m_ShieldGaugeRate = GetPrivateProfileInt(section,"ShieldGaugeRate",0,path);

	this->m_ShieldGaugeConstA = GetPrivateProfileInt(section,"ShieldGaugeConstA",0,path);

	this->m_ShieldGaugeConstB = GetPrivateProfileInt(section,"ShieldGaugeConstB",0,path);

	this->m_ShieldGaugeAttackRate = GetPrivateProfileInt(section,"ShieldGaugeAttackRate",0,path);

	this->m_ShieldGaugeAttackComboMiss = GetPrivateProfileInt(section,"ShieldGaugeAttackComboMiss",0,path);

	this->m_ShieldGaugeDisable = GetPrivateProfileInt(section, "ShieldGaugeDisable", 0, path);

	#if(GAMESERVER_UPDATE>=401)

	this->m_MasterSkillTree = GetPrivateProfileInt(section,"MasterSkillTree",0,path);

	this->m_MasterSkillTreePoint = GetPrivateProfileInt(section,"MasterSkillTreePoint",0,path);

	this->m_MasterSkillTreeMaxLevel = GetPrivateProfileInt(section,"MasterSkillTreeMaxLevel",0,path);

	this->m_MasterSkillTreeStartLevel = GetPrivateProfileInt(section, "MasterSkillTreeStartLevel", 400, path);

	#endif

	#if(GAMESERVER_UPDATE>=250 && GAMESERVER_UPDATE<=402)

	this->m_PcPointSwitch = GetPrivateProfileInt(section,"PcPointSwitch",0,path);

	this->m_PcPointMaxPoint = GetPrivateProfileInt(section,"PcPointMaxPoint",0,path);

	this->m_PcPointPointDelay = GetPrivateProfileInt(section,"PcPointPointDelay",0,path);

	this->m_PcPointPointValue[0] = GetPrivateProfileInt(section,"PcPointPointValue_FREE",0,path);

	this->m_PcPointPointValue[1] = GetPrivateProfileInt(section,"PcPointPointValue_VIP1",0,path);

	this->m_PcPointPointValue[2] = GetPrivateProfileInt(section,"PcPointPointValue_VIP2",0,path);

	this->m_PcPointPointValue[3] = GetPrivateProfileInt(section,"PcPointPointValue_VIP3",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=501)

	this->m_GensSystemSwitch = GetPrivateProfileInt(section,"GensSystemSwitch",0,path);

	this->m_GensSystemGuildLock = GetPrivateProfileInt(section,"GensSystemGuildLock",0,path);

	this->m_GensSystemPartyLock = GetPrivateProfileInt(section,"GensSystemPartyLock",0,path);

	this->m_GensSystemInsertMinLevel = GetPrivateProfileInt(section,"GensSystemInsertMinLevel",0,path);

	this->m_GensSystemContributionFloodTime = GetPrivateProfileInt(section,"GensSystemContributionFloodTime",0,path);

	this->m_GensSystemVictimContributionDecrease = GetPrivateProfileInt(section,"GensSystemVictimContributionDecrease",0,path);

	this->m_GensSystemKillerContributionIncrease = GetPrivateProfileInt(section,"GensSystemKillerContributionIncrease",0,path);

	this->m_GensSystemVictimMinContributionDecrease = GetPrivateProfileInt(section,"GensSystemVictimMinContributionDecrease",0,path);

	this->m_GensSystemVictimMaxContributionDecrease = GetPrivateProfileInt(section,"GensSystemVictimMaxContributionDecrease",0,path);

	this->m_GensSystemKillerMinContributionIncrease = GetPrivateProfileInt(section,"GensSystemKillerMinContributionIncrease",0,path);

	this->m_GensSystemKillerMaxContributionIncrease = GetPrivateProfileInt(section,"GensSystemKillerMaxContributionIncrease",0,path);

	this->m_GensSystemStartRewardDay = GetPrivateProfileInt(section,"GensSystemStartRewardDay",0,path);

	this->m_GensSystemFinalRewardDay = GetPrivateProfileInt(section,"GensSystemFinalRewardDay",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=603)

	this->m_HelperSwitch = GetPrivateProfileInt(section,"HelperSwitch",0,path);

	this->m_HelperActiveLevel = GetPrivateProfileInt(section,"HelperActiveLevel",0,path);

	this->m_HelperActiveDelay = GetPrivateProfileInt(section,"HelperActiveDelay",0,path);

	this->m_HelperActiveMoney[0] = GetPrivateProfileInt(section,"HelperActiveMoney1",0,path);

	this->m_HelperActiveMoney[1] = GetPrivateProfileInt(section,"HelperActiveMoney2",0,path);

	this->m_HelperActiveMoney[2] = GetPrivateProfileInt(section,"HelperActiveMoney3",0,path);

	this->m_HelperActiveMoney[3] = GetPrivateProfileInt(section,"HelperActiveMoney4",0,path);

	this->m_HelperActiveMoney[4] = GetPrivateProfileInt(section,"HelperActiveMoney5",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=802)

	this->m_EventInventorySwitch = GetPrivateProfileInt(section,"EventInventorySwitch",0,path);

	this->m_EventInventoryExpireYear = GetPrivateProfileInt(section,"EventInventoryExpireYear",0,path);

	this->m_EventInventoryExpireMonth = GetPrivateProfileInt(section,"EventInventoryExpireMonth",0,path);

	this->m_EventInventoryExpireDay = GetPrivateProfileInt(section,"EventInventoryExpireDay",0,path);

	this->m_MuRummySwitch = GetPrivateProfileInt(section,"MuRummySwitch",0,path);

	this->m_MuRummyRewardScore1 = GetPrivateProfileInt(section,"MuRummyRewardScore1",0,path);

	this->m_MuRummyRewardScore2 = GetPrivateProfileInt(section,"MuRummyRewardScore2",0,path);

	this->m_MuRummyRewardMoneyAmount = GetPrivateProfileInt(section,"MuRummyRewardMoneyAmount",0,path);

	#endif

	this->m_PartyReconnectTime = GetPrivateProfileInt(section,"PartyReconnectTime",0,path);

	this->m_PartyGeneralExperience[0] = GetPrivateProfileInt(section,"PartyGeneralExperience1",0,path);

	this->m_PartyGeneralExperience[1] = GetPrivateProfileInt(section,"PartyGeneralExperience2",0,path);

	this->m_PartyGeneralExperience[2] = GetPrivateProfileInt(section,"PartyGeneralExperience3",0,path);

	this->m_PartyGeneralExperience[3] = GetPrivateProfileInt(section,"PartyGeneralExperience4",0,path);

	this->m_PartyGeneralExperience[4] = GetPrivateProfileInt(section,"PartyGeneralExperience5",0,path);

	this->m_PartySpecialExperience[0] = GetPrivateProfileInt(section,"PartySpecialExperience1",0,path);

	this->m_PartySpecialExperience[1] = GetPrivateProfileInt(section,"PartySpecialExperience2",0,path);

	this->m_PartySpecialExperience[2] = GetPrivateProfileInt(section,"PartySpecialExperience3",0,path);

	this->m_PartySpecialExperience[3] = GetPrivateProfileInt(section,"PartySpecialExperience4",0,path);

	this->m_PartySpecialExperience[4] = GetPrivateProfileInt(section,"PartySpecialExperience5",0,path);

	this->m_PotionInfinite = GetPrivateProfileInt(section, "PotionInfinite", 0, path);

	this->m_ApplePotionRate = GetPrivateProfileInt(section,"ApplePotionRate",0,path);

	this->m_SmallLifePotionRate = GetPrivateProfileInt(section,"SmallLifePotionRate",0,path);

	this->m_MidleLifePotionRate = GetPrivateProfileInt(section,"MidleLifePotionRate",0,path);

	this->m_LargeLifePotionRate = GetPrivateProfileInt(section,"LargeLifePotionRate",0,path);

	this->m_SmallManaPotionRate = GetPrivateProfileInt(section,"SmallManaPotionRate",0,path);

	this->m_MidleManaPotionRate = GetPrivateProfileInt(section,"MidleManaPotionRate",0,path);

	this->m_LargeManaPotionRate = GetPrivateProfileInt(section,"LargeManaPotionRate",0,path);

	this->m_SmallShieldPotionRate = GetPrivateProfileInt(section,"SmallShieldPotionRate",0,path);

	this->m_MidleShieldPotionRate = GetPrivateProfileInt(section,"MidleShieldPotionRate",0,path);

	this->m_LargeShieldPotionRate = GetPrivateProfileInt(section,"LargeShieldPotionRate",0,path);

	this->m_SmallCompoundPotionRate1 = GetPrivateProfileInt(section,"SmallCompoundPotionRate1",0,path);

	this->m_SmallCompoundPotionRate2 = GetPrivateProfileInt(section,"SmallCompoundPotionRate2",0,path);

	this->m_MidleCompoundPotionRate1 = GetPrivateProfileInt(section,"MidleCompoundPotionRate1",0,path);

	this->m_MidleCompoundPotionRate2 = GetPrivateProfileInt(section,"MidleCompoundPotionRate2",0,path);

	this->m_LargeCompoundPotionRate1 = GetPrivateProfileInt(section,"LargeCompoundPotionRate1",0,path);

	this->m_LargeCompoundPotionRate2 = GetPrivateProfileInt(section,"LargeCompoundPotionRate2",0,path);

	this->m_EliteLifePotionRate = GetPrivateProfileInt(section,"EliteLifePotionRate",0,path);

	this->m_EliteManaPotionRate = GetPrivateProfileInt(section,"EliteManaPotionRate",0,path);

	this->m_EliteShieldPotionRate = GetPrivateProfileInt(section,"EliteShieldPotionRate",0,path);

	this->m_TransformationRing1 = GetPrivateProfileInt(section,"TransformationRing1",0,path);

	this->m_TransformationRing2 = GetPrivateProfileInt(section,"TransformationRing2",0,path);

	this->m_TransformationRing3 = GetPrivateProfileInt(section,"TransformationRing3",0,path);

	this->m_TransformationRing4 = GetPrivateProfileInt(section,"TransformationRing4",0,path);

	this->m_TransformationRing5 = GetPrivateProfileInt(section,"TransformationRing5",0,path);

	this->m_TransformationRing6 = GetPrivateProfileInt(section,"TransformationRing6",0,path);

	this->m_SoulSuccessRate[0] = GetPrivateProfileInt(section,"SoulSuccessRate_FREE",0,path);

	this->m_SoulSuccessRate[1] = GetPrivateProfileInt(section,"SoulSuccessRate_VIP1",0,path);

	this->m_SoulSuccessRate[2] = GetPrivateProfileInt(section,"SoulSuccessRate_VIP2",0,path);

	this->m_SoulSuccessRate[3] = GetPrivateProfileInt(section,"SoulSuccessRate_VIP3",0,path);

	this->m_LifeSuccessRate[0] = GetPrivateProfileInt(section,"LifeSuccessRate_FREE",0,path);

	this->m_LifeSuccessRate[1] = GetPrivateProfileInt(section,"LifeSuccessRate_VIP1",0,path);

	this->m_LifeSuccessRate[2] = GetPrivateProfileInt(section,"LifeSuccessRate_VIP2",0,path);

	this->m_LifeSuccessRate[3] = GetPrivateProfileInt(section,"LifeSuccessRate_VIP3",0,path);

	this->m_HarmonySuccessRate[0] = GetPrivateProfileInt(section,"HarmonySuccessRate_FREE",0,path);

	this->m_HarmonySuccessRate[1] = GetPrivateProfileInt(section,"HarmonySuccessRate_VIP1",0,path);

	this->m_HarmonySuccessRate[2] = GetPrivateProfileInt(section,"HarmonySuccessRate_VIP2",0,path);

	this->m_HarmonySuccessRate[3] = GetPrivateProfileInt(section,"HarmonySuccessRate_VIP3",0,path);

	this->m_SmeltStoneSuccessRate1[0] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate1_FREE",0,path);

	this->m_SmeltStoneSuccessRate1[1] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate1_VIP1",0,path);

	this->m_SmeltStoneSuccessRate1[2] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate1_VIP2",0,path);

	this->m_SmeltStoneSuccessRate1[3] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate1_VIP3",0,path);

	this->m_SmeltStoneSuccessRate2[0] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate2_FREE",0,path);

	this->m_SmeltStoneSuccessRate2[1] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate2_VIP1",0,path);

	this->m_SmeltStoneSuccessRate2[2] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate2_VIP2",0,path);

	this->m_SmeltStoneSuccessRate2[3] = GetPrivateProfileInt(section,"SmeltStoneSuccessRate2_VIP3",0,path);

	this->m_AddLuckSuccessRate1[0] = GetPrivateProfileInt(section,"AddLuckSuccessRate1_FREE",0,path);

	this->m_AddLuckSuccessRate1[1] = GetPrivateProfileInt(section,"AddLuckSuccessRate1_VIP1",0,path);

	this->m_AddLuckSuccessRate1[2] = GetPrivateProfileInt(section,"AddLuckSuccessRate1_VIP2",0,path);

	this->m_AddLuckSuccessRate1[3] = GetPrivateProfileInt(section,"AddLuckSuccessRate1_VIP3",0,path);

	this->m_AddLuckSuccessRate2[0] = GetPrivateProfileInt(section,"AddLuckSuccessRate2_FREE",0,path);

	this->m_AddLuckSuccessRate2[1] = GetPrivateProfileInt(section,"AddLuckSuccessRate2_VIP1",0,path);

	this->m_AddLuckSuccessRate2[2] = GetPrivateProfileInt(section,"AddLuckSuccessRate2_VIP2",0,path);

	this->m_AddLuckSuccessRate2[3] = GetPrivateProfileInt(section,"AddLuckSuccessRate2_VIP3",0,path);

	this->m_FruitAddPointMin = GetPrivateProfileInt(section,"FruitAddPointMin",0,path);

	this->m_FruitAddPointMax = GetPrivateProfileInt(section,"FruitAddPointMax",0,path);

	this->m_FruitAddPointSuccessRate[0] = GetPrivateProfileInt(section,"FruitAddPointSuccessRate_FREE",0,path);

	this->m_FruitAddPointSuccessRate[1] = GetPrivateProfileInt(section,"FruitAddPointSuccessRate_VIP1",0,path);

	this->m_FruitAddPointSuccessRate[2] = GetPrivateProfileInt(section,"FruitAddPointSuccessRate_VIP2",0,path);

	this->m_FruitAddPointSuccessRate[3] = GetPrivateProfileInt(section,"FruitAddPointSuccessRate_VIP3",0,path);

	this->m_FruitSubPointMin = GetPrivateProfileInt(section,"FruitSubPointMin",0,path);

	this->m_FruitSubPointMax = GetPrivateProfileInt(section,"FruitSubPointMax",0,path);

	this->m_FruitSubPointSuccessRate[0] = GetPrivateProfileInt(section,"FruitSubPointSuccessRate_FREE",0,path);

	this->m_FruitSubPointSuccessRate[1] = GetPrivateProfileInt(section,"FruitSubPointSuccessRate_VIP1",0,path);

	this->m_FruitSubPointSuccessRate[2] = GetPrivateProfileInt(section,"FruitSubPointSuccessRate_VIP2",0,path);

	this->m_FruitSubPointSuccessRate[3] = GetPrivateProfileInt(section,"FruitSubPointSuccessRate_VIP3",0,path);
}

void CServerInfo::ReadCustomInfo(char* section,char* path) // OK
{
	//Custom AutoPotion
	this->m_CustomAutoPotionSwitch[0] = GetPrivateProfileInt(section, "CustomAutoPotionSwitch_AL0", 0, path);
	this->m_CustomAutoPotionSwitch[1] = GetPrivateProfileInt(section, "CustomAutoPotionSwitch_AL1", 0, path);
	this->m_CustomAutoPotionSwitch[2] = GetPrivateProfileInt(section, "CustomAutoPotionSwitch_AL2", 0, path);
	this->m_CustomAutoPotionSwitch[3] = GetPrivateProfileInt(section, "CustomAutoPotionSwitch_AL3", 0, path);

	this->m_CustomAutoPotionDelay = GetPrivateProfileInt(section, "CustomAutoPotionDelay", 0, path);

	char GameServerInfo[100] = {0};

	this->m_AnnounceChaosMix = GetPrivateProfileInt(section,"AnnounceChaosMix",0,path);

	GetPrivateProfileString(section,"AnnounceChaosMixText","",this->m_AnnounceChaosMixText,sizeof(this->m_AnnounceChaosMixText),path);
}

void CServerInfo::ReadEventInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	this->m_BloodCastleEvent = GetPrivateProfileInt(section,"BloodCastleEvent",0,path);

	this->m_BloodCastleMaxUser = GetPrivateProfileInt(section,"BloodCastleMaxUser",0,path);

	this->m_BonusManagerSwitch = GetPrivateProfileInt(section,"BonusManagerSwitch",0,path);

	this->m_CastleDeepEvent = GetPrivateProfileInt(section,"CastleDeepEvent",0,path);

	this->m_CastleDeepEventTime = GetPrivateProfileInt(section,"CastleDeepEventTime",0,path);

	this->m_CastleSiegeEvent = GetPrivateProfileInt(section,"CastleSiegeEvent",0,path);

	this->m_CastleSiegeCycleStartYear = GetPrivateProfileInt(section,"CastleSiegeCycleStartYear",0,path);

	this->m_CastleSiegeCycleStartMonth = GetPrivateProfileInt(section,"CastleSiegeCycleStartMonth",0,path);

	this->m_CastleSiegeCycleStartDay = GetPrivateProfileInt(section,"CastleSiegeCycleStartDay",0,path);

	this->m_CastleSiegeSpecificState = GetPrivateProfileInt(section,"CastleSiegeSpecificState",0,path);

	this->m_CastleSiegeStateStartYear = GetPrivateProfileInt(section,"CastleSiegeStateStartYear",0,path);

	this->m_CastleSiegeStateStartMonth = GetPrivateProfileInt(section,"CastleSiegeStateStartMonth",0,path);

	this->m_CastleSiegeStateStartDay = GetPrivateProfileInt(section,"CastleSiegeStateStartDay",0,path);

	this->m_CastleSiegeStateStartHour = GetPrivateProfileInt(section,"CastleSiegeStateStartHour",0,path);

	this->m_CastleSiegeStateStartMinute = GetPrivateProfileInt(section,"CastleSiegeStateStartMinute",0,path);

	this->m_CastleSiegeOffensiveWeaponDamage = GetPrivateProfileInt(section,"CastleSiegeOffensiveWeaponDamage",0,path);

	this->m_CastleSiegeDefensiveWeaponDamage = GetPrivateProfileInt(section,"CastleSiegeDefensiveWeaponDamage",0,path);

	this->m_CastleSiegeDecayAccumulatedTimeValue = GetPrivateProfileInt(section,"CastleSiegeDecayAccumulatedTimeValue",0,path);

	this->m_CastleSiegeLowerAccumulatedTimeValue = GetPrivateProfileInt(section,"CastleSiegeLowerAccumulatedTimeValue",0,path);

	this->m_ChaosCastleEvent = GetPrivateProfileInt(section,"ChaosCastleEvent",0,path);

	this->m_ChaosCastleMinUser = GetPrivateProfileInt(section,"ChaosCastleMinUser",0,path);

	this->m_ChaosCastleBlowUserRate = GetPrivateProfileInt(section,"ChaosCastleBlowUserRate",0,path);

	#if(GAMESERVER_UPDATE>=201)
	gCrywolfSync.SetEnableCrywolf((this->m_CrywolfEvent=GetPrivateProfileInt(section,"CrywolfEvent",0,path)));

	gCrywolfSync.SetApplyBenefit((this->m_CrywolfBenefitSwitch=GetPrivateProfileInt(section,"CrywolfBenefitSwitch",0,path)));

	gCrywolfSync.SetPlusChaosRate((this->m_CrywolfBenefitChaosRate=GetPrivateProfileInt(section,"CrywolfBenefitChaosRate",0,path)));

	gCrywolfSync.SetMonHPBenefitRate((this->m_CrywolfBenefitMonsterLife=GetPrivateProfileInt(section,"CrywolfBenefitMonsterLife",0,path)));

	gCrywolfSync.SetApplyPenalty((this->m_CrywolfPenaltySwitch=GetPrivateProfileInt(section,"CrywolfPenaltySwitch",0,path)));

	gCrywolfSync.SetGemDropPenaltiyRate((this->m_CrywolfPenaltyJewelDrop=GetPrivateProfileInt(section,"CrywolfPenaltyJewelDrop",0,path)));

	gCrywolfSync.SetGettingExpPenaltyRate((this->m_CrywolfPenaltyExperience=GetPrivateProfileInt(section,"CrywolfPenaltyExperience",0,path)));
	#endif

	this->m_DevilSquareEvent = GetPrivateProfileInt(section,"DevilSquareEvent",0,path);

	this->m_DevilSquareMaxUser = GetPrivateProfileInt(section,"DevilSquareMaxUser",0,path);

	#if(GAMESERVER_UPDATE>=501)

	this->m_DoubleGoerEvent = GetPrivateProfileInt(section,"DoubleGoerEvent",0,path);

	this->m_DoubleGoerDifficultRate = GetPrivateProfileInt(section,"DoubleGoerDifficultRate",0,path);

	#endif

	this->m_IllusionTempleEvent = GetPrivateProfileInt(section,"IllusionTempleEvent",0,path);

	this->m_IllusionTempleMinUser = GetPrivateProfileInt(section,"IllusionTempleMinUser",0,path);

	this->m_IllusionTempleRewardFenrirRate = GetPrivateProfileInt(section,"IllusionTempleRewardFenrirRate",0,path);

	#if(GAMESERVER_UPDATE>=501)

	this->m_ImperialGuardianEvent = GetPrivateProfileInt(section,"ImperialGuardianEvent",0,path);

	this->m_ImperialGuardianDifficultRate = GetPrivateProfileInt(section,"ImperialGuardianDifficultRate",0,path);

	#endif

	this->m_InvasionManagerSwitch = GetPrivateProfileInt(section,"InvasionManagerSwitch",0,path);

	this->m_KanturuEvent = GetPrivateProfileInt(section,"KanturuEvent",0,path);

	#if(GAMESERVER_UPDATE>=402)

	this->m_MossMerchantEvent = GetPrivateProfileInt(section,"MossMerchantEvent",0,path);

	this->m_MossMerchantEventTime = GetPrivateProfileInt(section,"MossMerchantEventTime",0,path);

	#endif

	#if(GAMESERVER_UPDATE>=401)

	this->m_RaklionEvent = GetPrivateProfileInt(section,"RaklionEvent",0,path);

	#endif
}

void CServerInfo::ReadHackInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	this->m_CheckSpeedHack = GetPrivateProfileInt(section,"CheckSpeedHack",0,path);

	this->m_CheckSpeedHackTolerance = GetPrivateProfileInt(section,"CheckSpeedHackTolerance",0,path);

	this->m_CheckLatencyHack = GetPrivateProfileInt(section,"CheckLatencyHack",0,path);

	this->m_CheckLatencyHackTolerance = GetPrivateProfileInt(section,"CheckLatencyHackTolerance",0,path);

	this->m_CheckAutoPotionHack = GetPrivateProfileInt(section,"CheckAutoPotionHack",0,path);

	this->m_CheckAutoPotionHackTolerance = GetPrivateProfileInt(section,"CheckAutoPotionHackTolerance",0,path);

	this->m_CheckAutoComboHack = GetPrivateProfileInt(section,"CheckAutoComboHack",0,path);

	this->m_CheckAutoComboHackTolerance = GetPrivateProfileInt(section,"CheckAutoComboHackTolerance",0,path);

	this->m_MaxPacketPerSecond = GetPrivateProfileInt(section, "CheckPacketHackLimit", 180, path);

	this->m_AntiFloodMaxTimeCheck = GetPrivateProfileInt(section, "AntiFloodMaxTimeCheck", 5, path);

	this->m_AntiFloodMinTimeCheck = GetPrivateProfileInt(section, "AntiFloodMinTimeCheck", 5, path);

	this->m_AntiFloodMaxCount = GetPrivateProfileInt(section, "AntiFloodMaxCount", 10, path);

	this->m_AntiFloodBlockTime = GetPrivateProfileInt(section, "AntiFloodBlockTime", 60, path);

	this->m_SkillHackCheckSwitch = GetPrivateProfileInt(section, "SkillHackCheckSwitch", 0, path);

	this->m_SkillHackCheckType = GetPrivateProfileInt(section, "SkillHackCheckType", 0, path);

	this->m_SkillHackCheckDebug = GetPrivateProfileInt(section, "SkillHackCheckDebug", 0, path);

	this->m_SkillHackSpeedCheckSwitch = GetPrivateProfileInt(section, "SkillHackSpeedCheckSwitch", 0, path);

	this->m_SkillHackSpeedCheckDebug = GetPrivateProfileInt(section, "SkillHackSpeedCheckDebug", 0, path);
}

void CServerInfo::ReadSkillInfo(char* section,char* path) // OK
{
	char GameServerInfo[100] = {0};

	this->m_BlockTwisterSlash = GetPrivateProfileInt(section, "BlockTwisterSlash", 0, path);

	this->m_TwisterSlashConstA = GetPrivateProfileInt(section, "TwisterSlashConstA", 150, path);

	this->m_TwoWeaponsDamageMinConstA = GetPrivateProfileInt(section, "TwoWeaponsDamageMinConstA", 100, path);

	this->m_TwoWeaponsDamageMaxConstA = GetPrivateProfileInt(section, "TwoWeaponsDamageMaxConstA", 100, path);

	this->m_DisablePushSkills = GetPrivateProfileInt(section, "DisablePushSkills", 0, path);

	this->m_ManaShieldConstA = GetPrivateProfileInt(section,"ManaShieldConstA",0,path);

	this->m_ManaShieldConstB = GetPrivateProfileInt(section,"ManaShieldConstB",0,path);

	this->m_ManaShieldConstC = GetPrivateProfileInt(section,"ManaShieldConstC",0,path);

	this->m_ManaShieldRate[0] = GetPrivateProfileInt(section,"ManaShieldRateDW",0,path);

	this->m_ManaShieldRate[1] = GetPrivateProfileInt(section,"ManaShieldRateDK",0,path);

	this->m_ManaShieldRate[2] = GetPrivateProfileInt(section,"ManaShieldRateFE",0,path);

	this->m_ManaShieldRate[3] = GetPrivateProfileInt(section,"ManaShieldRateMG",0,path);

	this->m_ManaShieldRate[4] = GetPrivateProfileInt(section,"ManaShieldRateDL",0,path);

	this->m_ManaShieldRate[5] = GetPrivateProfileInt(section,"ManaShieldRateSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_ManaShieldRate[6] = GetPrivateProfileInt(section,"ManaShieldRateRF",0,path);

	#endif

	this->m_ManaShieldTimeConstA = GetPrivateProfileInt(section,"ManaShieldTimeConstA",0,path);

	this->m_ManaShieldTimeConstB = GetPrivateProfileInt(section,"ManaShieldTimeConstB",0,path);

	this->m_ManaShieldMaxRate = GetPrivateProfileInt(section,"ManaShieldMaxRate",0,path);

	this->m_DefenseConstA = GetPrivateProfileInt(section,"DefenseConstA",0,path);

	this->m_DefenseTimeConstA = GetPrivateProfileInt(section,"DefenseTimeConstA",0,path);

	this->m_HealConstA = GetPrivateProfileInt(section,"HealConstA",0,path);

	this->m_HealConstB = GetPrivateProfileInt(section,"HealConstB",0,path);

	this->m_GreaterDefenseConstA = GetPrivateProfileInt(section,"GreaterDefenseConstA",0,path);

	this->m_GreaterDefenseConstB = GetPrivateProfileInt(section,"GreaterDefenseConstB",0,path);

	this->m_GreaterDefenseRate[0] = GetPrivateProfileInt(section,"GreaterDefenseRateDW",0,path);

	this->m_GreaterDefenseRate[1] = GetPrivateProfileInt(section,"GreaterDefenseRateDK",0,path);

	this->m_GreaterDefenseRate[2] = GetPrivateProfileInt(section,"GreaterDefenseRateFE",0,path);

	this->m_GreaterDefenseRate[3] = GetPrivateProfileInt(section,"GreaterDefenseRateMG",0,path);

	this->m_GreaterDefenseRate[4] = GetPrivateProfileInt(section,"GreaterDefenseRateDL",0,path);

	this->m_GreaterDefenseRate[5] = GetPrivateProfileInt(section,"GreaterDefenseRateSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_GreaterDefenseRate[6] = GetPrivateProfileInt(section,"GreaterDefenseRateRF",0,path);

	#endif

	this->m_GreaterDefenseTimeConstA = GetPrivateProfileInt(section,"GreaterDefenseTimeConstA",0,path);

	this->m_GreaterDamageConstA = GetPrivateProfileInt(section,"GreaterDamageConstA",0,path);

	this->m_GreaterDamageConstB = GetPrivateProfileInt(section,"GreaterDamageConstB",0,path);

	this->m_GreaterDamageRate[0] = GetPrivateProfileInt(section,"GreaterDamageRateDW",0,path);

	this->m_GreaterDamageRate[1] = GetPrivateProfileInt(section,"GreaterDamageRateDK",0,path);

	this->m_GreaterDamageRate[2] = GetPrivateProfileInt(section,"GreaterDamageRateFE",0,path);

	this->m_GreaterDamageRate[3] = GetPrivateProfileInt(section,"GreaterDamageRateMG",0,path);

	this->m_GreaterDamageRate[4] = GetPrivateProfileInt(section,"GreaterDamageRateDL",0,path);

	this->m_GreaterDamageRate[5] = GetPrivateProfileInt(section,"GreaterDamageRateSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_GreaterDamageRate[6] = GetPrivateProfileInt(section,"GreaterDamageRateRF",0,path);

	#endif

	this->m_GreaterDamageTimeConstA = GetPrivateProfileInt(section,"GreaterDamageTimeConstA",0,path);

	this->m_SummonMonster1 = GetPrivateProfileInt(section,"SummonMonster1",0,path);

	this->m_SummonMonster2 = GetPrivateProfileInt(section,"SummonMonster2",0,path);

	this->m_SummonMonster3 = GetPrivateProfileInt(section,"SummonMonster3",0,path);

	this->m_SummonMonster4 = GetPrivateProfileInt(section,"SummonMonster4",0,path);

	this->m_SummonMonster5 = GetPrivateProfileInt(section,"SummonMonster5",0,path);

	this->m_SummonMonster6 = GetPrivateProfileInt(section,"SummonMonster6",0,path);

	this->m_SummonMonster7 = GetPrivateProfileInt(section,"SummonMonster7",0,path);

	#if(GAMESERVER_UPDATE>=701)

	this->m_SummonMonster8 = GetPrivateProfileInt(section,"SummonMonster8",0,path);

	#endif

	this->m_GreaterLifeConstA = GetPrivateProfileInt(section,"GreaterLifeConstA",0,path);

	this->m_GreaterLifeConstB = GetPrivateProfileInt(section,"GreaterLifeConstB",0,path);

	this->m_GreaterLifeConstC = GetPrivateProfileInt(section,"GreaterLifeConstC",0,path);

	this->m_GreaterLifeRate[0] = GetPrivateProfileInt(section,"GreaterLifeRateDW",0,path);

	this->m_GreaterLifeRate[1] = GetPrivateProfileInt(section,"GreaterLifeRateDK",0,path);

	this->m_GreaterLifeRate[2] = GetPrivateProfileInt(section,"GreaterLifeRateFE",0,path);

	this->m_GreaterLifeRate[3] = GetPrivateProfileInt(section,"GreaterLifeRateMG",0,path);

	this->m_GreaterLifeRate[4] = GetPrivateProfileInt(section,"GreaterLifeRateDL",0,path);

	this->m_GreaterLifeRate[5] = GetPrivateProfileInt(section,"GreaterLifeRateSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_GreaterLifeRate[6] = GetPrivateProfileInt(section,"GreaterLifeRateRF",0,path);

	#endif

	this->m_GreaterLifeTimeConstA = GetPrivateProfileInt(section,"GreaterLifeTimeConstA",0,path);

	this->m_GreaterLifeTimeConstB = GetPrivateProfileInt(section,"GreaterLifeTimeConstB",0,path);

	this->m_GreaterLifeMaxRate = GetPrivateProfileInt(section,"GreaterLifeMaxRate",0,path);

	this->m_FireSlashConstA = GetPrivateProfileInt(section,"FireSlashConstA",0,path);

	this->m_FireSlashConstB = GetPrivateProfileInt(section,"FireSlashConstB",0,path);

	this->m_FireSlashTimeConstA = GetPrivateProfileInt(section,"FireSlashTimeConstA",0,path);

	this->m_FireSlashMaxRate = GetPrivateProfileInt(section,"FireSlashMaxRate",0,path);

	this->m_GreaterCriticalDamageConstA = GetPrivateProfileInt(section,"GreaterCriticalDamageConstA",0,path);

	this->m_GreaterCriticalDamageConstB = GetPrivateProfileInt(section,"GreaterCriticalDamageConstB",0,path);

	this->m_GreaterCriticalDamageTimeConstA = GetPrivateProfileInt(section,"GreaterCriticalDamageTimeConstA",0,path);

	this->m_GreaterCriticalDamageTimeConstB = GetPrivateProfileInt(section,"GreaterCriticalDamageTimeConstB",0,path);

	this->m_GreaterCriticalDamageRate[0] = GetPrivateProfileInt(section, "GreaterCriticalDamageRateDW", 100, path);

	this->m_GreaterCriticalDamageRate[1] = GetPrivateProfileInt(section, "GreaterCriticalDamageRateDK", 100, path);

	this->m_GreaterCriticalDamageRate[2] = GetPrivateProfileInt(section, "GreaterCriticalDamageRateFE", 100, path);

	this->m_GreaterCriticalDamageRate[3] = GetPrivateProfileInt(section, "GreaterCriticalDamageRateMG", 100, path);

	this->m_GreaterCriticalDamageRate[4] = GetPrivateProfileInt(section, "GreaterCriticalDamageRateDL", 100, path);

	this->m_GreaterCriticalDamageRate[5] = GetPrivateProfileInt(section, "GreaterCriticalDamageRateSU", 100, path);

#if(GAMESERVER_UPDATE>=601)

	this->m_GreaterCriticalDamageRate[6] = GetPrivateProfileInt(section, "GreaterCriticalDamageRateRF", 0, path);

#endif

	this->m_SternTimeConstA = GetPrivateProfileInt(section,"SternTimeConstA",0,path);

	this->m_GreaterManaConstA = GetPrivateProfileInt(section,"GreaterManaConstA",0,path);

	this->m_GreaterManaTimeConstA = GetPrivateProfileInt(section,"GreaterManaTimeConstA",0,path);

	this->m_InvisibilityTimeConstA = GetPrivateProfileInt(section,"InvisibilityTimeConstA",0,path);

	this->m_BrandTimeConstA = GetPrivateProfileInt(section,"BrandTimeConstA",0,path);

	this->m_InfinityArrowTimeConstA = GetPrivateProfileInt(section,"InfinityArrowTimeConstA",0,path);

	this->m_MagicDamageImmunityTimeConstA = GetPrivateProfileInt(section,"MagicDamageImmunityTimeConstA",0,path);

	this->m_PhysiDamageImmunityTimeConstA = GetPrivateProfileInt(section,"PhysiDamageImmunityTimeConstA",0,path);

	this->m_DrainLifeConstA = GetPrivateProfileInt(section,"DrainLifeConstA",0,path);

	this->m_DrainLifeConstB = GetPrivateProfileInt(section,"DrainLifeConstB",0,path);

	this->m_ReflectDamageConstA = GetPrivateProfileInt(section,"ReflectDamageConstA",0,path);

	this->m_ReflectDamageConstB = GetPrivateProfileInt(section,"ReflectDamageConstB",0,path);

	this->m_ReflectDamageRate[0] = GetPrivateProfileInt(section,"ReflectDamageRateDW",0,path);

	this->m_ReflectDamageRate[1] = GetPrivateProfileInt(section,"ReflectDamageRateDK",0,path);

	this->m_ReflectDamageRate[2] = GetPrivateProfileInt(section,"ReflectDamageRateFE",0,path);

	this->m_ReflectDamageRate[3] = GetPrivateProfileInt(section,"ReflectDamageRateMG",0,path);

	this->m_ReflectDamageRate[4] = GetPrivateProfileInt(section,"ReflectDamageRateDL",0,path);

	this->m_ReflectDamageRate[5] = GetPrivateProfileInt(section,"ReflectDamageRateSU",0,path);

	#if(GAMESERVER_UPDATE>=601)

	this->m_ReflectDamageRate[6] = GetPrivateProfileInt(section,"ReflectDamageRateRF",0,path);

	#endif

	this->m_ReflectDamageTimeConstA = GetPrivateProfileInt(section,"ReflectDamageTimeConstA",0,path);

	this->m_ReflectDamageTimeConstB = GetPrivateProfileInt(section,"ReflectDamageTimeConstB",0,path);

	this->m_ReflectDamageMaxRate = GetPrivateProfileInt(section,"ReflectDamageMaxRate",0,path);

	this->m_SwordPowerConstA = GetPrivateProfileInt(section,"SwordPowerConstA",0,path);

	this->m_SwordPowerConstB = GetPrivateProfileInt(section,"SwordPowerConstB",0,path);

	this->m_SwordPowerTimeConstA = GetPrivateProfileInt(section,"SwordPowerTimeConstA",0,path);

	this->m_SwordPowerTimeConstB = GetPrivateProfileInt(section,"SwordPowerTimeConstB",0,path);

	this->m_SwordPowerMaxRate = GetPrivateProfileInt(section,"SwordPowerMaxRate",0,path);

	this->m_SleepConstA = GetPrivateProfileInt(section,"SleepConstA",0,path);

	this->m_SleepConstB = GetPrivateProfileInt(section,"SleepConstB",0,path);

	this->m_SleepTimeConstA = GetPrivateProfileInt(section,"SleepTimeConstA",0,path);

	this->m_SleepTimeConstB = GetPrivateProfileInt(section,"SleepTimeConstB",0,path);

	this->m_SleepMaxTime = GetPrivateProfileInt(section,"SleepMaxTime",0,path);

	this->m_LesserDefenseConstA = GetPrivateProfileInt(section,"LesserDefenseConstA",0,path);

	this->m_LesserDefenseConstB = GetPrivateProfileInt(section,"LesserDefenseConstB",0,path);

	this->m_LesserDefenseConstC = GetPrivateProfileInt(section,"LesserDefenseConstC",0,path);

	this->m_LesserDefenseConstD = GetPrivateProfileInt(section,"LesserDefenseConstD",0,path);

	this->m_LesserDefenseTimeConstA = GetPrivateProfileInt(section,"LesserDefenseTimeConstA",0,path);

	this->m_LesserDefenseTimeConstB = GetPrivateProfileInt(section,"LesserDefenseTimeConstB",0,path);

	this->m_LesserDefenseMaxRate = GetPrivateProfileInt(section,"LesserDefenseMaxRate",0,path);

	this->m_LesserDamageConstA = GetPrivateProfileInt(section,"LesserDamageConstA",0,path);

	this->m_LesserDamageConstB = GetPrivateProfileInt(section,"LesserDamageConstB",0,path);

	this->m_LesserDamageConstC = GetPrivateProfileInt(section,"LesserDamageConstC",0,path);

	this->m_LesserDamageConstD = GetPrivateProfileInt(section,"LesserDamageConstD",0,path);

	this->m_LesserDamageTimeConstA = GetPrivateProfileInt(section,"LesserDamageTimeConstA",0,path);

	this->m_LesserDamageTimeConstB = GetPrivateProfileInt(section,"LesserDamageTimeConstB",0,path);

	this->m_LesserDamageMaxRate = GetPrivateProfileInt(section,"LesserDamageMaxRate",0,path);

	this->m_SahamuttConstA = GetPrivateProfileInt(section,"SahamuttConstA",0,path);

	this->m_NeilConstA = GetPrivateProfileInt(section,"NeilConstA",0,path);

	this->m_MagicCircleConstA = GetPrivateProfileInt(section,"MagicCircleConstA",0,path);

	this->m_MagicCircleTimeConstA = GetPrivateProfileInt(section,"MagicCircleTimeConstA",0,path);

	this->m_ShieldRecoverConstA = GetPrivateProfileInt(section,"ShieldRecoverConstA",0,path);

	this->m_ShieldRecoverConstB = GetPrivateProfileInt(section,"ShieldRecoverConstB",0,path);

	this->m_DragonSlayerConstA = GetPrivateProfileInt(section,"DragonSlayerConstA",0,path);

	this->m_DragonSlayerConstB = GetPrivateProfileInt(section,"DragonSlayerConstB",0,path);

	this->m_DragonSlayerConstC = GetPrivateProfileInt(section,"DragonSlayerConstC",0,path);

	this->m_DragonSlayerConstD = GetPrivateProfileInt(section,"DragonSlayerConstD",0,path);

	this->m_DragonSlayerMaxRate = GetPrivateProfileInt(section,"DragonSlayerMaxRate",0,path);

	this->m_GreaterIgnoreDefenseRateConstA = GetPrivateProfileInt(section,"GreaterIgnoreDefenseRateConstA",0,path);

	this->m_GreaterIgnoreDefenseRateConstB = GetPrivateProfileInt(section,"GreaterIgnoreDefenseRateConstB",0,path);

	this->m_GreaterIgnoreDefenseRateTimeConstA = GetPrivateProfileInt(section,"GreaterIgnoreDefenseRateTimeConstA",0,path);

	this->m_GreaterIgnoreDefenseRateTimeConstB = GetPrivateProfileInt(section,"GreaterIgnoreDefenseRateTimeConstB",0,path);

	this->m_FitnessConstA = GetPrivateProfileInt(section,"FitnessConstA",0,path);

	this->m_FitnessConstB = GetPrivateProfileInt(section,"FitnessConstB",0,path);

	this->m_FitnessTimeConstA = GetPrivateProfileInt(section,"FitnessTimeConstA",0,path);

	this->m_FitnessTimeConstB = GetPrivateProfileInt(section,"FitnessTimeConstB",0,path);

	this->m_GreaterDefenseSuccessRateConstA = GetPrivateProfileInt(section,"GreaterDefenseSuccessRateConstA",0,path);

	this->m_GreaterDefenseSuccessRateConstB = GetPrivateProfileInt(section,"GreaterDefenseSuccessRateConstB",0,path);

	this->m_GreaterDefenseSuccessRateTimeConstA = GetPrivateProfileInt(section,"GreaterDefenseSuccessRateTimeConstA",0,path);

	this->m_GreaterDefenseSuccessRateTimeConstB = GetPrivateProfileInt(section,"GreaterDefenseSuccessRateTimeConstB",0,path);

	#if(GAMESERVER_UPDATE>=701)

	this->m_PartyHealConstA = GetPrivateProfileInt(section,"PartyHealConstA",0,path);

	this->m_PartyHealConstB = GetPrivateProfileInt(section,"PartyHealConstB",0,path);

	this->m_BlessConstA = GetPrivateProfileInt(section,"BlessConstA",0,path);

	this->m_BlessTimeConstA = GetPrivateProfileInt(section,"BlessTimeConstA",0,path);

	this->m_BlindConstA = GetPrivateProfileInt(section,"BlindConstA",0,path);

	this->m_BlindConstB = GetPrivateProfileInt(section,"BlindConstB",0,path);

	this->m_BlindConstC = GetPrivateProfileInt(section,"BlindConstC",0,path);

	this->m_BlindTimeConstA = GetPrivateProfileInt(section,"BlindTimeConstA",0,path);

	this->m_EarthPrisonConstA = GetPrivateProfileInt(section,"EarthPrisonConstA",0,path);

	this->m_IronDefenseConstA = GetPrivateProfileInt(section,"IronDefenseConstA",0,path);

	this->m_IronDefenseConstB = GetPrivateProfileInt(section,"IronDefenseConstB",0,path);

	this->m_IronDefenseTimeConstA = GetPrivateProfileInt(section,"IronDefenseTimeConstA",0,path);

	this->m_BloodHowlingConstA = GetPrivateProfileInt(section,"BloodHowlingConstA",0,path);

	this->m_BloodHowlingConstB = GetPrivateProfileInt(section,"BloodHowlingConstB",0,path);

	this->m_BloodHowlingTimeConstA = GetPrivateProfileInt(section,"BloodHowlingTimeConstA",0,path);

	#endif
}
