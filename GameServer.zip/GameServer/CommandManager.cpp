// CommandManager.cpp: implementation of the CCommandManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CommandManager.h"
#include "BonusManager.h"
#include "CustomAttack.h"
#include "CustomStore.h"
#include "DSProtocol.h"
#include "GameMain.h"
#include "Guild.h"
#include "ItemManager.h"
#include "Log.h"
#include "MapServerManager.h"
#include "MasterSkillTree.h"
#include "Message.h"
#include "Move.h"
#include "Notice.h"
#include "ObjectManager.h"
#include "Protocol.h"
#include "Quest.h"
#include "QuestReward.h"
#include "ServerInfo.h"
#include "Util.h"
#include "TradeX.h"
#include "LuaGameServer.h"

CCommandManager gCommandManager;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCommandManager::CCommandManager() // OK
{

}

CCommandManager::~CCommandManager() // OK
{

}

void CCommandManager::Init() // OK
{
	for(int n=0;n < MAX_COMMAND;n++)
	{
		this->m_CommandInfo[n].code = -1;
	}

	this->Add(gMessage.GetMessage("Eng", 32),COMMAND_MOVE);
	this->Add("/warp", COMMAND_MOVE);
	this->Add(gMessage.GetMessage("Eng", 55),COMMAND_GUILD_WAR);
	this->Add(gMessage.GetMessage("Eng", 56),COMMAND_BATTLE_SOCCER);
	this->Add(gMessage.GetMessage("Eng", 57),COMMAND_REQUEST);
	this->Add(gCustomStore.m_CustomStoreCommandSyntax,COMMAND_CUSTOM_STORE);
	this->Add(gCustomStore.m_CustomStoreOfflineCommandSyntax,COMMAND_CUSTOM_STORE_OFFLINE);
	this->Add(gMessage.GetMessage("Eng", 58),COMMAND_HIDE);
	this->Add(gCustomAttack.m_CustomAttackCommandSyntax,COMMAND_CUSTOM_ATTACK);
	this->Add(gCustomAttack.m_CustomAttackOfflineCommandSyntax,COMMAND_CUSTOM_ATTACK_OFFLINE);

	#if (GAMESERVER_UPDATE==201 || GAMESERVER_UPDATE == 603)
	this->Add("/tradex", COMMAND_TRADEX);
	#endif
}

void CCommandManager::MainProc()
{
	for (int n = OBJECT_START_USER; n < MAX_OBJECT; n++)
	{
		if (gObjIsConnectedGP(n) == 0)
		{
			continue;
		}

		if (gObj[n].AutoAddPointCount > 0)
		{
			this->CommandAddPointAutoProc(&gObj[n]);
		}

		if (gObj[n].AutoResetEnable != 0)
		{
			gLuaGameServer.AutoResetPlayerProc(n);
		}
	}
}

void CCommandManager::Add(char* label,int code) // OK
{
	for(int n=0;n < MAX_COMMAND;n++)
	{
		if(this->m_CommandInfo[n].code != -1)
		{
			continue;
		}

		this->m_CommandInfo[n].code = code;
		strcpy_s(this->m_CommandInfo[n].label,label);
		break;
	}
}

long CCommandManager::GetNumber(char* arg,int pos) // OK
{
	int count=0,p=0;

	char buffer[60] = {0};

	int len = strlen(arg);

	len = ((len>=sizeof(buffer))?(sizeof(buffer)-1):len);

	for(int n=0;n < len;n++)
	{
		if(arg[n] == 0x20)
		{
			count++;
		}
		else if(count == pos)
		{
			buffer[p] = arg[n];
			p++;
		}
	}

	return atoi(buffer);
}

void CCommandManager::GetString(char* arg,char* out,int size,int pos) // OK
{
	int count=0,p=0;

	char buffer[60] = {0};

	int len = strlen(arg);

	len = ((len>=sizeof(buffer))?(sizeof(buffer)-1):len);

	for(int n=0;n < len;n++)
	{
		if(arg[n] == 0x20)
		{
			count++;
		}
		else if(count == pos)
		{
			buffer[p] = arg[n];
			p++;
		}
	}

	memcpy(out,buffer,(size-1));
}

char* CCommandManager::GetFullString(char * arg)
{
	char buffer[60] = { 0 };

	int len = strlen(arg);

	len = ((len >= sizeof(buffer)) ? (sizeof(buffer) - 1) : len);

	for (int n = 0; n < len; n++)
	{
		if (arg[n] == 0x20)
		{
			memcpy(&buffer, &arg[n], strlen(&arg[n]));
			break;
		}
	}

	return buffer;
}

long CCommandManager::GetCommandCode(char* label) // OK
{
	for(int n=0;n < MAX_COMMAND;n++)
	{
		if(this->m_CommandInfo[n].code == -1)
		{
			continue;
		}

		if(_stricmp(label,this->m_CommandInfo[n].label) == 0)
		{
			return this->m_CommandInfo[n].code;
		}
	}

	return 0;
}

bool CCommandManager::ManagementCore(LPOBJ lpObj,char* message) // OK
{
#ifdef CUSTOM_GAMESERVER
	if (lpObj->TradeDuel != 0) {
		return true;
	}
#endif

	char command[32] = {0};

	memset(command,0,sizeof(command));

	this->GetString(message,command,sizeof(command),0);

	int code = this->GetCommandCode(command);

	char* argument = &message[strlen(command)];

	if(argument[0] == 0x20)
	{
		argument++;
	}

	switch(code)
	{
		case COMMAND_MOVE:
			this->CommandMove(lpObj,argument);
			break;
		case COMMAND_GUILD_WAR:
			this->CommandGuildWar(lpObj,argument);
			break;
		case COMMAND_BATTLE_SOCCER:
			this->CommandBattleSoccer(lpObj,argument);
			break;
		case COMMAND_REQUEST:
			this->CommandRequest(lpObj,argument);
			break;
		case COMMAND_CUSTOM_STORE:
			gCustomStore.CommandCustomStore(lpObj,argument);
			break;
		case COMMAND_CUSTOM_STORE_OFFLINE:
			gCustomStore.CommandCustomStoreOffline(lpObj,argument);
			break;
		case COMMAND_HIDE:
			this->CommandHide(lpObj,argument);
			break;
		case COMMAND_CUSTOM_ATTACK:
			gCustomAttack.CommandCustomAttack(lpObj,argument);
			break;
		case COMMAND_CUSTOM_ATTACK_OFFLINE:
			gCustomAttack.CommandCustomAttackOffline(lpObj,argument);
			break;
		case COMMAND_TRADEX:
			this->CommandTradeX(lpObj, argument);
			break;
		default:
			return 0;
	}

	return 1;
}

void CCommandManager::CommandMove(LPOBJ lpObj,char* arg) // OK
{
	if (lpObj->Authority > 1)
	{
		char name[11] = { 0 };

		this->GetString(arg, name, sizeof(name), 0);

		if (sizeof(name) > 0)
		{
			LPOBJ lpTarget = gObjFind(name);

			if (lpTarget != 0)
			{
				if (lpTarget->Connected == OBJECT_ONLINE)
				{
					gObjTeleport(lpTarget->Index, this->GetNumber(arg, 1), this->GetNumber(arg, 2), this->GetNumber(arg, 3));
					return;
				}
			}
		}
	}

	MOVE_INFO MoveInfo;

	if(gMove.GetInfoByName(arg,&MoveInfo) != 0)
	{
		gMove.Move(lpObj,MoveInfo.Index);
		return;
	}
}

void CCommandManager::CommandGuildWar(LPOBJ lpObj,char* arg) // OK
{
	char GuildName[9] = {0};

	this->GetString(arg,GuildName,sizeof(GuildName),0);

	if(strlen(GuildName) >= 1)
	{
		GCGuildWarRequestResult(GuildName,lpObj->Index,0);
	}
}

void CCommandManager::CommandBattleSoccer(LPOBJ lpObj,char* arg) // OK
{
	char GuildName[9] = {0};

	this->GetString(arg,GuildName,sizeof(GuildName),0);

	if(strlen(GuildName) >= 1)
	{
		GCGuildWarRequestResult(GuildName,lpObj->Index,1);
	}
}

void CCommandManager::CommandRequest(LPOBJ lpObj,char* arg) // OK
{
	char mode[5] = {0};

	this->GetString(arg,mode,sizeof(mode),0);

	if(strcmp(mode,"on") == 0)
	{
		lpObj->Option |= 1;
		lpObj->Option |= 2;
		lpObj->Option &= ~4;

		memset(lpObj->AutoPartyPassword,0,sizeof(lpObj->AutoPartyPassword));

		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0,gMessage.GetMessage(lpObj->m_Language, 126));
	}
	else if(strcmp(mode,"off") == 0)
	{
		lpObj->Option &= ~1;
		lpObj->Option &= ~2;
		lpObj->Option &= ~4;

		memset(lpObj->AutoPartyPassword,0,sizeof(lpObj->AutoPartyPassword));

		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0,gMessage.GetMessage(lpObj->m_Language, 127));
	}
	else if(strcmp(mode,"auto") == 0)
	{
		lpObj->Option |= 1;
		lpObj->Option |= 2;
		lpObj->Option |= 4;

		memset(lpObj->AutoPartyPassword,0,sizeof(lpObj->AutoPartyPassword));

		this->GetString(arg,lpObj->AutoPartyPassword,sizeof(lpObj->AutoPartyPassword),1);

		gNotice.GCNoticeSend(lpObj->Index,1,0,0,0,0,0,gMessage.GetMessage(lpObj->m_Language, 128));
	}
}

void CCommandManager::CommandHide(LPOBJ lpObj,char* arg) // OK
{
	if (lpObj->Authority < 2)
	{
		return;
	}

	if(gEffectManager.CheckEffect(lpObj,EFFECT_INVISIBILITY) == 0)
	{
		gEffectManager.AddEffect(lpObj,0,EFFECT_INVISIBILITY,0,0,0,0,0);

		gObjViewportListProtocolDestroy(lpObj);
	}
	else
	{
		gEffectManager.DelEffect(lpObj,EFFECT_INVISIBILITY);

		gObjViewportListProtocolCreate(lpObj);
	}
}

void CCommandManager::CommandTradeX(LPOBJ lpObj, char * arg)
{
	#if (GAMESERVER_UPDATE==201 || GAMESERVER_UPDATE == 603)
	if (gServerInfo.m_TradeXSwitch == 0) {
		return;
	}

	if (lpObj->UsingTradeX) {
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "Voc� est� ocupado no momento!");
		return;
	}

	char name[11] = { 0 };

	this->GetString(arg, name, sizeof(name), 0);

	LPOBJ lpTarget = gObjFind(name);

	if (lpTarget == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "O jogador alvo n�o est� online");
		return;
	}

	if (lpTarget->UsingTradeX != 0) {
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "Este jogador n�o pode negociar com voc� no momento!");
		return;
	}

	if (lpObj->Index == lpTarget->Index) {
		return;
	}

	gTradeX.TradeXRequestSend(lpObj, lpTarget);
	#endif
}

void CCommandManager::CommandAddPointAuto(LPOBJ lpObj, int amount, int type)
{
	if (amount > 0)
	{
		lpObj->AutoAddPointCount = 0;

		lpObj->AutoAddPointStats[type] = amount;

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[0] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[1] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[2] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[3] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[4] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);
	}
	else
	{
		lpObj->AutoAddPointCount = 0;

		lpObj->AutoAddPointStats[type] = 0;

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[0] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[1] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[2] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[3] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

		lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[4] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);
	}
}

void CCommandManager::CommandAddPointAutoProc(LPOBJ lpObj)
{
	if (lpObj->LevelUpPoint == 0 || lpObj->AutoAddPointCount == 0)
	{
		return;
	}

	int AddStatCount = lpObj->AutoAddPointCount;

	int* stat[5] = { &lpObj->Strength,&lpObj->Dexterity,&lpObj->Vitality,&lpObj->Energy,&lpObj->Leadership };

	for (int n = 0; n < 5; n++)
	{
		if (lpObj->AutoAddPointStats[n] > 0)
		{
			if (AddStatCount == 0)
			{
				break;
			}

			int AddStat = lpObj->LevelUpPoint / AddStatCount;

			AddStat = (((lpObj->LevelUpPoint % AddStatCount) > 0) ? (AddStat + 1) : AddStat);

			AddStat = ((AddStat > lpObj->AutoAddPointStats[n]) ? lpObj->AutoAddPointStats[n] : AddStat);

			AddStat = ((((*stat[n]) + AddStat) > gServerInfo.m_MaxStatPoint[lpObj->AccountLevel]) ? (gServerInfo.m_MaxStatPoint[lpObj->AccountLevel] - (*stat[n])) : AddStat);

			AddStatCount--;

			(*stat[n]) += AddStat;

			lpObj->LevelUpPoint -= AddStat;

			lpObj->AutoAddPointStats[n] -= (((*stat[n]) >= gServerInfo.m_MaxStatPoint[lpObj->AccountLevel]) ? lpObj->AutoAddPointStats[n] : AddStat);

			lpObj->AutoAddPointCount = 0;

			lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[0] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

			lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[1] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

			lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[2] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

			lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[3] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);

			lpObj->AutoAddPointCount = ((lpObj->AutoAddPointStats[4] > 0) ? (lpObj->AutoAddPointCount + 1) : lpObj->AutoAddPointCount);
		}
	}

	gObjectManager.CharacterCalcAttribute(lpObj->Index);

	#if (GAMESERVER_UPDATE>=403)
	GCNewCharacterInfoSend(lpObj);
	#else
	GCLevelUpSend(lpObj);
	#endif
}
