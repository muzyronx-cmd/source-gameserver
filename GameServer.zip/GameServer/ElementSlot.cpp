#include "stdafx.h"
#include "ElementSlot.h"
#include "ItemManager.h"
#include "GameMain.h"
#include "Util.h"

#if(GAMESERVER_UPDATE==201)
CElementSlot gElementSlot;

CElementSlot::CElementSlot()
{

}

CElementSlot::~CElementSlot()
{

}

void CElementSlot::ElementSlotSaveSend(LPOBJ lpObj)
{
	SDHP_ELEMENT_SLOT_SAVE_SEND pMsg;

	pMsg.header.set(0x05, 0x52, sizeof(pMsg));

	pMsg.index = lpObj->Index;

	memcpy(pMsg.account, lpObj->Account, sizeof(pMsg.account));

	memcpy(pMsg.name, lpObj->Name, sizeof(pMsg.name));

	for (int n = 0; n < ELEMENT_SLOT_SIZE; n++) {
		gItemManager.DBItemByteConvert(pMsg.ElementSlot[n], &lpObj->ElementSlot[n]);
	}

	gDataServerConnection.DataSend((BYTE*)&pMsg, sizeof(pMsg));
}

void CElementSlot::ElementSlotGetSend(LPOBJ lpObj)
{
	if (gObjIsAccountValid(lpObj->Index, lpObj->Account) == 0)
	{
		return;
	}

	SDHP_ELEMENT_SLOT_GET_SEND pMsg;

	pMsg.header.set(0x05, 0x50, sizeof(pMsg));

	pMsg.index = lpObj->Index;

	memcpy(pMsg.account, lpObj->Account, sizeof(pMsg.account));

	memcpy(pMsg.name, lpObj->Name, sizeof(pMsg.name));

	gDataServerConnection.DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CElementSlot::ElementSlotRecv(SDHP_ELEMENT_SLOT_SAVE_RECV * lpMsg)
{
	if (gObjIsAccountValid(lpMsg->index, lpMsg->account) == 0)
	{
		LogAdd(LOG_RED, "[ElementSlotRecv] Invalid Account [%d](%s)", lpMsg->index, lpMsg->account);
		CloseClient(lpMsg->index);
		return;
	}

	LPOBJ lpObj = &gObj[lpMsg->index];

	if (_stricmp(lpMsg->name, lpObj->Name) != 0) {
		LogAdd(LOG_RED, "[ElementSlotRecv] Invalid Name [%d](%s)", lpMsg->index, lpMsg->account);
		return;
	}

	for (int n = 0; n < ELEMENT_SLOT_SIZE; n++) {
		CItem item;

		lpObj->ElementSlot[n].Clear();

		if (gItemManager.ConvertItemByte(&item, lpMsg->ElementSlot[n]) != 0) {
			gItemManager.ElementSlotAddItem(lpObj->Index, item, n);
		}
	}

	BYTE send[2046];

	PMSG_ELEMENT_SLOT_SEND pMsg;

	pMsg.header.set(0xFB, 0x15, 0);

	int size = sizeof(pMsg);

	pMsg.count = 0;

	ELEMENT_SLOT_INFO info;

	for (int n = 0; n < ELEMENT_SLOT_SIZE; n++)
	{
		if (lpObj->ElementSlot[n].IsItem() == 0 || lpObj->ElementSlot[n].m_ItemExist == 0)
		{
			continue;
		}

		info.slot = n;

		gItemManager.ItemByteConvert(info.ItemInfo, lpObj->ElementSlot[n]);

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	pMsg.header.size[0] = SET_NUMBERHB(size);
	pMsg.header.size[1] = SET_NUMBERLB(size);

	memcpy(send, &pMsg, sizeof(pMsg));

	DataSend(lpObj->Index, send, size);
}

void CElementSlot::ElementSlotListSend(int aIndex)
{
	if (OBJECT_USER_RANGE(aIndex) == 0) {
		return;
	}

	if (gObjIsConnectedGP(aIndex) == 0) {
		return;
	}

	LPOBJ lpObj = &gObj[aIndex];

	BYTE send[2046];

	PMSG_ELEMENT_SLOT_SEND pMsg;

	pMsg.header.set(0xFB, 0x15, 0);

	int size = sizeof(pMsg);

	pMsg.count = 0;

	ELEMENT_SLOT_INFO info;

	for (int n = 0; n < ELEMENT_SLOT_SIZE; n++)
	{
		if (lpObj->ElementSlot[n].IsItem() == 0 || lpObj->ElementSlot[n].m_ItemExist == 0)
		{
			continue;
		}

		info.slot = n;

		gItemManager.ItemByteConvert(info.ItemInfo, lpObj->ElementSlot[n]);

		memcpy(&send[size], &info, sizeof(info));
		size += sizeof(info);

		pMsg.count++;
	}

	pMsg.header.size[0] = SET_NUMBERHB(size);
	pMsg.header.size[1] = SET_NUMBERLB(size);

	memcpy(send, &pMsg, sizeof(pMsg));

	DataSend(lpObj->Index, send, size);
}
#endif