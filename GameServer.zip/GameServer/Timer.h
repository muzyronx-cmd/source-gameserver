#pragma once

#include "ObjectManager.h"
#include "Viewport.h"
#include "User.h"
#include "MonsterAI.h"
#include "CriticalSection.h"
#include "LuaGameServer.h"

class CTimer {
public:
	CTimer() {

	};

	~CTimer() {
		this->closed = true;

		/*if (this->basicTimer.joinable()) {
			this->basicTimer.detach();
		}

		if (this->playerTimer.joinable()) {
			this->playerTimer.detach();
		}*/

		if (this->luaTimer.joinable()) {
			this->luaTimer.detach();
		}
	};

	void start() {
		//this->basicTimer = std::thread([this]() { this->runBasicTimer(); });
		//this->playerTimer = std::thread([this]() { this->runPlayerTimer(); });
		this->luaTimer = std::thread([this]() { this->runLuaTimer(); });

		this->closed = false;
	}

	/*void runBasicTimer() {
		while (!this->closed) {
				gObjectManager.ObjectMonsterAndMsgProc();
				gObjectManager.ObjectMoveProc();
				#if(GAMESERVER_UPDATE>=201)
				CMonsterAI::MonsterAIProc();
				CMonsterAI::MonsterMoveProc();
				#endif
				gObjEventRunProc();

			std::this_thread::sleep_for(std::chrono::milliseconds(100));
		}
	}*/

	/*void runPlayerTimer() {
		while (!this->closed) {
			gObjViewportProc();
			gObjFirstProc();
			gObjCloseProc();

			std::this_thread::sleep_for(std::chrono::milliseconds(1000));
		}
	}*/

	void runLuaTimer() {
		while (!this->closed) {
			gLuaGameServer.TimerSystem();

			std::this_thread::sleep_for(std::chrono::seconds(1));
		}
	}

private:
	//std::thread basicTimer;
	//std::thread playerTimer;
	std::thread luaTimer;

	bool closed = false;
};

extern CTimer gTimer;