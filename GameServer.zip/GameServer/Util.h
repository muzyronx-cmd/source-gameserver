#pragma once

#include "ServerDisplayer.h"
#include "User.h"

int SafeGetItem(int index);
flt GetRoundValue(float value);
BYTE GetNewOptionCount(BYTE NewOption);
BYTE GetSocketOptionCount(BYTE SocketOption[5]);
BYTE GetPathPacketDirPos(int px,int py);
void PacketArgumentDecrypt(char* out_buff,char* in_buff,int size);
void ErrorMessageBox(char* message,...);
void LogAdd(eLogColor color,char* text,...);
void LogAddLua(eLogColor color, char * text, ...);
bool DataSend(int aIndex,BYTE* lpMsg,DWORD size);
void DataSendAll(BYTE* lpMsg,int size);
bool DataSendSocket(SOCKET socket,BYTE* lpMsg,DWORD size);
void MsgSendV2(LPOBJ lpObj,BYTE* lpMsg,int size);
void CloseClient(int aIndex);
void PostMessage1(char* name,char* message,char* text);
void PostMessage2(char* name,char* message,char* text);
void PostMessage3(char* name,char* message,char* text);
void PostMessage4(char* name,char* message,char* text);
void PostMessage5(char* name,char* message,char* text);
void SetLargeRand();
long GetLargeRand();
void GCServerMsgStringSendAll(char *szMsg, BYTE type);
void ChatYellowMessage(int aIndex, char * String);
void ChatYellowMessageAll(char * String);
void ChatGreenMessage(int aIndex, char * String);
void ChatGreenMessageAll(char * String);
void ChatBlueMessage(int aIndex, char * String);
void ChatBlueMessageAll(char * String);
void ChatGoldMessage(int aIndex, char * String);
void ChatGoldMessageAll(char * String);

void DecryptInternalData(BYTE * lpMsg, int start, int size);
void EncryptInternalData(BYTE * lpMsg, int start, int size);

static BYTE EncDecKeyInternal1[5] = { 0x54, 0xE2, 0x32, 0xB1, 0xC8 };
static BYTE EncDecKeyInternal2[5] = { 0x88, 0xA2, 0x77, 0x15, 0xF1 };

extern short RoadPathTable[MAX_ROAD_PATH_TABLE];
