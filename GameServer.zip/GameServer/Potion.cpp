#include "stdafx.h"
#include "Potion.h"
#include "Notice.h"
#include "ItemManager.h"
#include "CommandManager.h"
#include "Log.h"
#include "Util.h"
#include "ServerDisplayer.h"
#include "ServerInfo.h"
#include "Message.h"

cPotion Potion;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

cPotion::cPotion() // OK
{

}

cPotion::~cPotion() // OK
{

}

void cPotion::CGPotionTypeRecv(int aIndex, PMSG_POTION_RECV *lpMsg)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (gServerInfo.m_CustomAutoPotionSwitch[lpObj->AccountLevel] == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 1007));
		return;
	}

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return;
	}

	if (lpMsg->HP > -1)
	{
		lpObj->startsystem = lpMsg->HP;
	}
	if (lpMsg->MP > -1)
	{
		lpObj->startsystemmp = lpMsg->MP;
	}
	if (lpMsg->AG > -1)
	{
		lpObj->startsystemag = lpMsg->AG;
	}
	if (lpMsg->SD > -1)
	{
		lpObj->startsystemsd = lpMsg->SD;
	}
}

int cPotion::Inventory(LPOBJ lpObj, int aIndex)
{
	int MaxValue = gItemManager.GetInventoryMaxValue(lpObj);

	for (int i = INVENTORY_WEAR_SIZE; i < MaxValue; i++)
	{
		if (lpObj->Inventory[i].m_Index == aIndex)
		{
			return i;
		}
	}

	return FALSE;
}

void cPotion::Thread1(void* lpParam)
{
	while (true)
	{
		Sleep((DWORD)gServerInfo.m_CustomAutoPotionDelay);

		for (int i = OBJECT_START_USER; i < MAX_OBJECT; ++i)
		{
			if (gObj[i].Connected == 3 && gObj[i].Time > 0)
			{
				--gObj[i].Time;
			}
		}
	}

	_endthread();
}

void cPotion::Thread2(void* lpParam)
{
	while (true)
	{
		for (int i = OBJECT_START_USER; i < MAX_OBJECT; ++i)
		{
			//HP
			if (gObj[i].startsystem != -1)
			{
				if (gObj[i].Connected == 3 && gObj[i].startsystem == 1)
				{
					PMSG_ITEM_USE_RECV pMsg;
					pMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 0));
					pMsg.TargetSlot = 0;

					if (pMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&pMsg, i);
					}

					PMSG_ITEM_USE_RECV psMsg;
					psMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 1));
					psMsg.TargetSlot = 0;

					if (psMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&psMsg, i);
					}

					PMSG_ITEM_USE_RECV prMsg;
					prMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 2));
					prMsg.TargetSlot = 0;

					if (prMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&prMsg, i);
					}

					PMSG_ITEM_USE_RECV pqMsg;
					pqMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 3));
					pqMsg.TargetSlot = 0;

					if (pqMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&pqMsg, i);
					}
				}
			}
			//MP
			if (gObj[i].startsystemmp != -1)
			{
				if (gObj[i].Connected == 3 && gObj[i].startsystemmp == 1)
				{
					PMSG_ITEM_USE_RECV spMsg;
					spMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 4));
					spMsg.TargetSlot = 0;

					if (spMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&spMsg, i);
					}

					PMSG_ITEM_USE_RECV rpMsg;
					rpMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 5));
					rpMsg.TargetSlot = 0;

					if (rpMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&rpMsg, i);
					}

					PMSG_ITEM_USE_RECV rrsMsg;
					rrsMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 6));
					rrsMsg.TargetSlot = 0;

					if (rrsMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&rrsMsg, i);
					}
				}
			}
			//AG
			if (gObj[i].startsystemag != -1)
			{
				if (gObj[i].Connected == 3 && gObj[i].startsystemag == 1)
				{
					PMSG_ITEM_USE_RECV cMsg;
					cMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 38));
					cMsg.TargetSlot = 0;

					if (cMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&cMsg, i);
					}

					PMSG_ITEM_USE_RECV dMsg;
					dMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 39));
					dMsg.TargetSlot = 0;

					if (dMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&dMsg, i);
					}

					PMSG_ITEM_USE_RECV eMsg;
					eMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 40));
					eMsg.TargetSlot = 0;

					if (eMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&eMsg, i);
					}
				}
			}
			//SD
			if (gObj[i].startsystemsd != -1)
			{
				if (gObj[i].Connected == 3 && gObj[i].startsystemsd == 1)
				{
					PMSG_ITEM_USE_RECV fMsg;
					fMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 35));
					fMsg.TargetSlot = 0;

					if (fMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&fMsg, i);
					}

					PMSG_ITEM_USE_RECV gMsg;
					gMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 36));
					gMsg.TargetSlot = 0;

					if (gMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&gMsg, i);
					}

					PMSG_ITEM_USE_RECV hMsg;
					hMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 37));
					hMsg.TargetSlot = 0;

					if (hMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&hMsg, i);
					}

					PMSG_ITEM_USE_RECV kMsg;
					kMsg.SourceSlot = Potion.Inventory(&gObj[i], GET_ITEM(14, 133));
					kMsg.TargetSlot = 0;

					if (kMsg.SourceSlot != 0x0)
					{
						gItemManager.CGItemUseRecv(&kMsg, i);
					}
				}
			}
		}

		Sleep((DWORD)gServerInfo.m_CustomAutoPotionDelay);
	}

	_endthread();
}

bool cPotion::CommandAutoPotion(LPOBJ lpObj, char* arg) // OK
{
	char mode[5] = { 0 };

	gCommandManager.GetString(arg, mode, sizeof(mode), 0);

	if (!strcmpi(mode, "on"))
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "Auto potion ativado com sucesso.");

		lpObj->startsystem = true;
	}
	else if (!strcmpi(mode, "off"))
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "Auto potion desativado com sucesso.");

		lpObj->startsystem = false;
	}

	gLog.Output(LOG_GENERAL, "[Command Potion] Use for:[%s][%s]", lpObj->Account, lpObj->Name);

	return 1;
}

