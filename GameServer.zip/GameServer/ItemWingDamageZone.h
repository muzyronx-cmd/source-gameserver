#pragma once

#include "User.h"

struct ITEM_WING_ZONE_INFO
{
	int Index;
	int Damage;
	int DamageDec;
	int Level;
	int map;
	int x1;
	int y1;
	int x2;
	int y2;
};

class CItemWingDamageZone
{
public:
	CItemWingDamageZone();
	virtual ~CItemWingDamageZone();

	void Load(char * path);
	void SetDamage(LPOBJ lpObj, LPOBJ lpTarget, int * damage);

private:
	std::map<int, ITEM_WING_ZONE_INFO> m_WingZoneInfo;
};

extern CItemWingDamageZone gItemWingDamageZone;