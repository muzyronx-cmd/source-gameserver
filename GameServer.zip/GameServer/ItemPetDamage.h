#pragma once

#include "User.h"

struct ITEM_PET_INFOS
{
	int Index;
	int Target;
	int Damage;
	int Level;
};


class CItemPetDamage
{
public:
	CItemPetDamage();
	virtual ~CItemPetDamage();

	void Load(char * path);
	void SetDamage(LPOBJ lpObj, LPOBJ lpTarget, int * damage);

private:
	std::map<int, ITEM_PET_INFOS> m_CItemPetDamage;

}; extern CItemPetDamage gItemPetDamage;