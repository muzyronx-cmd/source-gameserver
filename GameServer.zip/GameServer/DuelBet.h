// Duel.h: interface for the CDuelBet class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#ifdef CUSTOM_GAMESERVER

#include "Protocol.h"

//**********************************************//
//************ Client -> GameServer ************//
//**********************************************//

struct PMSG_DUEL_START_RECV
{
	PBMSG_HEAD header; // C1:AA
	BYTE index[2];
	char name[10];
};

struct PMSG_DUEL_OK_RECV
{
	PBMSG_HEAD header; // C1:AC
	BYTE flag;
	BYTE index[2];
	char name[10];
};

//**********************************************//
//************ GameServer -> Client ************//
//**********************************************//

struct PMSG_DUEL_START_SEND
{
	PBMSG_HEAD header; // C1:AA
	BYTE result;
	BYTE index[2];
	char name[10];
};

struct PMSG_DUEL_OK_SEND
{
	PBMSG_HEAD header; // C1:AC
	BYTE index[2];
	char name[10];
};

struct PMSG_DUEL_END_SEND
{
	PBMSG_HEAD header; // C1:AB
	BYTE index[2];
	char name[10];
};

struct PMSG_DUEL_SCORE_SEND
{
	PBMSG_HEAD header; // C1:AD
	BYTE index1[2];
	BYTE index2[2];
	BYTE score[2];
};

//**********************************************//
//**********************************************//
//**********************************************//

class CDuelBet
{
public:
	CDuelBet();
	virtual ~CDuelBet();
	bool CheckDuel(LPOBJ lpObj, LPOBJ lpTarget);
	bool CheckDuelUser(int aIndex);
	void CheckDuelScore(LPOBJ lpObj, LPOBJ lpTarget);
	void CheckDuelUser();
	void ResetDuel(LPOBJ lpObj);
	void RespawnDuelUser(LPOBJ lpObj);
	void UserDieProc(LPOBJ lpObj, LPOBJ lpTarget);
	void CGDuelStartRecv(PMSG_DUEL_START_RECV* lpMsg, int aIndex);
	void CGDuelOkRecv(PMSG_DUEL_OK_RECV* lpMsg, int aIndex);
	void CGDuelEndRecv(int aIndex);
	void CGDuelEnd(int aIndex);
	bool GCDuelBetTradeOkButton(int aIndex);
	void GCDuelBetTradeCancel(LPOBJ lpObj);
	bool CheckDuelUserSpace(LPOBJ lpObj);
	void DuelFinish(LPOBJ lpObj, bool finished);
	void DuelSendItemWinner(int aIndex);
	void GCDuelBetStartSend(int aIndex, BYTE flag, int bIndex);
	void GCDuelBetOkSend(int aIndex, int bIndex);
	void GCDuelBetEndSend(int aIndex, BYTE result);
	void GCDuelBetScoreSend(int aIndex, int bIndex);
	void GCSendDuelTrade(int aIndex, int bIndex);
};

extern CDuelBet gDuel;
#endif