// Message.h: interface for the CMessage class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

struct MESSAGE_INFO
{
	int Index;
	char Message[128];
};

class CMessage
{
public:
	CMessage();
	virtual ~CMessage();
	void LoadMsgEng(char* path);
	void LoadMsgPor(char* path);
	void LoadMsgSpn(char* path);
	char* GetInfoEng(int index);
	char* GetInfoPor(int index);
	char* GetInfoSpn(int index);
	char* GetMessage(char* lang, int index);
	char* GetMessageGlobal(char* lang, int index);
private:
	char m_DefaultMessage[128];

	std::map<int, MESSAGE_INFO> m_MessageInfoEng;
	std::map<int, MESSAGE_INFO> m_MessageInfoPor;
	std::map<int, MESSAGE_INFO> m_MessageInfoSpn;
};

extern CMessage gMessage;
