#include "stdafx.h"
#include "MuHelperOffline.h"
#include "DefaultClassInfo.h"
#include "Map.h"
#include "Util.h"
#include "SkillManager.h"
#include "EffectManager.h"
#include "Party.h"
#include "Attack.h"
#include "CustomAttack.h"
#include "ObjectManager.h"
#include "QuestObjective.h"
#include "ItemManager.h"
#include "SocketManager.h"
#include "Viewport.h"
#include "Message.h"
#include "Notice.h"
#include "MasterSkillTree.h"
#include "CustomJewel.h"
#include "MapManager.h"

#if GAMESERVER_UPDATE == 603
CMuHelperOffline gMuHelperOffline;

CMuHelperOffline::CMuHelperOffline()
{

}

CMuHelperOffline::~CMuHelperOffline()
{

}

void CMuHelperOffline::Load(char* section, char* path)
{
	this->m_MuHelperOfflineSwitch = GetPrivateProfileInt(section, "MuHelperOfflineSwitch", 0, path);

	this->m_MuHelperOfflineEnable[0] = GetPrivateProfileInt(section, "MuHelperOfflineEnable_FREE", 1, path);

	this->m_MuHelperOfflineEnable[1] = GetPrivateProfileInt(section, "MuHelperOfflineEnable_VIP1", 1, path);

	this->m_MuHelperOfflineEnable[2] = GetPrivateProfileInt(section, "MuHelperOfflineEnable_VIP2", 1, path);

	this->m_MuHelperOfflineEnable[3] = GetPrivateProfileInt(section, "MuHelperOfflineEnable_VIP3", 1, path);

	this->m_MuHelperOfflineTime[0] = GetPrivateProfileInt(section, "MuHelperOfflineTime_FREE", 10, path);

	this->m_MuHelperOfflineTime[1] = GetPrivateProfileInt(section, "MuHelperOfflineTime_VIP1", 10, path);

	this->m_MuHelperOfflineTime[2] = GetPrivateProfileInt(section, "MuHelperOfflineTime_VIP2", 10, path);

	this->m_MuHelperOfflineTime[3] = GetPrivateProfileInt(section, "MuHelperOfflineTime_VIP3", 10, path);

	this->m_MuHelperOfflineAutoPickVip[0] = GetPrivateProfileInt(section, "MuHelperOfflineAutoPick_FREE", 1, path);

	this->m_MuHelperOfflineAutoPickVip[1] = GetPrivateProfileInt(section, "MuHelperOfflineAutoPick_VIP1", 1, path);

	this->m_MuHelperOfflineAutoPickVip[2] = GetPrivateProfileInt(section, "MuHelperOfflineAutoPick_VIP2", 1, path);

	this->m_MuHelperOfflineAutoPickVip[3] = GetPrivateProfileInt(section, "MuHelperOfflineAutoPick_VIP3", 1, path);

	this->m_MuHelperOfflineRequireLevel[0] = GetPrivateProfileInt(section, "MuHelperOfflineRequireLevel_FREE", 1, path);

	this->m_MuHelperOfflineRequireLevel[1] = GetPrivateProfileInt(section, "MuHelperOfflineRequireLevel_VIP1", 1, path);

	this->m_MuHelperOfflineRequireLevel[2] = GetPrivateProfileInt(section, "MuHelperOfflineRequireLevel_VIP2", 1, path);

	this->m_MuHelperOfflineRequireLevel[3] = GetPrivateProfileInt(section, "MuHelperOfflineRequireLevel_VIP3", 1, path);

	this->m_MuHelperOfflineRequireReset[0] = GetPrivateProfileInt(section, "MuHelperOfflineRequireReset_FREE", 0, path);

	this->m_MuHelperOfflineRequireReset[1] = GetPrivateProfileInt(section, "MuHelperOfflineRequireReset_VIP1", 0, path);

	this->m_MuHelperOfflineRequireReset[2] = GetPrivateProfileInt(section, "MuHelperOfflineRequireReset_VIP2", 0, path);

	this->m_MuHelperOfflineRequireReset[3] = GetPrivateProfileInt(section, "MuHelperOfflineRequireReset_VIP3", 0, path);
}

void CMuHelperOffline::MuHelperOfflineRecv(PMSG_MUHELPER_OFFLINE_RECV * lpMsg, int aIndex)
{
	if (!this->m_MuHelperOfflineSwitch) {
		return;
	}

	if (!gObjIsConnectedGP(aIndex))
	{
		return;
	}

	LPOBJ lpObj = &gObj[aIndex];

	if (this->m_MuHelperOfflineEnable[lpObj->AccountLevel] == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 850));
		return;
	}

	if (gMapManager.GetMapMuHelperOffline(lpObj->Map) == 0) {
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 850));
		return;
	}

	if (((gMasterSkillTree.CheckMasterLevel(lpObj) == 0) ? lpObj->Level : (lpObj->Level + lpObj->MasterLevel)) < this->m_MuHelperOfflineRequireLevel[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 851), this->m_MuHelperOfflineRequireLevel[lpObj->AccountLevel]);
		return;
	}

	if (lpObj->Reset < this->m_MuHelperOfflineRequireReset[lpObj->AccountLevel])
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 852), this->m_MuHelperOfflineRequireReset[lpObj->AccountLevel]);
		return;
	}

	if (lpObj->AttackCustom != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 853));
		return;
	}

	if (gMap[lpObj->Map].CheckAttr(lpObj->X, lpObj->Y, 1) != 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 854));
		return;
	}

	if (CA_MAP_RANGE(lpObj->Map) != 0 || DS_MAP_RANGE(lpObj->Map) != 0 || BC_MAP_RANGE(lpObj->Map) != 0 || CC_MAP_RANGE(lpObj->Map) != 0
		#if(GAMESERVER_UPDATE>=251)
		|| IT_MAP_RANGE(lpObj->Map) != 0 || DA_MAP_RANGE(lpObj->Map) != 0 || DG_MAP_RANGE(lpObj->Map) != 0 || IG_MAP_RANGE(lpObj->Map) != 0
		#endif
		)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 854));
		return;
	}

	if (lpMsg->SkillBasicID == 0)
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, gMessage.GetMessage(lpObj->m_Language, 855));
		return;
	}

	lpObj->HuntingRange = lpMsg->HuntingRange;
	//--
	lpObj->RecoveryPotionOn = lpMsg->RecoveryPotionOn;
	lpObj->RecoveryPotionPercent = lpMsg->RecoveryPotionPercent;
	lpObj->RecoveryHealOn = (lpObj->Class == CLASS_FE) ? lpMsg->RecoveryHealOn : 0; //-> CLASS_ELF
	lpObj->RecoveryHealPercent = (lpObj->Class == CLASS_FE) ? lpMsg->RecoveryHealPercent : 0; //-> CLASS_ELF
	lpObj->RecoveryDrainOn = (lpObj->Class == CLASS_SU) ? lpMsg->RecoveryDrainOn : 0; //-> CLASS_SUMMONER
	lpObj->RecoveryDrainPercent = (lpObj->Class == CLASS_SU) ? lpMsg->RecoveryDrainPercent : 0; //-> CLASS_SUMMONER

	lpObj->DistanceLongOn = lpMsg->DistanceLongOn;
	lpObj->DistanceReturnOn = lpMsg->DistanceReturnOn;
	lpObj->DistanceMin = lpMsg->DistanceMin;
	lpObj->SkillBasicID = lpMsg->SkillBasicID;
	lpObj->SkillSecondID = lpMsg->SkillSecondID;
	lpObj->SkillThirdID = lpMsg->SkillThirdID;
	lpObj->ComboOn = (lpObj->Class == CLASS_DK) ? lpMsg->ComboOn : 0;

	lpObj->PartyModeOn = lpMsg->PartyModeOn;
	lpObj->PartyModeHealOn = (lpObj->Class == CLASS_FE) ? lpMsg->PartyModeHealOn : 0;		//-> CLASS_ELF
	lpObj->PartyModeHealPercent = (lpObj->Class == CLASS_FE) ? lpMsg->PartyModeHealPercent : 0;	//-> CLASS_ELF
	lpObj->PartyModeBuffOn = lpMsg->PartyModeBuffOn;
	//--
	lpObj->BuffOn = lpMsg->BuffOn;
	lpObj->BuffSkill[0] = lpMsg->BuffSkill[0];
	lpObj->BuffSkill[1] = lpMsg->BuffSkill[1];
	lpObj->BuffSkill[2] = lpMsg->BuffSkill[2];
	lpObj->ObtainRange = (DWORD)lpMsg->ObtainRange;
	lpObj->ObtainRepairOn = lpMsg->ObtainRepairOn;
	lpObj->ObtainPickNear = (lpMsg->ObtainPickNear != 0) ? 1 : 0;
	lpObj->ObtainPickSelected = lpMsg->ObtainPickSelected;
	lpObj->ObtainPickJewels = (lpMsg->ObtainPickJewels != 0) ? 1 : 0;
	lpObj->ObtainPickAncient = (lpMsg->ObtainPickAncient != 0) ? 1 : 0;
	lpObj->ObtainPickMoney = (lpMsg->ObtainPickMoney != 0) ? 1 : 0;
	lpObj->ObtainPickExcellent = (lpMsg->ObtainPickExcellent != 0) ? 1 : 0;
	lpObj->ObtainPickExtra = (lpMsg->ObtainPickExtra != 0) ? 1 : 0;
	lpObj->ObtainPickExtraCount = lpMsg->ObtainPickExtraCount;
	lpObj->AutoPickTickTime = GetTickCount();
	lpObj->AutoAttackLastHit = GetTickCount();

	lpObj->m_CanUseAutoPick = this->m_MuHelperOfflineAutoPickVip[lpObj->AccountLevel];

	for (int i = 0; i < lpObj->ObtainPickExtraCount; ++i)
	{
		memcpy(lpObj->ObtainPickItemList[i], lpMsg->ObtainPickItemList[i], sizeof(lpObj->ObtainPickItemList[i]));
	}

	lpObj->Socket = INVALID_SOCKET;

	lpObj->m_OfflineCoordX = lpObj->X;
	lpObj->m_OfflineCoordY = lpObj->Y;
	lpObj->m_OfflineTimeResetMove = GetTickCount();
	lpObj->AttackCustomDelay = GetTickCount();
	lpObj->MuOffHelperTime = this->m_MuHelperOfflineTime[lpObj->AccountLevel] * 600;
	lpObj->m_OfflineMode = 1;
	lpObj->orderskill = 0;
	lpObj->orderskillMax = 0;

	if (lpMsg->SkillBasicID != 0) {
		lpObj->orderskillMax++;
	}
	else if (lpMsg->SkillSecondID != 0) {
		lpObj->orderskillMax++;
	}
	else if (lpMsg->SkillThirdID != 0) {
		lpObj->orderskillMax++;
	}

	closesocket(lpObj->PerSocketContext->Socket);
}

void CMuHelperOffline::OnAttackHelperAlreadyConnected(LPOBJ lpObj)
{
	if (lpObj->m_OfflineMode != 0) {
		gObjDel(lpObj->Index);
		lpObj->m_OfflineMode = 0;
		lpObj->MuOffHelperTime = 0;
	}
}

void CMuHelperOffline::OnAttackHelperSecondProc(LPOBJ lpObj)
{
	if (lpObj->m_OfflineMode != 0) {
		lpObj->CheckSumTime = GetTickCount();
		lpObj->ConnectTickCount = GetTickCount();
		lpObj->PcPointPointTime = ((gCustomAttack.m_CustomAttackOfflineGPGain == 0) ? GetTickCount() : lpObj->PcPointPointTime);
		lpObj->CashShopGoblinPointTime = ((gCustomAttack.m_CustomAttackOfflineGPGain == 0) ? GetTickCount() : lpObj->CashShopGoblinPointTime);
	}
}

void CMuHelperOffline::OnAttackMsgProc(LPOBJ lpObj)
{
	if (!gObjIsConnectedGP(lpObj->Index))
	{
		return;
	}

	if (lpObj->m_OfflineMode == 0)
	{
		return;
	}

	if (gMap[lpObj->Map].CheckAttr(lpObj->X, lpObj->Y, 1) != 0)
	{
		this->OnAttackHelperAlreadyConnected(lpObj);
		return;
	}

	if (lpObj->MuOffHelperTime > 0)
	{
		if ((--lpObj->MuOffHelperTime) == 0)
		{
			gObjDel(lpObj->Index);
			lpObj->m_OfflineMode = 0;
			lpObj->MuOffHelperTime = 0;
		}
	}

	this->AutoPotionProc(lpObj);

	this->AutoBuffProc(lpObj);

	this->AutoAttackProc(lpObj);

	this->AutoRepairProc(lpObj);
}

void CMuHelperOffline::AutoPotionProc(LPOBJ lpObj)
{
	//-- AUTO POTION HP
	if (lpObj->RecoveryPotionOn != 0) {
		if (lpObj->Life > 0 && lpObj->Life < ((lpObj->MaxLife * lpObj->RecoveryPotionPercent) / 100)) {
			PMSG_ITEM_USE_RECV pMsg;

			pMsg.header.set(0x26, sizeof(pMsg));

			pMsg.SourceSlot = 0xFF;

			pMsg.SourceSlot = ((pMsg.SourceSlot == 0xFF) ? gItemManager.GetInventoryItemSlot(lpObj, GET_ITEM(14, 3), -1) : pMsg.SourceSlot);

			pMsg.SourceSlot = ((pMsg.SourceSlot == 0xFF) ? gItemManager.GetInventoryItemSlot(lpObj, GET_ITEM(14, 2), -1) : pMsg.SourceSlot);

			pMsg.SourceSlot = ((pMsg.SourceSlot == 0xFF) ? gItemManager.GetInventoryItemSlot(lpObj, GET_ITEM(14, 1), -1) : pMsg.SourceSlot);

			pMsg.TargetSlot = 0xFF;

			pMsg.type = 0;

			if (INVENTORY_FULL_RANGE(pMsg.SourceSlot) != 0) {
				gItemManager.CGItemUseRecv(&pMsg, lpObj->Index);
			}
		}
	}

	//-- RECOVERY HEALING ELF
	if (lpObj->RecoveryHealOn != 0) {
		auto RenderSkillHealing = gSkillManager.GetSkill(lpObj, SKILL_HEAL);

		if (RenderSkillHealing != 0) {
			if (lpObj->Life < ((lpObj->MaxLife * lpObj->RecoveryHealPercent) / 100)) {
				if (gEffectManager.CheckEffect(lpObj, gSkillManager.GetSkillEffect(RenderSkillHealing->m_index)) == 0) {
					gSkillManager.UseAttackSkill(lpObj->Index, lpObj->Index, RenderSkillHealing);
				}
			}
		}
	}
}

void CMuHelperOffline::AutoBuffProc(LPOBJ lpObj)
{
	//-- AUTOBUFF ONLY
	if (lpObj->BuffOn != 0)  {
		for (int n = 0; n < 3; n++) {
			if (lpObj->BuffSkill[n] > 0) {
				auto RenderBuff = gSkillManager.GetSkill(lpObj, lpObj->BuffSkill[n]);

				if (RenderBuff != 0) {
					if (gEffectManager.CheckEffect(lpObj, gSkillManager.GetSkillEffect(RenderBuff->m_index)) == 0) {
						gSkillManager.UseAttackSkill(lpObj->Index, lpObj->Index, RenderBuff); //Buff Your self
					}
				}
			}
		}
	}

	//-- PARTY MODE ON
	if (lpObj->PartyModeOn != 0) {
		//-- PARTY HEAL ELF
		if (lpObj->PartyModeHealOn != 0 && lpObj->Class == CLASS_FE) {
			for (int i = 0; i < MAX_PARTY_USER; i++) {
				if (OBJECT_RANGE(gParty.m_PartyInfo[lpObj->PartyNumber].Index[i]) != 0) {
					auto RenderPartyHealing = gSkillManager.GetSkill(lpObj, SKILL_HEAL);

					if (RenderPartyHealing != 0) {
						auto lpTarget = &gObj[gParty.m_PartyInfo[lpObj->PartyNumber].Index[i]];

						if (lpTarget->Index == lpObj->Index) {
							continue;
						}

						if (lpTarget->Life < ((lpTarget->MaxLife * lpObj->PartyModeHealPercent) / 100)) {
							if (gEffectManager.CheckEffect(lpTarget, gSkillManager.GetSkillEffect(RenderPartyHealing->m_index)) == 0) {
								gSkillManager.UseAttackSkill(lpObj->Index, lpTarget->Index, RenderPartyHealing);
							}
						}
					}
				}
			}
		}
		//-- PARTY BUFF
		if (lpObj->PartyModeBuffOn != 0) {	
			for (int i = 0; i < MAX_PARTY_USER; i++) {
				if (OBJECT_RANGE(gParty.m_PartyInfo[lpObj->PartyNumber].Index[i]) != 0) {
					for (int n = 0; n < 3; n++) {
						if (lpObj->BuffSkill[n] > 0) {
							auto RenderPartyBuff = gSkillManager.GetSkill(lpObj, lpObj->BuffSkill[n]);

							if (RenderPartyBuff != 0) {
								if (gEffectManager.CheckEffect(&gObj[gParty.m_PartyInfo[lpObj->PartyNumber].Index[i]], gSkillManager.GetSkillEffect(RenderPartyBuff->m_index)) == 0) {
									gSkillManager.UseAttackSkill(lpObj->Index, gParty.m_PartyInfo[lpObj->PartyNumber].Index[i], RenderPartyBuff);
								}
							}
						}
					}
				}
			}
		}
	}
}

bool CMuHelperOffline::GetTargetMonster(LPOBJ lpObj, int SkillNumber, int * MonsterIndex)
{
	int NearestDistance = 100;

	for (int n = 0; n < MAX_VIEWPORT; n++)
	{
		if (lpObj->VpPlayer2[n].state == VIEWPORT_NONE || OBJECT_RANGE(lpObj->VpPlayer2[n].index) == 0 || lpObj->VpPlayer2[n].type != OBJECT_MONSTER)
		{
			continue;
		}

		if (gObj[lpObj->VpPlayer2[n].index].Live == 0 || OBJECT_RANGE(gObj[lpObj->VpPlayer2[n].index].SummonIndex) == 1) {
			continue;
		}

		if (gObjCalcDistance(lpObj, &gObj[lpObj->VpPlayer2[n].index]) >= lpObj->HuntingRange)
		{
			continue;
		}

		(*MonsterIndex) = lpObj->VpPlayer2[n].index;
		NearestDistance = gObjCalcDistance(lpObj, &gObj[lpObj->VpPlayer2[n].index]);
	}

	return 1;
}

void CMuHelperOffline::AutoAttackProc(LPOBJ lpObj)
{
	if ((GetTickCount() - lpObj->AutoAttackLastHit) < 20) {
		return;
	}

	lpObj->AutoAttackLastHit = GetTickCount();

	CSkill* SkillRender = nullptr;

	if ((lpObj->Life < ((lpObj->MaxLife * lpObj->RecoveryDrainPercent) / 100) && lpObj->RecoveryDrainOn != 0) && lpObj->Class == CLASS_SU) {
		SkillRender = gSkillManager.GetSkill(lpObj, SKILL_DRAIN_LIFE);
	}
	else {
		if (lpObj->orderskill == 0) {
			SkillRender = gSkillManager.GetSkill(lpObj, lpObj->SkillBasicID);
		}
		else if (lpObj->orderskill == 1) {
			SkillRender = gSkillManager.GetSkill(lpObj, lpObj->SkillSecondID);
		}
		else if (lpObj->orderskill == 2) {
			SkillRender = gSkillManager.GetSkill(lpObj, lpObj->SkillThirdID);
		}
		else {
			SkillRender = gSkillManager.GetSkill(lpObj, lpObj->SkillBasicID);
		}
	}

	if (SkillRender == nullptr) {
		(lpObj->orderskill > lpObj->orderskillMax ? lpObj->orderskill = 0 : lpObj->orderskill++);
		return;
	}

	int canAttack = 0;
	int needWalk = 0;
	int distance = ((lpObj->HuntingRange > 6) ? 6 : lpObj->HuntingRange) + 2;
	int tObjNum = -1;

	if (this->GetTargetMonster(lpObj, SkillRender->m_index, &tObjNum) != 0)
	{
		canAttack = 0;

		if (gObj[tObjNum].Live == 0 || gObj[tObjNum].State == OBJECT_EMPTY || gObj[tObjNum].RegenType != 0)
		{
			return;
		}

		if (OBJECT_RANGE(tObjNum) == 0)
		{
			return;
		}

		if (gObj[tObjNum].Type != OBJECT_MONSTER)
		{
			return;
		}

		if (gMap[lpObj->Map].CheckAttr(gObj[tObjNum].X, gObj[tObjNum].Y, 1) != 0)
		{
			return;
		}

		int dis = (int)sqrt((float)((lpObj->X - gObj[tObjNum].X) * (lpObj->X - gObj[tObjNum].X) + (lpObj->Y - gObj[tObjNum].Y) * (lpObj->Y - gObj[tObjNum].Y)));

		if (dis > distance)
		{
			return;
		}
		else {
			if (gSkillManager.CheckSkillRange(SkillRender->m_index, lpObj->X, lpObj->Y, gObj[tObjNum].X, gObj[tObjNum].Y) != 0) {
				needWalk = 0;
			}
			else {
				needWalk = 1;
			}

			if (gSkillManager.CheckSkillRadio(SkillRender->m_index, lpObj->X, lpObj->Y, gObj[tObjNum].X, gObj[tObjNum].Y) != 0) {
				needWalk = 0;
			}
			else {
				needWalk = 1;
			}

			if (needWalk == 1) {
				AnimationMove(lpObj, gObj[tObjNum].X, gObj[tObjNum].Y);
			}

			canAttack = 1;
		}

		if (canAttack != 0) {
			if (lpObj->Mana < gSkillManager.GetSkillMana(SkillRender->m_index)) {
				//-- AUTO POTION MP PRIMERO VALIDA QUE NO ESTE MUERTO
				PMSG_ITEM_USE_RECV pMsgMP;

				pMsgMP.header.set(0x26, sizeof(pMsgMP));

				pMsgMP.SourceSlot = 0xFF;

				pMsgMP.SourceSlot = ((pMsgMP.SourceSlot == 0xFF) ? gItemManager.GetInventoryItemSlot(lpObj, GET_ITEM(14, 6), -1) : pMsgMP.SourceSlot);

				pMsgMP.SourceSlot = ((pMsgMP.SourceSlot == 0xFF) ? gItemManager.GetInventoryItemSlot(lpObj, GET_ITEM(14, 5), -1) : pMsgMP.SourceSlot);

				pMsgMP.SourceSlot = ((pMsgMP.SourceSlot == 0xFF) ? gItemManager.GetInventoryItemSlot(lpObj, GET_ITEM(14, 4), -1) : pMsgMP.SourceSlot);

				pMsgMP.TargetSlot = 0xFF;

				pMsgMP.type = 0;

				if (INVENTORY_FULL_RANGE(pMsgMP.SourceSlot) != 0) {
					gItemManager.CGItemUseRecv(&pMsgMP, lpObj->Index);
				}
				else {
					return;
				}
			}

			int MultiplyAttack = (lpObj->Class == CLASS_RF) ? 1 : 5;

			if ((GetTickCount() - ((DWORD)lpObj->AttackCustomDelay)) >= (((((DWORD)lpObj->PhysiSpeed) * MultiplyAttack) > 250) ? 0 : (250 - (((DWORD)lpObj->PhysiSpeed) * MultiplyAttack)))) {
				(lpObj->orderskill > lpObj->orderskillMax ? lpObj->orderskill = 0 : lpObj->orderskill++);

				lpObj->AttackCustomDelay = GetTickCount();

				if (SkillRender->m_skill != SKILL_FLAME
					&& SkillRender->m_skill != SKILL_TWISTER
					&& SkillRender->m_skill != SKILL_EVIL_SPIRIT
					&& SkillRender->m_skill != SKILL_HELL_FIRE
					&& SkillRender->m_skill != SKILL_AQUA_BEAM
					&& SkillRender->m_skill != SKILL_BLAST
					&& SkillRender->m_skill != SKILL_INFERNO
					&& SkillRender->m_skill != SKILL_TRIPLE_SHOT
					&& SkillRender->m_skill != SKILL_IMPALE
					&& SkillRender->m_skill != SKILL_MONSTER_AREA_ATTACK
					&& SkillRender->m_skill != SKILL_PENETRATION
					&& SkillRender->m_skill != SKILL_FIRE_SLASH
					&& SkillRender->m_skill != SKILL_FIRE_SCREAM) {
					if (SkillRender->m_skill != SKILL_DARK_SIDE) {

						PMSG_DURATION_SKILL_ATTACK_RECV pMsg;

						pMsg.header.set(0x1E, sizeof(pMsg));

						#if(GAMESERVER_UPDATE>=701)
						pMsg.skillH = SET_NUMBERHB(0);
						pMsg.skillL = SET_NUMBERLB((((GetLargeRand() % 100) >= 25) ? 1 : 0));
						#else
						pMsg.skill[0] = SET_NUMBERHB(SkillRender->m_index);
						pMsg.skill[1] = SET_NUMBERLB(SkillRender->m_index);
						#endif

						pMsg.x = (BYTE)gObj[tObjNum].X;

						pMsg.y = (BYTE)gObj[tObjNum].Y;

						pMsg.dir = (gSkillManager.GetSkillAngle(gObj[tObjNum].X, gObj[tObjNum].Y, lpObj->X, lpObj->Y) * 255) / 360;

						pMsg.dis = 0;

						pMsg.angle = (gSkillManager.GetSkillAngle(lpObj->X, lpObj->Y, gObj[tObjNum].X, gObj[tObjNum].Y) * 255) / 360;

						#if(GAMESERVER_UPDATE>=803)
						pMsg.indexH = SET_NUMBERHB(lpObj->TargetNumber);
						pMsg.indexL = SET_NUMBERLB(lpObj->TargetNumber);
						#else
						pMsg.index[0] = SET_NUMBERHB(tObjNum);
						pMsg.index[1] = SET_NUMBERLB(tObjNum);
						#endif

						pMsg.MagicKey = 0;

						gSkillManager.CGDurationSkillAttackRecv(&pMsg, lpObj->Index);
						gAttack.Attack(lpObj, &gObj[tObjNum], SkillRender, 0, 1, 0, 0, 0);
					}
					else {
						gCustomAttack.SendRFSkillAttack(lpObj, tObjNum, SkillRender->m_index);
					}
				}
				else {
					gCustomAttack.SendMultiSkillAttack(lpObj, tObjNum, SkillRender->m_index);
				}
			}
		}
	}
}

void CMuHelperOffline::AutoRepairProc(LPOBJ lpObj)
{
	for (int n = 0; n < INVENTORY_WEAR_SIZE; ++n)
	{
		if (lpObj->Inventory[n].IsItem() != 0)
		{
			int money = gItemManager.RepairItem(lpObj, &lpObj->Inventory[n], n, 1);

			if (money != 0)
			{
				gObjectManager.CharacterCalcAttribute(lpObj->Index);
			}
		}
	}
}

void CMuHelperOffline::AnimationMove(LPOBJ lpObj, int x, int y)
{
	BYTE path[8];

	if (lpObj->Teleport != 0)
	{
		return;
	}

	if (gObjCheckMapTile(lpObj, 1) != 0)
	{
		return;
	}

	if ((timeGetTime() - lpObj->LastMoveTime) < 100)
	{
		return;
	}

	if (gEffectManager.CheckStunEffect(lpObj) != 0 || gEffectManager.CheckImmobilizeEffect(lpObj) != 0)
	{
		return;
	}

	if (lpObj->SkillSummonPartyTime != 0)
	{
		lpObj->SkillSummonPartyTime = 0;
	}

	lpObj->Dir = path[0] >> 4;
	lpObj->Rest = 0;
	lpObj->PathCur = 0;
	lpObj->PathCount = path[0] & 0x0F;
	lpObj->LastMoveTime = timeGetTime();

	memset(lpObj->PathX, 0, sizeof(lpObj->PathX));

	memset(lpObj->PathY, 0, sizeof(lpObj->PathY));

	memset(lpObj->PathOri, 0, sizeof(lpObj->PathOri));

	lpObj->TX = x;
	lpObj->TY = y;
	lpObj->PathCur = ((lpObj->PathCount > 0) ? 1 : 0);
	lpObj->PathCount = ((lpObj->PathCount > 0) ? (lpObj->PathCount + 1) : lpObj->PathCount);
	lpObj->PathStartEnd = 1;
	lpObj->PathX[0] = x;
	lpObj->PathY[0] = y;
	lpObj->PathDir[0] = lpObj->Dir;

	for (int n = 1; n < lpObj->PathCount; n++)
	{
		if ((n % 2) == 0)
		{
			lpObj->TX = lpObj->PathX[n - 1] + RoadPathTable[((path[((n + 1) / 2)] & 0x0F) * 2) + 0];
			lpObj->TY = lpObj->PathY[n - 1] + RoadPathTable[((path[((n + 1) / 2)] & 0x0F) * 2) + 1];
			lpObj->PathX[n] = lpObj->PathX[n - 1] + RoadPathTable[((path[((n + 1) / 2)] & 0x0F) * 2) + 0];
			lpObj->PathY[n] = lpObj->PathY[n - 1] + RoadPathTable[((path[((n + 1) / 2)] & 0x0F) * 2) + 1];
			lpObj->PathOri[n - 1] = path[((n + 1) / 2)] & 0x0F;
			lpObj->PathDir[n + 0] = path[((n + 1) / 2)] & 0x0F;
		}
		else
		{
			lpObj->TX = lpObj->PathX[n - 1] + RoadPathTable[((path[((n + 1) / 2)] / 0x10) * 2) + 0];
			lpObj->TY = lpObj->PathY[n - 1] + RoadPathTable[((path[((n + 1) / 2)] / 0x10) * 2) + 1];
			lpObj->PathX[n] = lpObj->PathX[n - 1] + RoadPathTable[((path[((n + 1) / 2)] / 0x10) * 2) + 0];
			lpObj->PathY[n] = lpObj->PathY[n - 1] + RoadPathTable[((path[((n + 1) / 2)] / 0x10) * 2) + 1];
			lpObj->PathOri[n - 1] = path[((n + 1) / 2)] / 0x10;
			lpObj->PathDir[n + 0] = path[((n + 1) / 2)] / 0x10;
		}
	}

	lpObj->X = x;
	lpObj->Y = y;
	lpObj->TX = lpObj->TX;
	lpObj->TY = lpObj->TY;
	lpObj->OldX = lpObj->TX;
	lpObj->OldY = lpObj->TY;
	lpObj->ViewState = 0;

	gMap[lpObj->Map].SetStandAttr(lpObj->TX, lpObj->TY);

	PMSG_MOVE_SEND pMsg;

	pMsg.header.set(PROTOCOL_CODE1, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(lpObj->Index);

	pMsg.index[1] = SET_NUMBERLB(lpObj->Index);

	pMsg.x = (BYTE)lpObj->TX;

	pMsg.y = (BYTE)lpObj->TY;

	pMsg.dir = lpObj->Dir << 4;

	lpObj->PathCur = 0;
	lpObj->PathCount = 0;
	lpObj->TX = lpObj->X;
	lpObj->TY = lpObj->Y;
	pMsg.x = (BYTE)lpObj->X;
	pMsg.y = (BYTE)lpObj->Y;

	for (int n = 0; n < MAX_VIEWPORT; n++)
	{
		if (lpObj->VpPlayer2[n].type == OBJECT_USER)
		{
			if (lpObj->VpPlayer2[n].state != OBJECT_EMPTY && lpObj->VpPlayer2[n].state != OBJECT_DIECMD && lpObj->VpPlayer2[n].state != OBJECT_DIED)
			{
				DataSend(lpObj->VpPlayer2[n].index, (BYTE*)&pMsg, pMsg.header.size);
			}
		}
	}
}

void CMuHelperOffline::AutoTurnBack(int aIndex)
{
	if (!gObjIsConnectedGP(aIndex))
	{
		return;
	}

	LPOBJ lpObj = &gObj[aIndex];

	if (lpObj->m_OfflineMode == 0)
	{
		return;
	}

	if (gMap[lpObj->Map].CheckAttr(lpObj->X, lpObj->Y, 1) != 0)
	{
		return;
	}

	if (lpObj->DistanceReturnOn != 0) {
		if (GetTickCount() >= lpObj->m_OfflineTimeResetMove + 1000 + (lpObj->DistanceMin * 1000)) {
			if (lpObj->m_OfflineCoordX != lpObj->X && lpObj->m_OfflineCoordY != lpObj->Y) {
				AnimationMove(lpObj, lpObj->m_OfflineCoordX, lpObj->m_OfflineCoordY);
			}

			lpObj->m_OfflineTimeResetMove = GetTickCount();
		}
	}
}

void CMuHelperOffline::AutoPickProc(int aIndex)
{
	if (!gObjIsConnectedGP(aIndex))
	{
		return;
	}

	LPOBJ lpObj = &gObj[aIndex];

	if (lpObj->m_OfflineMode == 0)
	{
		return;
	}

	if (!lpObj->m_CanUseAutoPick) {
		return;
	}

	if ((int)(GetTickCount() - lpObj->AutoPickTickTime) < 100) {
		return;
	}

	if (MAP_RANGE(lpObj->Map) == 0) {
		return;
	}

	if (gMap[lpObj->Map].CheckAttr(lpObj->X, lpObj->Y, 1) != 0)
	{
		return;
	}

	if (lpObj->DieRegen != 0) {
		return;
	}

	int OldX;
	int OldY;
	bool canPick = false;

	for (int n = 0; n < MAX_VIEWPORT; n++) {
		if (lpObj->VpPlayerItem[n].state != VIEWPORT_WAIT) {
			continue;
		}

		if (lpObj->VpPlayerItem[n].type != OBJECT_ITEM) {
			continue;
		}

		if (MAP_ITEM_RANGE(lpObj->VpPlayerItem[n].index) == 0) {
			continue;
		}

		auto lpMapItem = &gMap[lpObj->Map].m_Item[lpObj->VpPlayerItem[n].index];

		if (lpMapItem->IsItem() == 0 || lpMapItem->m_Give != 0 || lpMapItem->m_Live == 0) {
			continue;
		}

		if (lpMapItem->IsEventItem() != 0) {
			continue;
		}

		if (lpMapItem->IsMuunItem() != 0 || lpMapItem->IsMuunUtil() != 0) {
			continue;
		}

		if (gMap[lpObj->Map].CheckAttr(lpMapItem->m_X, lpMapItem->m_Y, 1) != 0)
		{
			continue;
		}

		int dis = (int)sqrt((float)((lpObj->X - lpMapItem->m_X) * (lpObj->X - lpMapItem->m_X) + (lpObj->Y - lpMapItem->m_Y) * (lpObj->Y - lpMapItem->m_Y)));

		if (dis > lpObj->ObtainRange) {
			continue;
		}

		canPick = false;

		int index = lpObj->VpPlayerItem[n].index;

		OldX = lpObj->X;
		OldY = lpObj->Y;

		if (lpObj->ObtainPickSelected == 1) {
			if ((lpObj->ObtainPickMoney == 1 && lpMapItem->m_Index == GET_ITEM(14, 15))
				|| (lpObj->ObtainPickExcellent == 1 && lpMapItem->m_NewOption > 0)
				|| (lpObj->ObtainPickAncient == 1 && lpMapItem->m_SetOption > 0)
				|| (lpObj->ObtainPickJewels == 1 && this->checkJewel(lpMapItem->m_Index) == true)) {
				canPick = true;
				this->AnimationMove(lpObj, lpMapItem->m_X, lpMapItem->m_Y);
			}
			else if (lpObj->ObtainPickExtra == 1) {
				if (this->checkListPickUp(lpMapItem->m_Index, lpMapItem->m_Level, lpObj) == true) {
					canPick = true;
					this->AnimationMove(lpObj, lpMapItem->m_X, lpMapItem->m_Y);
				}
			}
		}

		if (canPick == false) {
			continue;
		}

		if (gMap[lpObj->Map].CheckItemGive(aIndex, index) == 0) {
			continue;
		}

		if (lpObj->X == lpMapItem->m_X && lpObj->Y == lpMapItem->m_Y) {
			//zen item
			if (lpMapItem->m_Index == GET_ITEM(14, 15)) {
				if (lpObj->ObtainPickMoney == 1) {
					gMap[lpObj->Map].ItemGive(aIndex, index);

					if (!gObjCheckMaxMoney(aIndex, lpMapItem->m_BuyMoney)) {
						if (lpObj->Money < MAX_MONEY) {
							lpObj->Money = MAX_MONEY;
							continue;
						}
					}
					else {
						lpObj->Money += lpMapItem->m_BuyMoney;
					}
					continue;
				}
			}
			//all items
			if (lpMapItem->m_QuestItem != false) {
				if (!gQuestObjective.CheckQuestObjectiveItemCount(lpObj, lpMapItem->m_Index, lpMapItem->m_Level))
				{
					continue;
				}
			}

			CItem item = (*lpMapItem);

			if (gItemManager.InventoryInsertItemStack(lpObj, &item) != 0)
			{
				gMap[lpObj->Map].ItemGive(aIndex, index);
				continue;
			}

			if (gItemManager.InventoryInsertItem(aIndex, item) != 0xFF) {
				gMap[lpObj->Map].ItemGive(aIndex, index);

				GCPartyItemInfoSend(aIndex, &item);
				continue;
			}
		}
	}

	lpObj->AutoPickTickTime = GetTickCount();
}

bool CMuHelperOffline::checkJewel(int ItemIndex)
{
	if (ItemIndex == GET_ITEM(12, 15) ||
		ItemIndex == GET_ITEM(14, 13) ||
		ItemIndex == GET_ITEM(14, 14) ||
		ItemIndex == GET_ITEM(14, 16) ||
		ItemIndex == GET_ITEM(14, 22) ||
		ItemIndex == GET_ITEM(14, 31) ||
		ItemIndex == GET_ITEM(14, 42) ||
		gCustomJewel.CheckCustomJewelByItem(ItemIndex))
	{
		return 1;
	}

	return 0;
}

bool CMuHelperOffline::checkListPickUp(int Index, int Level, LPOBJ lpObj)
{
	for (int i = 0; i < lpObj->ObtainPickExtraCount; i++) {
		ITEM_INFO ItemInfo;

		if (gItemManager.GetInfo(Index, &ItemInfo) == 0)
		{
			continue;
		}

		if (strstr(ItemInfo.Name, lpObj->ObtainPickItemList[i]) != 0) {
			return 1;
		}
	}

	return 0;
}
#endif