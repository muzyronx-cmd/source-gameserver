// Notice.h: interface for the CNotice class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "Protocol.h"

//**********************************************//
//************ GameServer -> Client ************//
//**********************************************//

struct PMSG_NOTICE_SEND
{
	PBMSG_HEAD header; // C1:0D
	BYTE type;
	#if(GAMESERVER_UPDATE>=99)
	BYTE count;
	BYTE opacity;
	WORD delay;
	DWORD color;
	BYTE speed;
	#endif
	char message[256];
};

//**********************************************//
//**********************************************//
//**********************************************//

class CNotice
{
public:
	CNotice();
	virtual ~CNotice();
	void GCNoticeSend(int aIndex,BYTE type,BYTE count,BYTE opacity,WORD delay,DWORD color,BYTE speed,char* message,...);
	void GCNoticeSend2(int aIndex, BYTE type, BYTE count, BYTE opacity, WORD delay, DWORD color, BYTE speed, char* message);
	void GCNoticeSend3(int aIndex, BYTE type, BYTE count, BYTE opacity, WORD delay, DWORD color, BYTE speed, char* message, va_list arg);
	void GCNoticeSendToAll(BYTE type,BYTE count,BYTE opacity,WORD delay,DWORD color,BYTE speed,char* message,...);
	void GCNoticeSendToAll2(BYTE type, BYTE count, BYTE opacity, WORD delay, DWORD color, BYTE speed, char* message);
	void GCNoticeSendToAllMultLanguage(BYTE type, BYTE count, BYTE opacity, WORD delay, DWORD color, BYTE speed, int msgIndex, ...);
};

extern CNotice gNotice;
