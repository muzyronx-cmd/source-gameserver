#pragma once

class SKILL_HACK_SPEED_CHECK_INFO {
public:
	SKILL_HACK_SPEED_CHECK_INFO() {
		this->MinSpeed = 0;
		this->MaxSpeed = 0;
		this->Delay = 0;
		this->Count = 0;
	};

	~SKILL_HACK_SPEED_CHECK_INFO() {

	};

	int MinSpeed;
	int MaxSpeed;
	int Delay;
	int Count;
};

class SKILL_HACK_SPEED_CHECK_OBJ {
public:
	SKILL_HACK_SPEED_CHECK_OBJ() {
		this->skill = -1;

		this->m_SkillHackSpeedCheckInfo.clear();
	};

	~SKILL_HACK_SPEED_CHECK_OBJ() {
		this->m_SkillHackSpeedCheckInfo.clear();
	};

	int skill;
	std::vector<SKILL_HACK_SPEED_CHECK_INFO> m_SkillHackSpeedCheckInfo;
};

class CSkillHackSpeedCheck {
public:
	CSkillHackSpeedCheck();
	~CSkillHackSpeedCheck();

	void Load(char* path);
	SKILL_HACK_SPEED_CHECK_OBJ* GetSkillInfo(int skill);
	bool CheckSkillSpeedHack(int aIndex, int skill);
	bool CheckSkillSpeedHackDelay(int aIndex, int index, int Delay);
	bool CheckSkillSpeedHackMaxDelay(int aIndex, int index, int MaxDelay);
	bool CheckSkillSpeedHackCount(int aIndex, int index, int Count);
	bool CheckSkillPlayerSpeedMin(int aIndex, int Speed);
	bool CheckSkillPlayerSpeedMax(int aIndex, int Speed);

private:
	std::map<int, SKILL_HACK_SPEED_CHECK_OBJ> m_SkillHackSpeedCheckObj;
};

extern CSkillHackSpeedCheck gSkillHackSpeedCheck;