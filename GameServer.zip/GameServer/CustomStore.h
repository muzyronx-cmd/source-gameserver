// CustomStore.h: interface for the CCustomStore class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "PersonalShop.h"
#include "User.h"

#ifdef CUSTOM_GAMESERVER
struct PMSG_OFF_TRADE_ITEM_SAVE_SEND
{
	PSBMSG_HEAD header;
	char account[11];
	char name[11];
	int value;
	int coin;
	BYTE item[19];
	BYTE slot;
	BYTE map;
	BYTE x;
	BYTE y;
};

struct PMSG_OFF_TRADE_DELETE_ITEM_SEND
{
	PSBMSG_HEAD header;
	char account[11];
	char name[11];
	BYTE slot;
};

struct PMSG_OFF_TRADE_DELETE_ALL_ITEM_SEND
{
	PSBMSG_HEAD header;
	char account[11];
	char name[11];
};
#endif

class CCustomStore
{
public:
	CCustomStore();
	virtual ~CCustomStore();
	void ReadCustomStoreInfo(char* section,char* path);
#ifdef CUSTOM_GAMESERVER
	void CustomStoreOpen(LPOBJ lpObj, int type);
#endif
	void CommandCustomStore(LPOBJ lpObj,char* arg);
	void CommandCustomStoreOffline(LPOBJ lpObj,char* arg);
	void OpenCustomStore(LPOBJ lpObj,int type);
	bool OnPShopOpen(LPOBJ lpObj);
	void OnPShopClose(LPOBJ lpObj);
	void OnPShopSecondProc(LPOBJ lpObj);
	void OnPShopAlreadyConnected(LPOBJ lpObj);
	void OnPShopItemList(LPOBJ lpObj,LPOBJ lpTarget);
	bool OnPShopBuyItemRecv(PMSG_PSHOP_BUY_ITEM_RECV* lpMsg,int aIndex);
	static void OnPShopBuyItemCallbackRecv(LPOBJ lpObj,LPOBJ lpTarget,DWORD slot,DWORD WCoinC,DWORD WCoinP,DWORD GoblinPoint);

#ifdef CUSTOM_GAMESERVER
	void SendOfflineTrade(LPOBJ lpObj);
	void SendDeleteItemOffTrade(LPOBJ lpObj, BYTE slot);
	void SendDeleteAllItemOffTrade(LPOBJ lpObj);
#endif
public:
	int m_CustomStoreSwitch;
	int m_CustomStoreMapZone;
	int m_CustomStoreEnable[4];
	int m_CustomStoreTime[4];
	int m_CustomStoreRequireLevel[4];
	int m_CustomStoreRequireReset[4];
	char m_CustomStoreCommandSyntax[32];
	char m_CustomStoreCommandJoBSyntax[32];
	char m_CustomStoreCommandJoSSyntax[32];
	char m_CustomStoreCommandJoCSyntax[32];
	char m_CustomStoreCommandWCCSyntax[32];
	char m_CustomStoreCommandWCPSyntax[32];
	char m_CustomStoreCommandWCGSyntax[32];
	char m_CustomStoreJoBName[36];
	char m_CustomStoreJoSName[36];
	char m_CustomStoreJoCName[36];
	char m_CustomStoreWCCName[36];
	char m_CustomStoreWCPName[36];
	char m_CustomStoreWCGName[36];
	int m_CustomStoreOfflineSwitch;
	int m_CustomStoreOfflineGPGain;
	int m_CustomStoreOfflineMapZone;
	int m_CustomStoreOfflineEnable[4];
	int m_CustomStoreOfflineRequireLevel[4];
	int m_CustomStoreOfflineRequireReset[4];
	char m_CustomStoreOfflineCommandSyntax[32];
};

extern CCustomStore gCustomStore;
