#pragma once

#include "Protocol.h"

#if (GAMESERVER_UPDATE==201)

struct SDHP_PERIODIC_ITEM_SEND
{
	PSWMSG_HEAD header; // C2:18:05
	WORD index;
	char account[11];
	BYTE count;
};

struct SDHP_PERIODIC_ITEM_RECV
{
	PSWMSG_HEAD header;
	WORD index;
	char account[11];
	BYTE count;
};

struct SDHP_PERIODIC_ITEM1
{
	BYTE slot;
	DWORD serial;
	DWORD time;
};

struct SDHP_PERIODIC_ITEM2
{
	BYTE slot;
	DWORD serial;
};

struct SDHP_PERIODIC_PICK_UP_SEND
{
	PSBMSG_HEAD header;
	WORD index;
	WORD npcindex;
	char account[11];
};

struct SDHP_PERIODIC_PICK_UP_RECV
{
	PSBMSG_HEAD header;
	WORD index;
	WORD npcindex;
	char account[11];
	int Id;
	int Section;
	int ItemIndex;
	int Days;
	int Level;
	int Skill;
	int Luck;
	int Opt;
	int Exc;
	int IsPeriodic;
	BYTE Result;
};

struct SDHP_PERIODIC_ITEM_DEL_SEND
{
	PSBMSG_HEAD header;
	DWORD Serial;
};

struct SDHP_PERIODIC_ITEM_SAVE_SEND
{
	PSWMSG_HEAD header; // C2:18:34
	WORD index;
	char account[11];
	BYTE count;
};

struct SDHP_PERIODIC_ITEM_SAVE
{
	DWORD serial;
	DWORD time;
};

struct PMSG_PERIODIC_ITEM_SEND
{
	PSWMSG_HEAD h;
	BYTE count;
	BYTE Type;
};

struct PMSG_PERIODIC_ITEM
{
	WORD ItemIndex;
	BYTE Slot;
	DWORD Timer;
	BYTE Type;
	DWORD TickCount;
};

class ItemDuration
{
public:
	ItemDuration();
	virtual ~ItemDuration();

	void MainProc();
	void SendInformationMain(int aIndex);
	void DGPeriodicItemSend(int aIndex);
	void DGPeriodicWarehouseItemSend(int aIndex);
	void DGPeriodicItemRecv(SDHP_PERIODIC_ITEM_RECV* lpMsg);
	void DGPeriodicWarehouseItemRecv(SDHP_PERIODIC_ITEM_RECV* lpMsg);
	bool NpcTalkPeriodicItem(LPOBJ lpNpc, LPOBJ lpObj);
	void PickUpItemSend(LPOBJ lpObj);
	void PickUpItemRecv(SDHP_PERIODIC_PICK_UP_RECV * lpMsg);
	bool DGPeriodicItemDelSend(DWORD Serial);
	void DGPeriodicItemTimeSaveSend(int aIndex);
	void DGPeriodicItemTimeSaveCMSend(int aIndex);
	int GetNewPeriodicTimer(int Hours);

	void SendInformationBySlot(LPOBJ lpObj);

}; extern ItemDuration gItemDuration;
#endif