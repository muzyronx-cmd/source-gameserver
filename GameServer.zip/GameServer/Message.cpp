// Message.cpp: implementation of the CMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Message.h"
#include "MemScript.h"
#include "Util.h"

CMessage gMessage;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMessage::CMessage() // OK
{
	memset(this->m_DefaultMessage,0,sizeof(this->m_DefaultMessage));

	this->m_MessageInfoEng.clear();
	this->m_MessageInfoPor.clear();
	this->m_MessageInfoSpn.clear();
}

CMessage::~CMessage() // OK
{

}

void CMessage::LoadMsgEng(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_MessageInfoEng.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			MESSAGE_INFO info;

			info.Index = lpMemScript->GetNumber();

			strcpy_s(info.Message, lpMemScript->GetAsString());

			this->m_MessageInfoEng.insert(std::pair<int, MESSAGE_INFO>(info.Index, info));
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void CMessage::LoadMsgPor(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_MessageInfoPor.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			MESSAGE_INFO info;

			info.Index = lpMemScript->GetNumber();

			strcpy_s(info.Message, lpMemScript->GetAsString());

			this->m_MessageInfoPor.insert(std::pair<int, MESSAGE_INFO>(info.Index, info));
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void CMessage::LoadMsgSpn(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_MessageInfoSpn.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			MESSAGE_INFO info;

			info.Index = lpMemScript->GetNumber();

			strcpy_s(info.Message, lpMemScript->GetAsString());

			this->m_MessageInfoSpn.insert(std::pair<int, MESSAGE_INFO>(info.Index, info));
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

char* CMessage::GetInfoEng(int index)
{
	std::map<int, MESSAGE_INFO>::iterator it = this->m_MessageInfoEng.find(index);

	if (it == this->m_MessageInfoEng.end())
	{
		wsprintf(this->m_DefaultMessage, "Could not find message %d!", index);
		return this->m_DefaultMessage;
	}
	else
	{
		return it->second.Message;
	}
}

char* CMessage::GetInfoPor(int index)
{
	std::map<int, MESSAGE_INFO>::iterator it = this->m_MessageInfoPor.find(index);

	if (it == this->m_MessageInfoPor.end())
	{
		wsprintf(this->m_DefaultMessage, "Could not find message %d!", index);
		return this->m_DefaultMessage;
	}
	else
	{
		return it->second.Message;
	}
}

char* CMessage::GetInfoSpn(int index)
{
	std::map<int, MESSAGE_INFO>::iterator it = this->m_MessageInfoSpn.find(index);

	if (it == this->m_MessageInfoSpn.end())
	{
		wsprintf(this->m_DefaultMessage, "Could not find message %d!", index);
		return this->m_DefaultMessage;
	}
	else
	{
		return it->second.Message;
	}
}

char* CMessage::GetMessage(char* lang, int index) // OK
{
	if (strcmp(lang, "Eng") == 0)
	{
		return this->GetInfoEng(index);
	}

	if (strcmp(lang, "Por") == 0)
	{
		return this->GetInfoPor(index);
	}

	if (strcmp(lang, "Spn") == 0)
	{
		return this->GetInfoSpn(index);
	}

	return this->GetInfoEng(index);
}

char * CMessage::GetMessageGlobal(char * lang, int index)
{
	if (strcmp(lang, "Eng") == 0)
	{
		return this->GetInfoEng(index);
	}

	if (strcmp(lang, "Por") == 0)
	{
		return this->GetInfoPor(index);
	}

	if (strcmp(lang, "Spn") == 0)
	{
		return this->GetInfoSpn(index);
	}

	return this->GetInfoEng(index);
}