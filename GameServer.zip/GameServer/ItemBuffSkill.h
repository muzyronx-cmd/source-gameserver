#pragma once

#include "User.h"

struct ITEMBUFFSKILL_INFOS
{
	int Index;
	int Skill;
};

class ItemBuffSkill
{
public:
	ItemBuffSkill();
	virtual ~ItemBuffSkill();

	void Load(char * path);
	void ApplyBuffSkill(LPOBJ lpObj);

private:
	std::map<int, ITEMBUFFSKILL_INFOS> m_ItemBuffSkill;

}; extern ItemBuffSkill gItemBuffSkill;