#pragma once

#include "User.h"

struct ITEM_PET_ZONE_INFO
{
	int Index;
	int Damage;
	int DamageDec;
	int Level;
	int map;
	int x1;
	int y1;
	int x2;
	int y2;
};

class CItemPetDamageZone
{
public:
	CItemPetDamageZone();
	virtual ~CItemPetDamageZone();

	void Load(char * path);
	void SetDamage(LPOBJ lpObj, LPOBJ lpTarget, int * damage);

private:
	std::map<int, ITEM_PET_ZONE_INFO> m_PetZoneInfo;
};
extern CItemPetDamageZone gItemPetDamageZone;