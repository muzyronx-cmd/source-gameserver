#include "stdafx.h"
#include "SkillHackCheck.h"
#include "User.h"
#include "MemScript.h"
#include "Log.h"
#include "Util.h"
#include "ServerInfo.h"

CSkillHackCheck gSkillHackCheck;

CSkillHackCheck::CSkillHackCheck()
{
	this->m_SkillHackCheckObj.clear();
}

CSkillHackCheck::~CSkillHackCheck()
{
}

void CSkillHackCheck::Load(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_SkillHackCheckObj.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			SKILL_HACK_CHECK_OBJ info;

			info.skill = lpMemScript->GetNumber();

			SKILL_HACK_CHECK_INFO skillHackInfo;

			skillHackInfo.MinDetectHits = lpMemScript->GetAsNumber();

			skillHackInfo.MaxDetectHits = lpMemScript->GetAsNumber();

			skillHackInfo.MinDelay = lpMemScript->GetAsNumber();

			skillHackInfo.MaxDelay = lpMemScript->GetAsNumber();

			std::map<int, SKILL_HACK_CHECK_OBJ>::iterator it = this->m_SkillHackCheckObj.find(info.skill);

			if (it == this->m_SkillHackCheckObj.end()) {
				info.m_SkillHackCheckInfo.push_back(skillHackInfo);

				this->m_SkillHackCheckObj.insert(std::make_pair(info.skill, info));
			}
			else {
				it->second.m_SkillHackCheckInfo.push_back(skillHackInfo);
			}
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

SKILL_HACK_CHECK_OBJ * CSkillHackCheck::GetSkillInfo(int skill)
{
	std::map<int, SKILL_HACK_CHECK_OBJ>::iterator it = this->m_SkillHackCheckObj.find(skill);

	if (it == this->m_SkillHackCheckObj.end()) {
		return 0;
	}

	return &it->second;
}

bool CSkillHackCheck::CheckSkillHack(int aIndex, int skill)
{
	auto lpInfo = this->GetSkillInfo(skill);

	if (lpInfo == 0) {
		return 1;
	}

	auto lpObj = &gObj[aIndex];

	if (lpObj == 0) {
		return 1;
	}

	lpObj->SkillHackPacketCount[skill]++;

	int stack = 0;
	int maxStack = lpInfo->m_SkillHackCheckInfo.size();

	for (auto &skills : lpInfo->m_SkillHackCheckInfo) {
		stack++;

		if (gServerInfo.m_SkillHackCheckDebug) {
			gLog.Output(LOG_SKILL_HACK, "[%s][%s][%s] Debug Skill: %d, Hits Min: [%d/%d], Hits Max: [%d/%d] Delay Min: [%d/%d] Delay Max: [%d/%d]"
				, gObj[aIndex].Account, gObj[aIndex].Name, gDefaultClassInfo.m_className[lpObj->Class].c_str()
				, skill
				, lpObj->SkillHackPacketCount[skill], skills.MinDetectHits
				, lpObj->SkillHackPacketCount[skill], skills.MaxDetectHits
				, (timeGetTime() - gObj[aIndex].SkillHackPacketDelay[skill]), skills.MinDelay
				, (timeGetTime() - gObj[aIndex].SkillHackPacketDelay[skill]), skills.MaxDelay
			);
		}

		if (this->CheckSkillSkillHackMinDelay(aIndex, skill, skills.MinDelay)
			&& this->CheckSkillSkillHackMaxDelay(aIndex, skill, skills.MaxDelay)) {
			if (this->CheckSkillSkillHackMinHits(aIndex, skill, skills.MinDetectHits)) {
				if (this->CheckSkillSkillHackMaxHits(aIndex, skill, skills.MaxDetectHits)) {
					gLog.Output(LOG_SKILL_HACK, "[%s][%s][%s] Suspect Detected Skill: %d, Hits Min: [%d/%d], Hits Max: [%d/%d] Delay Min: [%d/%d] Delay Max: [%d/%d]"
						, gObj[aIndex].Account, gObj[aIndex].Name, gDefaultClassInfo.m_className[lpObj->Class].c_str()
						, skill
						, lpObj->SkillHackPacketCount[skill], skills.MinDetectHits
						, lpObj->SkillHackPacketCount[skill], skills.MaxDetectHits
						, (timeGetTime() - gObj[aIndex].SkillHackPacketDelay[skill]), skills.MinDelay
						, (timeGetTime() - gObj[aIndex].SkillHackPacketDelay[skill]), skills.MaxDelay
					);
					return 0;
				}
			}
		}
		else {
			if (stack == maxStack) {
				if (this->CheckSkillSkillHackMinDelay(aIndex, skill, skills.MinDelay)) {
					lpObj->SkillHackPacketCount[skill] = 0;
					lpObj->SkillHackPacketDelay[skill] = timeGetTime();
				}
			}
		}
	}

	return 1;
}

bool CSkillHackCheck::CheckSkillSkillHackMinHits(int aIndex, int index, int MinHits)
{
	return gObj[aIndex].SkillHackPacketCount[index] >= ((DWORD)MinHits) ? 1 : 0;
}

bool CSkillHackCheck::CheckSkillSkillHackMaxHits(int aIndex, int index, int MaxHits)
{
	return gObj[aIndex].SkillHackPacketCount[index] >= ((DWORD)MaxHits) ? 1 : 0;
}

bool CSkillHackCheck::CheckSkillSkillHackMinDelay(int aIndex, int index, int MinDelay)
{
	return (timeGetTime() - gObj[aIndex].SkillHackPacketDelay[index]) >= (DWORD)MinDelay ? 1 : 0;
}

bool CSkillHackCheck::CheckSkillSkillHackMaxDelay(int aIndex, int index, int MaxDelay)
{
	return (timeGetTime() - gObj[aIndex].SkillHackPacketDelay[index]) <= (DWORD)MaxDelay ? 1 : 0;
}
