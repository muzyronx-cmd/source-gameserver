#pragma once

#define AES_256_KEY_SIZE 32
#define AES_BLOCK_SIZE 16
#define BUFSIZE 1024

struct input {
	int encrypt;
	unsigned char key[AES_256_KEY_SIZE];
	unsigned char iv[AES_BLOCK_SIZE];
	unsigned char* data;
	unsigned int length;
};

struct output {
	unsigned char* data;
	unsigned int length;
};

output enc_dec(input* input);