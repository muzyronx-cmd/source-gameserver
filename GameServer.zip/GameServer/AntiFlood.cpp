#include "stdafx.h"
#include "AntiFlood.h"
#include "ServerInfo.h"
#include "Log.h"

CAntiFlood gAntiFlood;

CAntiFlood::CAntiFlood()
{
	this->m_AntiFloodInfo.clear();
}

CAntiFlood::~CAntiFlood()
{

}

void CAntiFlood::AddIpAddress(char * IpAddress)
{
	auto it = this->m_AntiFloodInfo.find(std::string(IpAddress));

	if (it == this->m_AntiFloodInfo.end())
	{
		auto info = new ANTI_FLOOD_INFO();

		info->IpAddress = std::string(IpAddress);

		info->Count = 1;

		info->TickCount = GetTickCount();

		this->m_AntiFloodInfo.insert(std::pair<std::string, ANTI_FLOOD_INFO*>(IpAddress, info));
	}
	else
	{
		it->second->Count++;
		it->second->LastActivity = GetTickCount();
	}
}

bool CAntiFlood::CheckFlood(char * IpAddress)
{
	auto it = this->m_AntiFloodInfo.find(std::string(IpAddress));

	if (it == this->m_AntiFloodInfo.end())
	{
		return 1;
	}
	else
	{
		if (it->second->Block)
		{
			if ((int)((GetTickCount() - it->second->LastActivity) / 1000) > gServerInfo.m_AntiFloodMaxTimeCheck)
			{
				delete it->second;
				this->m_AntiFloodInfo.erase(IpAddress);
				return 1;
			}

			if ((int)((GetTickCount() - it->second->BlockTime) / 1000) > gServerInfo.m_AntiFloodBlockTime)
			{
				delete it->second;
				this->m_AntiFloodInfo.erase(IpAddress);

				gLog.Output(LOG_HACK, "[PROTECTION] FLOOD [%s] IP UNLOCK", IpAddress);
				return 1;
			}

			return 0;
		}

		if ((int)((GetTickCount() - it->second->TickCount) / 1000) < gServerInfo.m_AntiFloodMinTimeCheck)
		{
			if (it->second->Count > gServerInfo.m_AntiFloodMaxCount)
			{
				if (!it->second->Block)
				{
					this->BlockIpAddress(IpAddress);
					return 0;
				}
			}
		}
		else
		{
			delete it->second;
			this->m_AntiFloodInfo.erase(IpAddress);
		}
	}

	return 1;
}

void CAntiFlood::BlockIpAddress(char * IpAddress)
{
	auto it = this->m_AntiFloodInfo.find(std::string(IpAddress));

	if (it != this->m_AntiFloodInfo.end())
	{
		it->second->Block = 1;
		it->second->BlockTime = GetTickCount();

		gLog.Output(LOG_HACK, "[PROTECTION] FLOOD DETECTED [%s] IP LOCK", IpAddress);
	}
}