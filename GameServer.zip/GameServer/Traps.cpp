#include "stdafx.h"
#include "Traps.h"
#include "Util.h"

Traps gTraps;

Traps::Traps()
{
}

Traps::~Traps()
{
}

void Traps::SendCheck(int aIndex)
{
	PMSG_SEND_TRAP pMsg;

	pMsg.header.set(0xFA, 0x9F, sizeof(pMsg));

	pMsg.wUserIndex = aIndex;

	pMsg.CurrTime = time(0);

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
}
