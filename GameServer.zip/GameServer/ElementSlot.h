#pragma once

#include "User.h"
#include "Protocol.h"

#if(GAMESERVER_UPDATE==201)
struct SDHP_ELEMENT_SLOT_GET_SEND
{
	PSBMSG_HEAD header; // C2:05:31
	WORD index;
	char account[11];
	char name[11];
};

struct SDHP_ELEMENT_SLOT_SAVE_SEND
{
	PSWMSG_HEAD header; // C2:05:30
	WORD index;
	char account[11];
	char name[11];
	BYTE ElementSlot[ELEMENT_SLOT_SIZE][MAX_ITEM_BYTE];
};

struct SDHP_ELEMENT_SLOT_SAVE_RECV
{
	PSWMSG_HEAD header; // C2:05:32
	WORD index;
	char account[11];
	char name[11];
	BYTE ElementSlot[ELEMENT_SLOT_SIZE][MAX_ITEM_BYTE];
};

struct PMSG_ELEMENT_SLOT_SEND
{
	PSWMSG_HEAD header; // C2:0xFB:0x11
	BYTE count;
};

struct ELEMENT_SLOT_INFO
{
	BYTE slot;
	BYTE ItemInfo[7];
};

class CElementSlot {
public:
	CElementSlot();
	virtual ~CElementSlot();

	void ElementSlotSaveSend(LPOBJ lpObj);
	void ElementSlotGetSend(LPOBJ lpObj);
	void ElementSlotRecv(SDHP_ELEMENT_SLOT_SAVE_RECV * lpMsg);
	void ElementSlotListSend(int aIndex);
};

extern CElementSlot gElementSlot;
#endif