// HackSpeedCheck.h: interface for the CSpeedHackCheck class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#define MAX_SKILL_DAMAGE 512

struct SKILL_DAMAGE_INFO
{
	void Reset()
	{
		this->Index = -1;
		this->Damage = 0;
	}

	int Index;
	int Damage;
};

class CSkillDamage
{
public:
	CSkillDamage();
	virtual ~CSkillDamage();
	void Init();
	void Load(char* path);
	void SetInfo(SKILL_DAMAGE_INFO info);
	SKILL_DAMAGE_INFO* GetInfo(int index);
	void DamageSkillCheck(int index, int* damage);
private:
	SKILL_DAMAGE_INFO m_SkillDamage[MAX_SKILL_DAMAGE];
};

extern CSkillDamage gSkillDamage;
