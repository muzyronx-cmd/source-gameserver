// Protect.cpp: implementation of the CProtect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Protect.h"
#include "ServerInfo.h"
#include "Util.h"
#include "CriticalSection.h"

CProtect gProtect;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define ENC(x) (char*)x

CProtect::CProtect() // OK
{

}

CProtect::~CProtect() // OK
{
	if (this->licenseThread.joinable()) {
		this->licenseThread.detach();
	}
}



bool CProtect::GetComputerHardwareId() // OK
{


	return 0;

}

bool CProtect::ConnectToAuthServer(char* IpAddress, WORD port) // OK
{


	return 0;

}

const unsigned char key[32] = { 
	0x10, 0x25, 0x05, 0xAB, 0xF2, 0x21
	, 0x57, 0x30, 0x22, 0x77, 0x63, 0x70
	, 0x08, 0xB9, 0xB2, 0xA3, 0x50, 0x38
	, 0x44, 0x11, 0x01, 0xA8, 0x08, 0xBB
	, 0xAC, 0x84, 0x57, 0x26, 0x4C, 0x8A
	, 0x9E, 0x1D 
};


bool CProtect::AuthServerDataSend(eAuthServerType ServerType) // OK
{


	return 0;

}

int GetDatabaseProductId(int ProductId) // OK
{
	switch (ProductId)
	{
	case AUTH_SERVER_TYPE_97_CONNECT_SERVER:
	case AUTH_SERVER_TYPE_97_JOIN_SERVER:
	case AUTH_SERVER_TYPE_97_DATA_SERVER:
	case AUTH_SERVER_TYPE_97_GAME_SERVER:
		return 1;
	case AUTH_SERVER_TYPE_99_CONNECT_SERVER:
	case AUTH_SERVER_TYPE_99_JOIN_SERVER:
	case AUTH_SERVER_TYPE_99_DATA_SERVER:
	case AUTH_SERVER_TYPE_99_GAME_SERVER:
		return 2;
	case AUTH_SERVER_TYPE_S1_CONNECT_SERVER:
	case AUTH_SERVER_TYPE_S1_JOIN_SERVER:
	case AUTH_SERVER_TYPE_S1_DATA_SERVER:
	case AUTH_SERVER_TYPE_S1_GAME_SERVER:
		return 3;
	case AUTH_SERVER_TYPE_S2_CONNECT_SERVER:
	case AUTH_SERVER_TYPE_S2_JOIN_SERVER:
	case AUTH_SERVER_TYPE_S2_DATA_SERVER:
	case AUTH_SERVER_TYPE_S2_GAME_SERVER:
		return 4;
	case AUTH_SERVER_TYPE_S4_CONNECT_SERVER:
	case AUTH_SERVER_TYPE_S4_JOIN_SERVER:
	case AUTH_SERVER_TYPE_S4_DATA_SERVER:
	case AUTH_SERVER_TYPE_S4_GAME_SERVER:
		return 5;
	case AUTH_SERVER_TYPE_S6_CONNECT_SERVER:
	case AUTH_SERVER_TYPE_S6_JOIN_SERVER:
	case AUTH_SERVER_TYPE_S6_DATA_SERVER:
	case AUTH_SERVER_TYPE_S6_GAME_SERVER:
		return 6;
	case AUTH_SERVER_TYPE_S8_CONNECT_SERVER:
	case AUTH_SERVER_TYPE_S8_JOIN_SERVER:
	case AUTH_SERVER_TYPE_S8_DATA_SERVER:
	case AUTH_SERVER_TYPE_S8_GAME_SERVER:
		return 7;
	}

	return -1;
}

void CProtect::StartAuthGS(eAuthServerType ServerTypes, bool checktimer) // OK
{

}

inline void CProtect::ErrorMessageBox() // OK
{

}

inline DWORD WINAPI CProtect::GameServerTheread(LPVOID lpParam)
{
again:
	switch ((int)lpParam)
	{
	case 0:
		ExitProcess(0);
	case 1:
		TerminateProcess(GetCurrentProcess(), 0);
	case 2:
		RaiseException(rand() % 0xFFFFFFFF, 0, 0, 0);
	case 3:
		__asm
		{
			mov eax, 0
			jmp eax
		}
	case 4:
		while (true)
		{
			TerminateProcess(GetCurrentProcess(), 0);
			CRASH_APPLICATION_MACRO
		}
	default:
		CreateThread(0, 0, gProtect.GameServerTheread, 0, 0, 0);
	}

	lpParam = 0;
	goto again;
}

inline void CProtect::SafeExitProcess() // OK
{
 
}

void CProtect::SetDisconnectRand()
{

}

void CProtect::SendDLLCustom(int aIndex)
{
	DLL_CUSTOM_SEND pMsg;

	pMsg.header.set(0xF3, 0xE3, sizeof(pMsg));

	memcpy(pMsg.m_NameServer, gProtect.GetServerName(), sizeof(pMsg.m_NameServer));

	memcpy(pMsg.m_NameServer, gProtect.GetDecryptedString(pMsg.m_NameServer, sizeof(pMsg.m_NameServer)), sizeof(pMsg.m_NameServer)); //Criptografar

	pMsg.m_HaveDLLCustom = this->GetDLLCustom();

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
}

char* CProtect::GetEncryptedString(BYTE* string, int size) // OK
{


	return 0;

}

char * CProtect::GetDecryptedString(char* string, int size)
{
#
	return 0;

}

char * CProtect::GetIpAddress()
{

	return 0;

}

char * CProtect::GetPrivateIpAddress()
{

	 return 0;

}

char * CProtect::GetServerName()
{

	return 0;

}

char * CProtect::GetHWID()
{
	return (char*)this->m_HDWID;
}

char * CProtect::GetServerKey()
{
	return (char*)this->m_ServerKey;
}

int CProtect::GetServerType()
{

	return 0;

}

char * CProtect::GetLicenseType()
{
	
	return (char*)ENC("COMPRADO");

}

char * CProtect::GetDays()
{
	return 0;
}

char * CProtect::GetLicenseMethod()
{
	return (char*)ENC("PLUS");
}

int CProtect::GetMaxWings()
{
	return 200;
}

int CProtect::GetMaxPets()
{
#if(GAMESERVER_UPDATE == 101)
	return 20;
#else
	return 100;
#endif
}

int CProtect::GetPatente()
{
#if (GAMESERVER_UPDATE == 101)
	return 1;
#else
	return 100;
#endif
}

int CProtect::GetMaxElementSlot()
{
	
	return 100;
	
}

void CProtect::CheckLicenseDays()
{

}

int CProtect::GetDLLCustom()
{
	return this->m_DLLCustom;
}

void CProtect::runThread()
{

}
