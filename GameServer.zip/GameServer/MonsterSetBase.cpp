// MonsterSetBase.cpp: implementation of the CMonsterSetBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MonsterSetBase.h"
#include "MapServerManager.h"
#include "MemScript.h"
#include "Path.h"
#include "Util.h"

CMonsterSetBase gMonsterSetBase;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMonsterSetBase::CMonsterSetBase() // OK
{
	this->Clear();
}

CMonsterSetBase::~CMonsterSetBase() // OK
{

}

void CMonsterSetBase::Clear()
{
	this->m_total_count = 0;

	for (int n = 0; n < MAX_MAP; n++) {
		this->m_count[n] = 0;
		this->m_MonsterSetBaseInfo[n].clear();
	}
}

void CMonsterSetBase::ClearMap(int map)
{
	this->m_total_count -= this->m_count[map];

	this->m_count[map] = 0;
	this->m_MonsterSetBaseInfo[map].clear();
}

void CMonsterSetBase::Load()
{
	this->Clear();

	std::map<int, int> MonsterSetBase;

	char wildcard_path[MAX_PATH];

	wsprintf(wildcard_path, "%s*", gPath.GetFullPath("MonsterSetBase\\"));

	WIN32_FIND_DATA data;

	HANDLE file = FindFirstFile(wildcard_path, &data);

	if (file == INVALID_HANDLE_VALUE)
	{
		return;
	}

	do
	{
		if ((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0)
		{
			if (isdigit(data.cFileName[0]) != 0 && isdigit(data.cFileName[1]) != 0 && isdigit(data.cFileName[2]) != 0)
			{
				if (data.cFileName[3] == ' ' && data.cFileName[4] == '-' && data.cFileName[5] == ' ')
				{
					int map = atoi(data.cFileName);

					if (MonsterSetBase.find(map) == MonsterSetBase.end())
					{
						char path[MAX_PATH];

						wsprintf(path, "MonsterSetBase\\%s", data.cFileName);

						this->Load(gPath.GetFullPath(path), map);

						MonsterSetBase.insert(std::pair<int, int>(map, 1));
					}
				}
			}
		}
	} while (FindNextFile(file, &data) != 0);

	wsprintf(wildcard_path, "%s", gPath.GetFullPath("MonsterSetBase\\Invasion\\InvasionMonsterSetBase.txt"));

	this->Load(wildcard_path, -1);
}

void CMonsterSetBase::Reload(int map)
{
	this->ClearMap(map);

	std::map<int, int> MonsterSetBase;

	char wildcard_path[MAX_PATH];

	wsprintf(wildcard_path, "%s*", gPath.GetFullPath("MonsterSetBase\\"));

	WIN32_FIND_DATA data;

	HANDLE file = FindFirstFile(wildcard_path, &data);

	if (file == INVALID_HANDLE_VALUE)
	{
		return;
	}

	do
	{
		if ((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0)
		{
			if (isdigit(data.cFileName[0]) != 0 && isdigit(data.cFileName[1]) != 0 && isdigit(data.cFileName[2]) != 0)
			{
				if (data.cFileName[3] == ' ' && data.cFileName[4] == '-' && data.cFileName[5] == ' ')
				{
					int mapMonster = atoi(data.cFileName);

					if (map != mapMonster) {
						continue;
					}

					if (MonsterSetBase.find(mapMonster) == MonsterSetBase.end())
					{
						char path[MAX_PATH];

						wsprintf(path, "MonsterSetBase\\%s", data.cFileName);

						this->Load(gPath.GetFullPath(path), map);

						MonsterSetBase.insert(std::pair<int, int>(mapMonster, 1));
					}
				}
			}
		}
	} while (FindNextFile(file, &data) != 0);

	wsprintf(wildcard_path, "%s", gPath.GetFullPath("MonsterSetBase\\Invasion\\InvasionMonsterSetBase.txt"));

	this->Load(wildcard_path, map);
}

void CMonsterSetBase::Load(char* path, int checkMap) // OK
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			int section = lpMemScript->GetNumber();

			while (true)
			{
				if (strcmp("end", lpMemScript->GetAsString()) == 0)
				{
					break;
				}

				MONSTER_SET_BASE_INFO info;

				memset(&info, 0, sizeof(info));

				info.Type = section;

				info.MonsterClass = lpMemScript->GetNumber();

				info.Map = lpMemScript->GetAsNumber();

				info.Dis = lpMemScript->GetAsNumber();

				info.X = lpMemScript->GetAsNumber();

				info.Y = lpMemScript->GetAsNumber();

				if (section == 1 || section == 3)
				{
					info.TX = lpMemScript->GetAsNumber();
					info.TY = lpMemScript->GetAsNumber();
				}
				else if (section == 2)
				{
					info.X = (info.X - 3) + GetLargeRand() % 7;
					info.Y = (info.Y - 3) + GetLargeRand() % 7;
				}

				info.Dir = lpMemScript->GetAsNumber();

				if (section == 1 || section == 3)
				{
					int count = lpMemScript->GetAsNumber();

					if (section == 3)
					{
						info.Value = lpMemScript->GetAsNumber();
					}

					if (checkMap != -1 && info.Map != checkMap) {
						continue;
					}

					for (int n = 0; n < count; n++)
					{
						this->SetInfo(info, info.Map);
					}
				}
				else
				{
					if (checkMap != -1 && info.Map != checkMap) {
						continue;
					}

					this->SetInfo(info, info.Map);
				}
			}
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void CMonsterSetBase::SetInfo(MONSTER_SET_BASE_INFO info, int map) // OK
{
	if(this->m_total_count < 0 || this->m_total_count >= MAX_MSB_MONSTER)
	{
		return;
	}
	
	if(gMapServerManager.CheckMapServer(info.Map) == 0)
	{
		return;
	}

	info.Dir = ((info.Dir==-1)?(GetLargeRand()%8):info.Dir);

	this->m_MonsterSetBaseInfo[map].insert(std::make_pair(this->m_count[map]++, info));

	this->m_total_count++;
}

bool CMonsterSetBase::GetPosition(int index,short map,short* ox,short* oy) // OK
{
	if(index < 0 || index >= MAX_MSB_MONSTER)
	{
		return 0;
	}

	MONSTER_SET_BASE_INFO* lpInfo = &this->m_MonsterSetBaseInfo[map][index];
	
	if(lpInfo->Type == 0 || lpInfo->Type == 4)
	{
		(*ox) = lpInfo->X;
		(*oy) = lpInfo->Y;
		return 1;
	}
	else if(lpInfo->Type == 1 || lpInfo->Type == 3)
	{
		return this->GetBoxPosition(map,lpInfo->X,lpInfo->Y,lpInfo->TX,lpInfo->TY,ox,oy);
	}
	else if(lpInfo->Type == 2)
	{
		return this->GetBoxPosition(map,(lpInfo->X-3),(lpInfo->Y-3),(lpInfo->X+3),(lpInfo->Y+3),ox,oy);
	}

	return 0;
}

bool CMonsterSetBase::GetBoxPosition(int map,int x,int y,int tx,int ty,short* ox,short* oy) // OK
{
	for(int n=0;n < 100;n++)
	{
		int subx = tx-x;
		int suby = ty-y;

		subx = ((subx<1)?1:subx);
		suby = ((suby<1)?1:suby);

		subx = x+(GetLargeRand()%subx);
		suby = y+(GetLargeRand()%suby);

		if(gMap[map].CheckAttr(subx,suby,1) == 0 && gMap[map].CheckAttr(subx,suby,4) == 0 && gMap[map].CheckAttr(subx,suby,8) == 0)
		{
			(*ox) = subx;
			(*oy) = suby;
			return 1;
		}
	}

	return 0;
}

void CMonsterSetBase::SetBoxPosition(int index,int map,int x,int y,int tx,int ty) // OK
{
	if(index < 0 || index >= MAX_MSB_MONSTER)
	{
		return;
	}

	MONSTER_SET_BASE_INFO* lpInfo = &this->m_MonsterSetBaseInfo[map][index];

	lpInfo->Map = map;
	lpInfo->X = x;
	lpInfo->Y = y;
	lpInfo->TX = tx;
	lpInfo->TY = ty;
}
