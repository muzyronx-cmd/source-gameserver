// ItemValue.h: interface for the CItemValue class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "Item.h"

struct ITEM_VALUE_INFO
{
	int Index;
	int Level;
	int Grade;
	int BuyValue;
#if (GAMESERVER_UPDATE>=603)
	int Coin1;
	int Coin2;
	int Coin3;
	int SellValue;
	int SellCoin1;
	int SellCoin2;
	int SellCoin3;
#endif
};

class CItemValue
{
public:
	CItemValue();
	virtual ~CItemValue();
	void Load(char* path);
	bool GetItemValue(CItem* lpItem,int* value);
	#if (GAMESERVER_UPDATE>=603)
	bool GetItemValueComplete(CItem* lpItem, int* value, int* coin1, int* coin2, int* coin3, int* sell, int* sellcoin1, int* sellcoin2, int* sellcoin3);
	#endif
private:
	std::vector<ITEM_VALUE_INFO> m_ItemValueInfo;
};

extern CItemValue gItemValue;
