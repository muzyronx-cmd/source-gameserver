// Move.h: interface for the CMove class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "Protocol.h"
#include "User.h"

#define MAX_MOVE 100

//**********************************************//
//************ Client -> GameServer ************//
//**********************************************//

struct PMSG_TELEPORT_RECV
{
	PBMSG_HEAD header; // C1:1C
	#if(GAMESERVER_UPDATE>=301)
	WORD gate;
	#else
	BYTE gate;
	#endif
	BYTE x;
	BYTE y;
};

struct PMSG_TELEPORT_MOVE_RECV
{
	PBMSG_HEAD header; // C1:8E
#if(GAMESERVER_UPDATE>=1200)
	DWORD reserved;
	WORD number;
	BYTE type;
#else
	BYTE type;
	DWORD reserved;
	WORD number;
#endif
};

//**********************************************//
//************ GameServer -> Client ************//
//**********************************************//

struct PMSG_TELEPORT_SEND
{
	PBMSG_HEAD header; // C3:1C
#if(GAMESERVER_UPDATE>=1200)
	BYTE unk;
#endif
#if(GAMESERVER_UPDATE>=400)
	WORD gate;
#else
	BYTE gate;
#endif
	BYTE map;
#if(GAMESERVER_UPDATE>=1200)
	BYTE unk2;
#endif
	BYTE x;
	BYTE y;
	BYTE dir;
};

struct PMSG_TELEPORT_RESULT_SEND
{
	PSBMSG_HEAD header;
	BYTE result;
};

//**********************************************//
//**********************************************//
//**********************************************//

struct MOVE_INFO
{
	int Index;
	char Name[32];
	int Money;
	int MinLevel;
	int MaxLevel;
	int MinReset;
	int MaxReset;
	int AccountLevel;
	int Gate;
};

class CMove
{
public:
	CMove();
	virtual ~CMove();
	void Load(char* path);
	bool GetInfo(int index,MOVE_INFO* lpInfo);
	bool GetInfoByName(char* name,MOVE_INFO* lpInfo);
	void Move(LPOBJ lpObj,int index);
	void CGTeleportRecv(PMSG_TELEPORT_RECV* lpMsg,int aIndex);
	void CGTeleportMoveRecv(PMSG_TELEPORT_MOVE_RECV* lpMsg,int aIndex);
	void GCTeleportSend(int aIndex,int gate,BYTE map,BYTE x,BYTE y,BYTE dir);
	void GCMoveResultSend(int aIndex, BYTE result);
private:
	std::map<int,MOVE_INFO> m_MoveInfo;
};

extern CMove gMove;
