#include "stdafx.h"
#include "ItemAttribute.h"
#include "MemScript.h"
#include "Util.h"
#include "ItemManager.h"

CItemAttribute gItemAttribute;

CItemAttribute::CItemAttribute()
{
	this->m_ItemAttribute.clear();
}

CItemAttribute::~CItemAttribute()
{
}

void CItemAttribute::Load(char * path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_ItemAttribute.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			ITEM_VALUES_INFO info;

			int section = lpMemScript->GetNumber();
			int index = lpMemScript->GetAsNumber();

			info.Index = GET_ITEM(section, index);

			info.SucessAttack = lpMemScript->GetAsNumber();

			info.Defense = lpMemScript->GetAsNumber();

			info.SucessDefense = lpMemScript->GetAsNumber();

			info.AddLife = lpMemScript->GetAsNumber();

			info.Reflet = lpMemScript->GetAsNumber();

			info.DamageMin = lpMemScript->GetAsNumber();

			info.DamageMax = lpMemScript->GetAsNumber();

			info.ExcDamage = lpMemScript->GetAsNumber();

			info.CriticalDamage = lpMemScript->GetAsNumber();

			this->m_ItemAttribute.insert(std::pair<int, ITEM_VALUES_INFO>(info.Index, info));
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void CItemAttribute::SetValues(LPOBJ lpObj, int index)
{
	try
	{
		std::map<int, ITEM_VALUES_INFO>::iterator it = this->m_ItemAttribute.find(index);

		if (it == this->m_ItemAttribute.end())
		{
			return;
		}

		if (it->second.SucessAttack > 0)
		{
			lpObj->AttackSuccessRate += it->second.SucessAttack;
		}
		if (it->second.Defense > 0)
		{
			lpObj->Defense += it->second.Defense;
		}
		if (it->second.SucessDefense > 0)
		{
			lpObj->DefenseSuccessRate += it->second.SucessDefense;
		}
		if (it->second.AddLife > 0)
		{
			lpObj->AddLife += it->second.AddLife;
		}
		if (it->second.Reflet > 0)
		{
			lpObj->DamageReflect += it->second.Reflet;
		}
		if (it->second.DamageMin > 0)
		{
			lpObj->PhysiDamageMin += it->second.DamageMin;
			lpObj->PhysiDamageMinRight += it->second.DamageMin;
			lpObj->PhysiDamageMinLeft += it->second.DamageMin;
		}
		if (it->second.DamageMax > 0)
		{
			lpObj->PhysiDamageMax += it->second.DamageMax;
			lpObj->PhysiDamageMaxRight += it->second.DamageMax;
			lpObj->PhysiDamageMaxLeft += it->second.DamageMax;
		}
		if (it->second.CriticalDamage > 0)
		{
			lpObj->CriticalDamageRate += it->second.CriticalDamage;
		}
		if (it->second.ExcDamage > 0)
		{
			lpObj->ExcellentDamageRate += it->second.ExcDamage;
		}
	}
	catch (...)
	{
		LogAdd(LOG_RED, "[ItemAttribute::SetValues] Error");
	}
}
