#pragma once

char* signMessage(std::string privateKey, unsigned char* data, size_t length);
bool verifySignature(std::string publicKey, const char* data, unsigned int length, char* signatureBase64);