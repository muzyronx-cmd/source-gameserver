#include "stdafx.h"
#include "Crypt.h"
#include <openssl/evp.h>

output cleanup(output o)
{
	if (o.data) free(o.data);
	o.data = NULL;
	o.length = 0;
	return o;
}

bool concat(output* o, unsigned char* data, unsigned int length)
{
	if (o->data == NULL)
		o->data = (unsigned char*)malloc(length);
	else
	{
		unsigned char* ptr = (unsigned char*)realloc(o->data, o->length + length);
		if (ptr == NULL)
			return false;
		o->data = ptr;
	}

	memcpy_s(o->data + o->length, length, data, length);
	o->length = o->length + length;

	return true;
}

output enc_dec(input* input)
{
	output out;
	out.data = NULL;
	out.length = 0;

	const EVP_CIPHER* cipher_type = EVP_aes_256_cbc();
	const int cipher_block_size = EVP_CIPHER_block_size(cipher_type);

	EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
	if (ctx == NULL)
		return cleanup(out);

	/* Don't set key or IV right away; we want to check lengths */
	if (!EVP_CipherInit_ex(ctx, cipher_type, NULL, NULL, NULL, input->encrypt))
		return cleanup(out);

	OPENSSL_assert(EVP_CIPHER_CTX_key_length(ctx) == AES_256_KEY_SIZE);
	OPENSSL_assert(EVP_CIPHER_CTX_iv_length(ctx) == AES_BLOCK_SIZE);

	/* Now we can set key and IV */
	if (!EVP_CipherInit_ex(ctx, NULL, NULL, input->key, input->iv, input->encrypt))
	{
		EVP_CIPHER_CTX_cleanup(ctx);
		return cleanup(out);
	}

	unsigned char* in_buf = new unsigned char[BUFSIZE];
	unsigned char* out_buf = new unsigned char[BUFSIZE + cipher_block_size];

	unsigned int bytes_read = 0;
	int out_len;

	while (1)
	{
		unsigned int bytes_to_read = input->length - bytes_read;
		if (bytes_to_read <= 0)
			break;

		if (bytes_to_read > BUFSIZE)
			bytes_to_read = BUFSIZE;

		memcpy_s(in_buf, BUFSIZE, input->data + bytes_read, bytes_to_read);
		bytes_read += bytes_to_read;

		if (!EVP_CipherUpdate(ctx, out_buf, &out_len, in_buf, bytes_to_read))
		{
			EVP_CIPHER_CTX_cleanup(ctx);
			delete[] in_buf;
			delete[] out_buf;
			return cleanup(out);
		}

		if (!concat(&out, out_buf, out_len))
		{
			EVP_CIPHER_CTX_cleanup(ctx);
			delete[] in_buf;
			delete[] out_buf;
			return cleanup(out);
		}
	}

	// Now cipher the final block and write it out to file
	if (!EVP_CipherFinal_ex(ctx, out_buf, &out_len))
	{
		EVP_CIPHER_CTX_cleanup(ctx);
		delete[] in_buf;
		delete[] out_buf;
		return cleanup(out);
	}

	if (!concat(&out, out_buf, out_len))
	{
		EVP_CIPHER_CTX_cleanup(ctx);
		delete[] in_buf;
		delete[] out_buf;
		return cleanup(out);
	}

	EVP_CIPHER_CTX_cleanup(ctx);
	delete[] in_buf;
	delete[] out_buf;

	return out;
}