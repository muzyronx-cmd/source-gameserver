#include "stdafx.h"
#include "PKZone.h"
#include "MemScript.h"
#include "Util.h"

CPKZone gPKZone;

CPKZone::CPKZone()
{
}

CPKZone::~CPKZone()
{
}

void CPKZone::Load(char* path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_PkZoneInfo.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			PK_ZONE_INFO info;

			info.map = lpMemScript->GetNumber();

			info.startX = lpMemScript->GetAsNumber();

			info.startY = lpMemScript->GetAsNumber();

			info.endX = lpMemScript->GetAsNumber();

			info.endY = lpMemScript->GetAsNumber();

			info.type = lpMemScript->GetAsNumber();

			this->m_PkZoneInfo.push_back(info);
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

bool CPKZone::CheckAttackZone(LPOBJ lpObj, LPOBJ lpTarget)
{
	for (auto& zone : this->m_PkZoneInfo) {
		if (lpObj->Map != zone.map) {
			continue;
		}

		if (lpObj->X >= zone.startX && lpObj->Y >= zone.startY
			&& lpObj->X <= zone.endX && lpObj->Y <= zone.endY
			&& lpTarget->X >= zone.startX && lpTarget->Y >= zone.startY
			&& lpTarget->X <= zone.endX && lpTarget->Y <= zone.endY) {
			if (zone.type == 1) {
				return false;
			}
		}
	}

	return true;
}

bool CPKZone::CheckZoneMurderLevel(LPOBJ lpObj, LPOBJ lpTarget)
{
	for (auto& zone : this->m_PkZoneInfo) {
		if (lpObj->Map != zone.map) {
			continue;
		}

		if (lpObj->X >= zone.startX && lpObj->Y >= zone.startY
			&& lpObj->X <= zone.endX && lpObj->Y <= zone.endY
			&& lpTarget->X >= zone.startX && lpTarget->Y >= zone.startY
			&& lpTarget->X <= zone.endX && lpTarget->Y <= zone.endY) {
			if (zone.type == 2) {
				return false;
			}
		}
	}

	return true;
}

