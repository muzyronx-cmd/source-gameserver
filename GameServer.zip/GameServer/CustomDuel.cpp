// Duel.cpp: implementation of the CCustomDuel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CustomDuel.h"
#include "CastleSiege.h"
#include "DarkSpirit.h"
#include "DSProtocol.h"
#include "Duel.h"
#include "EffectManager.h"
#include "Guild.h"
#include "MapServerManager.h"
#include "User.h"
#include "Util.h"
#include "GameMain.h"
#include "ChaosCastle.h"
#include "DevilSquare.h"
#include "BloodCastle.h"
#include "Notice.h"
#include "ItemManager.h"
#include "Log.h"
#include "Trade.h"
#include "ServerInfo.h"
#include "ObjectManager.h"

CCustomDuel gCustomDuel;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomDuel::CCustomDuel()
{

}

CCustomDuel::~CCustomDuel()
{

}

bool CCustomDuel::CheckDuel(LPOBJ lpObj, LPOBJ lpTarget)
{
	if (lpObj->Type != OBJECT_USER || lpTarget->Type != OBJECT_USER)
	{
		return 0;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUser) == 0 || OBJECT_RANGE(lpTarget->CustomDuelUser) == 0)
	{
		return 0;
	}

	if (lpObj->CustomDuelUser == lpTarget->Index && lpTarget->CustomDuelUser == lpObj->Index)
	{
		return 1;
	}

	return 0;
}

bool CCustomDuel::CheckDuelUser(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (lpObj->Type != OBJECT_USER)
	{
		return 0;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUser) == 0)
	{
		return 0;
	}

	return 1;
}

void CCustomDuel::CheckDuelScore(LPOBJ lpObj, LPOBJ lpTarget)
{
	if (this->CheckDuel(lpObj, lpTarget) == 0)
	{
		return;
	}

	lpTarget->KillerType = 3;

	if (lpObj->DuelScore >= 5)
	{
		lpTarget->KillerType = 0;

		this->DuelSendItemWinner(lpObj->Index);

		this->DuelFinish(lpObj, true);

		this->ResetDuel(lpObj);

		this->GCDuelEndSend(lpObj->Index, 0);

		this->ResetDuel(lpTarget);

		this->GCDuelEndSend(lpTarget->Index, 0);
	}
}

void CCustomDuel::CheckCustomDuelUser()
{
	for (int n = OBJECT_START_USER; n < MAX_OBJECT; n++)
	{
		if (gObjIsConnected(n) == 0)
		{
			continue;
		}

		LPOBJ lpObj = &gObj[n];

		if (OBJECT_RANGE(lpObj->CustomDuelUserReserved) != 0)
		{
			if ((GetTickCount() - lpObj->CustomDuelTickCount) > 20000)
			{
				this->ResetDuel(&gObj[lpObj->CustomDuelUserReserved]);
				this->GCDuelStartSend(lpObj->Index, 0, lpObj->CustomDuelUserReserved);
				this->ResetDuel(lpObj);
			}
		}

		if (OBJECT_RANGE(lpObj->CustomDuelUserRequested) != 0)
		{
			if ((GetTickCount() - lpObj->CustomDuelTickCount) > 20000)
			{
				this->ResetDuel(&gObj[lpObj->CustomDuelUserRequested]);
				this->GCDuelStartSend(lpObj->CustomDuelUserRequested, 0, lpObj->Index);
				this->ResetDuel(lpObj);
			}
		}

		if (OBJECT_RANGE(lpObj->CustomDuelUser) != 0)
		{
			if (lpObj->Map != 6 && lpObj->Interface.use == 0 && lpObj->Interface.type != INTERFACE_TRADE && lpObj->Interface.state != 0)
			{
				if (lpObj->DuelScore != gObj[lpObj->CustomDuelUser].DuelScore)
				{
					if (lpObj->DuelScore > gObj[lpObj->CustomDuelUser].DuelScore)
					{
						this->DuelSendItemWinner(lpObj->Index);
					}
					else if (gObj[lpObj->CustomDuelUser].DuelScore > lpObj->DuelScore)
					{
						this->DuelSendItemWinner(lpObj->CustomDuelUser);
					}
				}

				gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, "Voc� saiu do mapa onde � realizado o duelo por isso perdeu o mesmo.");
				gNotice.GCNoticeSend(lpObj->CustomDuelUser, 0, 0, 0, 0, 0, 0, "Voc� venceu o duelo porque o advers�rio saiu do mapa.");

				this->DuelFinish(lpObj, false);

				this->ResetDuel(&gObj[lpObj->CustomDuelUser]);
				this->GCDuelEndSend(lpObj->CustomDuelUser, 0);
				this->ResetDuel(lpObj);
				this->GCDuelEndSend(lpObj->Index, 0);
				continue;
			}

			if (lpObj->Guild != 0)
			{
				if (lpObj->Guild->WarState != 0)
				{
					gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, "Voc� entrou em war por este motivo o duelo ser� cancelado.");
					gNotice.GCNoticeSend(lpObj->CustomDuelUser, 0, 0, 0, 0, 0, 0, "O seu advers�rio entrou em war por este motivo o duelo ser� cancelado.");

					this->DuelFinish(lpObj, false);

					this->ResetDuel(&gObj[lpObj->CustomDuelUser]);
					this->GCDuelEndSend(lpObj->CustomDuelUser, 0);
					this->ResetDuel(lpObj);
					this->GCDuelEndSend(lpObj->Index, 0);
					continue;
				}
			}

			if ((GetTickCount() - lpObj->CustomDuelTickCount) > (60000 * 3))
			{
				if (lpObj->DuelScore != gObj[lpObj->CustomDuelUser].DuelScore)
				{
					if (lpObj->DuelScore > gObj[lpObj->CustomDuelUser].DuelScore)
					{
						this->DuelSendItemWinner(lpObj->Index);
					}
					else if (gObj[lpObj->CustomDuelUser].DuelScore > lpObj->DuelScore)
					{
						this->DuelSendItemWinner(lpObj->CustomDuelUser);
					}
				}

				this->DuelFinish(lpObj, false);

				this->ResetDuel(&gObj[lpObj->CustomDuelUser]);
				this->GCDuelEndSend(lpObj->CustomDuelUser, 0);
				this->ResetDuel(lpObj);
				this->GCDuelEndSend(lpObj->Index, 0);
			}
		}
	}
}

void CCustomDuel::ResetDuel(LPOBJ lpObj)
{
	gDarkSpirit[lpObj->Index].ResetTarget(lpObj->CustomDuelUser);

	lpObj->CustomDuelUserReserved = -1;
	lpObj->CustomDuelUserRequested = -1;
	lpObj->DuelScore = 0;
	lpObj->CustomDuelUser = -1;
	lpObj->CustomDuelTickCount = 0;

	lpObj->Dueling = 0;

	memset(lpObj->Dueling_bets, 0xFF, 32);
	memset(lpObj->Dueling_inventory, 0xFF, 64);
}

void CCustomDuel::RespawnDuelUser(LPOBJ lpObj)
{
	lpObj->Map = 6;
	lpObj->X = 11;
	lpObj->Y = 244;

	gMap[lpObj->Map].GetMapRandomPos(&lpObj->X, &lpObj->Y, 2);
}

void CCustomDuel::UserDieProc(LPOBJ lpObj, LPOBJ lpTarget)
{
	if (this->CheckDuel(lpObj, lpTarget) == 0)
	{
		return;
	}

	lpTarget->DuelScore++;

	this->GCDuelScoreSend(lpObj->Index, lpTarget->Index);
}

void CCustomDuel::CGDuelStartRecv(PMSG_DUEL_START_RECV* lpMsg, int aIndex)
{
	if (gServerInfo.m_DuelSwitch != 1)
	{
		return;
	}

	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return;
	}

	int bIndex = MAKE_NUMBERW(lpMsg->index[0], lpMsg->index[1]);

	if (gObjIsConnectedGP(bIndex) == 0 || aIndex == bIndex)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador alvo n�o est� online");
		return;
	}

	LPOBJ lpTarget = &gObj[bIndex];

	if (lpObj->Interface.use != 0 || lpObj->State == OBJECT_DELCMD || lpObj->DieRegen != 0 || lpObj->Teleport != 0 || lpObj->SkillSummonPartyTime != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� n�o pode duelar neste momento");
		return;
	}

	if ((lpTarget->Option & 2) == 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador alvo recusou sua aplica��o duel automaticamente");
		return;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUserReserved) != 0 || OBJECT_RANGE(lpObj->CustomDuelUserRequested) != 0 || OBJECT_RANGE(lpObj->CustomDuelUser) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� j� perguntou ou foi convidado a duelar");
		return;
	}

	if (OBJECT_RANGE(lpTarget->CustomDuelUserReserved) != 0 || OBJECT_RANGE(lpTarget->CustomDuelUserRequested) != 0 || OBJECT_RANGE(lpTarget->CustomDuelUser) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador alvo j� perguntou ou foi convidado a duelar");
		return;
	}

	if (lpTarget->PShopOpen != 0 || lpObj->PShopOpen != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Feche a loja.");
		return;
	}

	if (lpObj->Map != lpTarget->Map) {
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� precisa estar no mesmo mapa que o jogador alvo.");
		return;
	}

	if ((lpObj->X < lpTarget->X - 2) || (lpObj->X > lpTarget->X + 2) ||
		(lpObj->Y < lpTarget->Y - 2) || (lpObj->Y > lpTarget->Y + 2))
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O char informado n�o est� proximo de voc�");
		return;
	}

	if (lpObj->Guild != 0 && lpObj->Guild->WarState == 1)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� n�o pode duelar em Guild War");
		return;
	}

	if (lpTarget->Guild != 0 && lpTarget->Guild->WarState == 1)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador alvo n�o pode duelar em Guild War");
		return;
	}

	if (DS_MAP_RANGE(lpObj->Map) != 0 || BC_MAP_RANGE(lpObj->Map) != 0 || CC_MAP_RANGE(lpObj->Map) != 0 ||
		IT_MAP_RANGE(lpObj->Map) != 0 || DG_MAP_RANGE(lpObj->Map) != 0 || IG_MAP_RANGE(lpObj->Map) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� n�o pode duelar neste mapa");
		return;
	}

#if(GAMESERVER_TYPE==1)

	if (gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_NOTIFY || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_READYSIEGE || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_STARTSIEGE)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� n�o pode duelar durante Castle Siege");
		return;
	}

#endif

	char name[11] = { 0 };

	memcpy(name, lpMsg->name, sizeof(lpMsg->name));

	if (strcmp(lpTarget->Name, name) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O nome do jogador alvo � inv�lido");
		return;
	}

	for (int n = 0; n < MAX_SELF_DEFENSE; n++)
	{
		if (lpObj->SelfDefense[n] >= 0)
		{
			gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� n�o pode duelar com Self Defense");
			return;
		}

		if (lpTarget->SelfDefense[n] >= 0)
		{
			gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador n�o pode segmentar duelo Self Defense");
			return;
		}
	}

	gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Pedido de duelo enviado!");

	lpObj->CustomDuelUserReserved = bIndex;
	lpObj->CustomDuelUserRequested = -1;
	lpObj->DuelScore = 0;
	lpObj->CustomDuelUser = -1;
	lpObj->CustomDuelTickCount = GetTickCount();

	lpTarget->CustomDuelUserReserved = -1;
	lpTarget->CustomDuelUserRequested = aIndex;
	lpTarget->DuelScore = 0;
	lpTarget->CustomDuelUser = -1;
	lpTarget->CustomDuelTickCount = GetTickCount();

	this->GCDuelOkSend(bIndex, aIndex);
}

void CCustomDuel::CGDuelOkRecv(PMSG_DUEL_OK_RECV* lpMsg, int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return;
	}

	int bIndex = MAKE_NUMBERW(lpMsg->index[0], lpMsg->index[1]);

	if (gObjIsConnectedGP(bIndex) == 0)
	{
		return;
	}

	LPOBJ lpTarget = &gObj[bIndex];

	if (lpMsg->flag == 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador alvo recusou o duelo de seu pedido");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if (lpObj->Interface.use != 0 || lpObj->State == OBJECT_DELCMD || lpObj->DieRegen != 0 || lpObj->Teleport != 0 || lpObj->SkillSummonPartyTime != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador est� ocupado ou em trade.");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if (lpTarget->PShopOpen != 0 || lpObj->PShopOpen != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador est� com a Loja aberta.");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUserReserved) != 0 || OBJECT_RANGE(lpObj->CustomDuelUser) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� j� perguntou ou foi convidado a duelar");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if (OBJECT_RANGE(lpTarget->CustomDuelUserRequested) != 0 || OBJECT_RANGE(lpTarget->CustomDuelUser) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador alvo j� perguntou ou foi convidado a duelar");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if (lpTarget->CustomDuelUserReserved != aIndex)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O jogador alvo j� perguntou ou foi convidado a duelar");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if (lpObj->Map != lpTarget->Map) {
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� precisa estar no mesmo mapa que o jogador alvo.");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if ((lpObj->X < lpTarget->X - 2) || (lpObj->X > lpTarget->X + 2) ||
		(lpObj->Y < lpTarget->Y - 2) || (lpObj->Y > lpTarget->Y + 2))
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O char informado n�o est� proximo de voc�");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	if (DS_MAP_RANGE(lpObj->Map) != 0 || BC_MAP_RANGE(lpObj->Map) != 0 || CC_MAP_RANGE(lpObj->Map) != 0 ||
		IT_MAP_RANGE(lpObj->Map) != 0 || DG_MAP_RANGE(lpObj->Map) != 0 || IG_MAP_RANGE(lpObj->Map) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� n�o pode duelar neste mapa");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

#if(GAMESERVER_TYPE==1)

	if (gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_NOTIFY || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_READYSIEGE || gCastleSiege.GetCastleState() == CASTLESIEGE_STATE_STARTSIEGE)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Voc� n�o pode duelar durante Castle Siege");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

#endif

	char name[11] = { 0 };

	memcpy(name, lpMsg->name, 10);

	if (strcmp(lpTarget->Name, name) != 0)
	{
		gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "O nome do jogador alvo � inv�lido");
		this->ResetDuel(lpObj);
		this->ResetDuel(lpTarget);
		this->GCDuelStartSend(bIndex, 0, aIndex);
		return;
	}

	lpObj->CustomDuelUserReserved = -1;
	lpObj->CustomDuelUserRequested = -1;
	lpObj->DuelScore = 0;
	lpObj->CustomDuelUser = bIndex;
	lpObj->CustomDuelTickCount = GetTickCount();

	lpTarget->CustomDuelUserReserved = -1;
	lpTarget->CustomDuelUserRequested = -1;
	lpTarget->DuelScore = 0;
	lpTarget->CustomDuelUser = aIndex;
	lpTarget->CustomDuelTickCount = GetTickCount();

	//Enviar Trade
	//Variaveis que fingem o trade (dwIndex)
	lpObj->Interface.use = 1;
	lpObj->Interface.state = 0;
	lpObj->Interface.type = INTERFACE_TRADE;
	lpObj->TargetNumber = bIndex;
	lpObj->InterfaceTime = GetTickCount();
	//Variaveis que fingem o trade (wdIndex)
	lpTarget->Interface.use = 1;
	lpTarget->Interface.state = 0;
	lpTarget->Interface.type = INTERFACE_TRADE;
	lpTarget->TargetNumber = aIndex;
	lpTarget->InterfaceTime = GetTickCount();

	this->GCSendDuelTrade(aIndex, bIndex);

	//Copia invent�rio ao abrir o trade
	memcpy(lpObj->Dueling_inventory, lpObj->InventoryMap, 64);
	memcpy(lpTarget->Dueling_inventory, lpTarget->InventoryMap, 64);
}

void CCustomDuel::CGDuelEndRecv(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUserReserved) != 0)
	{
		this->ResetDuel(&gObj[lpObj->CustomDuelUserReserved]);
		this->GCDuelStartSend(aIndex, 0, lpObj->CustomDuelUserReserved);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUserRequested) != 0)
	{
		this->ResetDuel(&gObj[lpObj->CustomDuelUserRequested]);
		this->GCDuelStartSend(lpObj->CustomDuelUserRequested, 0, aIndex);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUser) != 0)
	{
		this->ResetDuel(&gObj[lpObj->CustomDuelUser]);
		this->GCDuelEndSend(lpObj->CustomDuelUser, 0);
		this->ResetDuel(lpObj);
		this->GCDuelEndSend(aIndex, 0);
		return;
	}
}

void CCustomDuel::CGDuelEnd(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (OBJECT_RANGE(lpObj->CustomDuelUserReserved) != 0)
	{
		this->ResetDuel(&gObj[lpObj->CustomDuelUserReserved]);
		this->GCDuelStartSend(aIndex, 0, lpObj->CustomDuelUserReserved);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUserRequested) != 0)
	{
		this->ResetDuel(&gObj[lpObj->CustomDuelUserRequested]);
		this->GCDuelStartSend(lpObj->CustomDuelUserRequested, 0, aIndex);
		this->ResetDuel(lpObj);
		return;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUser) != 0)
	{
		this->ResetDuel(&gObj[lpObj->CustomDuelUser]);
		this->GCDuelEndSend(lpObj->CustomDuelUser, 0);
		this->ResetDuel(lpObj);
		this->GCDuelEndSend(aIndex, 0);
		return;
	}
}

bool CCustomDuel::GCDuelTradeOkButton(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	if (gObjIsConnectedGP(aIndex) == 0)
	{
		return 0;
	}

	if (OBJECT_RANGE(lpObj->CustomDuelUser) != 0)
	{
		lpObj->CustomDuelTickCount = GetTickCount();

		if (OBJECT_RANGE(lpObj->TargetNumber) != 0)
		{
			if (lpObj->CustomDuelUser != lpObj->TargetNumber)
			{
				this->GCDuelTradeCancel(lpObj);
				return 1;
			}

			LPOBJ lpTarget = &gObj[lpObj->CustomDuelUser];

			if (gObjIsConnectedGP(lpObj->CustomDuelUser) == 0)
			{
				this->GCDuelTradeCancel(lpObj);
				return 1;
			}

			if (lpObj->Map != lpTarget->Map)
			{
				this->GCDuelTradeCancel(lpObj);
				return 1;
			}

			if (lpObj->TradeOk == 1 && lpTarget->TradeOk == 1)
			{
				if (this->CheckDuelUserSpace(lpObj) == 0)
				{
					gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Os itens apostados n�o cabem em seu invent�rio");
					gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "Tente organizar seu invent�rio antes de declarar o duelo");
					gNotice.GCNoticeSend(lpTarget->Index, 1, 0, 0, 0, 0, 0, "As suas apostas n�o cabem no invent�rio do seu oponente");
					this->GCDuelTradeCancel(lpObj);
					return 1;
				}

				if (this->CheckDuelUserSpace(lpTarget) == 0)
				{
					gNotice.GCNoticeSend(lpTarget->Index, 1, 0, 0, 0, 0, 0, "Os itens apostados n�o cabem em seu invent�rio");
					gNotice.GCNoticeSend(lpTarget->Index, 1, 0, 0, 0, 0, 0, "Tente organizar seu invent�rio antes de declarar o duelo");
					gNotice.GCNoticeSend(aIndex, 1, 0, 0, 0, 0, 0, "As suas apostas n�o cabem no invent�rio do seu oponente");
					this->GCDuelTradeCancel(lpObj);
					return 1;
				}

				for (int n = 0; n < 32; n++)
				{
					//Copia o item
					lpObj->Dueling_bets[n] = lpObj->Trade[n];
				}

				for (int n = 0; n < 32; n++)
				{
					//Copia o item
					lpTarget->Dueling_bets[n] = lpTarget->Trade[n];
				}

				lpObj->Dueling = 1;
				lpTarget->Dueling = 1;

				gTrade.ResetTrade(aIndex);
				gTrade.ResetTrade(lpTarget->Index);

				//Mover Arena
				ForceMoveDuel(aIndex, 6, 11, 243);

				ForceMoveDuel(lpTarget->Index, 6, 11, 245);

				this->GCDuelStartSend(aIndex, 1, lpTarget->Index);

				this->GCDuelStartSend(lpTarget->Index, 1, aIndex);

				this->GCDuelScoreSend(aIndex, lpTarget->Index);

				lpObj->CustomDuelTickCount = GetTickCount();
				lpTarget->CustomDuelTickCount = GetTickCount();
				return 1;
			}
		}
	}

	return 0;
}

void CCustomDuel::GCDuelTradeCancel(LPOBJ lpObj)
{
	if (lpObj->Live == 1)
	{
		gTrade.ResetTrade(lpObj->Index);
		gTrade.GCTradeResultSend(lpObj->Index, 0);
		gTrade.ResetTrade(lpObj->CustomDuelUser);
		gTrade.GCTradeResultSend(lpObj->CustomDuelUser, 0);
		this->CGDuelEndRecv(lpObj->Index);
	}
}

bool CCustomDuel::CheckDuelUserSpace(LPOBJ lpObj)
{
	LPOBJ lpTarget = &gObj[lpObj->TargetNumber];

	if (gObjIsConnectedGP(lpTarget->Index) == 0)
	{
		return 0;
	}

	BYTE TemInventoryMap[64];

	memcpy(TemInventoryMap, lpObj->Dueling_inventory, 64);

	for (int n = 0; n < 32; n++)
	{
		if (lpTarget->Trade[n].IsItem() != 0)
		{
			if (gItemManager.InventoryInsertItemTemp(lpObj, lpTarget->Trade[n], (BYTE*)&TemInventoryMap) == 0xFF)
			{
				return 0;
			}
		}
	}

	return 1;
}

void CCustomDuel::DuelFinish(LPOBJ lpObj, bool finished)
{
	//Moves
	short X = 137 + rand() % 7;
	short Y = 127 + rand() % 7;

	ForceMoveDuel(lpObj->Index, 0, X, Y);

	short X2 = 137 + rand() % 7;
	short Y2 = 127 + rand() % 7;

	ForceMoveDuel(lpObj->CustomDuelUser, 0, X2, Y2);

	if (finished) {
		gNotice.GCNoticeSend(lpObj->Index, 0, 0, 0, 0, 0, 0, "Voc� venceu o duelo, parab�ns!");
		gNotice.GCNoticeSend(lpObj->CustomDuelUser, 0, 0, 0, 0, 0, 0, "Que pena! Voc� perdeu o duelo.");

		GCFireworksSend(lpObj, X, Y);
	}
	else
	{
		gNotice.GCNoticeSend(lpObj->Index, 1, 0, 0, 0, 0, 0, "O duelo foi cancelado por causa de seu longo duramento");
		gNotice.GCNoticeSend(lpObj->CustomDuelUser, 1, 0, 0, 0, 0, 0, "O duelo foi cancelado por causa de seu longo duramento");
	}
}

void CCustomDuel::DuelSendItemWinner(int aIndex)
{
	LPOBJ lpObj = &gObj[aIndex];

	//Se ainda estou online
	if (lpObj->Connected < 3) { return; }

	LPOBJ lpTarget = &gObj[lpObj->CustomDuelUser];

	//Se quem estou dando trade est� conectado ainda
	if (lpTarget->Connected < 3) { return; }

	for (int n = 0; n < 32; n++)
	{
		//Se tiver um item
		if (lpTarget->Dueling_bets[n].IsItem() == 1)
		{
			if (gItemManager.InventoryInsertItem(lpObj->Index, lpTarget->Dueling_bets[n]) != 0xFF)
			{
				//Item inserido, ent�o deletar do invent�rio do outro que perdeu o duelo
				for (int a = 0; a < 76; a++)
				{
					if (lpTarget->Inventory[a].IsItem() == 1) {
						//Faz por serial (simple way)
						if (lpTarget->Inventory[a].m_Serial > 0) {
							if (lpTarget->Dueling_bets[n].m_Serial == lpTarget->Inventory[a].m_Serial) {
								//Item encontrado e sendo deletado 
								gItemManager.InventoryDelItem(lpTarget->Index, a);
							}
						}
						else {
							if (lpTarget->Dueling_bets[n].m_Index == lpTarget->Inventory[a].m_Index) {
								if (lpTarget->Dueling_bets[n].m_Option1 == lpTarget->Inventory[a].m_Option1) {
									if (lpTarget->Dueling_bets[n].m_NewOption == lpTarget->Inventory[a].m_NewOption) {
										//Item encontrado e sendo deletado
										gItemManager.InventoryDelItem(lpTarget->Index, a);
									}
								}
							}
						}
					}
				}
			}
			else {
				LogAdd(LOG_RED, "[DUEL-INSERTITEM / NO SPACE] [%s][%s]", lpObj->Account, lpObj->Name);
			}
		}
	}

	gObjectManager.CharacterMakePreviewCharSet(lpTarget->Index);
	gItemManager.GCItemListSend(lpTarget->Index, 1);
	gTrade.GCTradeResultSend(lpTarget->Index, 1);

	gObjectManager.CharacterMakePreviewCharSet(lpObj->Index);
	gItemManager.GCItemListSend(lpObj->Index, 1);
	gTrade.GCTradeResultSend(lpObj->Index, 1);
}

void CCustomDuel::GCDuelStartSend(int aIndex, BYTE result, int bIndex)
{
#if(GAMESERVER_UPDATE>=402)

	PMSG_DUEL_START_SEND pMsg;

	pMsg.header.set(0xAA, 0x01, sizeof(pMsg));

	pMsg.result = ((result == 0) ? 0x0F : 0);

	pMsg.index[0] = SET_NUMBERHB(bIndex);
	pMsg.index[1] = SET_NUMBERLB(bIndex);

	memcpy(pMsg.name, gObj[bIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);

#else
	PMSG_DUEL_START_SEND pMsg;

	pMsg.header.set(0xAA, sizeof(pMsg));

	pMsg.result = result;

	pMsg.index[0] = SET_NUMBERHB(bIndex);
	pMsg.index[1] = SET_NUMBERLB(bIndex);

	memcpy(pMsg.name, gObj[bIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
#endif
}

void CCustomDuel::GCDuelOkSend(int aIndex, int bIndex)
{
#if(GAMESERVER_UPDATE>=402)

	PMSG_DUEL_OK_SEND pMsg;

	pMsg.header.set(0xAA, 0x02, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(bIndex);
	pMsg.index[1] = SET_NUMBERLB(bIndex);

	memcpy(pMsg.name, gObj[bIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);

#else
	PMSG_DUEL_OK_SEND pMsg;

	pMsg.header.set(0xAC, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(bIndex);
	pMsg.index[1] = SET_NUMBERLB(bIndex);

	memcpy(pMsg.name, gObj[bIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
#endif
}

void CCustomDuel::GCDuelEndSend(int aIndex, BYTE result)
{
#if(GAMESERVER_UPDATE>=402)

	PMSG_DUEL_END_SEND pMsg;

	pMsg.header.set(0xAA, 0x03, sizeof(pMsg));

	pMsg.result = result;

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);

#else
	PMSG_DUEL_END_SEND pMsg;

	pMsg.header.set(0xAB, sizeof(pMsg));

	pMsg.index[0] = SET_NUMBERHB(aIndex);
	pMsg.index[1] = SET_NUMBERLB(aIndex);

	memcpy(pMsg.name, gObj[aIndex].Name, sizeof(pMsg.name));

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
#endif
}

void CCustomDuel::GCDuelScoreSend(int aIndex, int bIndex)
{
#if(GAMESERVER_UPDATE>=402)

	PMSG_DUEL_SCORE_SEND pMsg;

	pMsg.header.set(0xAA, 0x04, sizeof(pMsg));

	pMsg.index1[0] = SET_NUMBERHB(aIndex);
	pMsg.index1[1] = SET_NUMBERLB(aIndex);

	pMsg.index2[0] = SET_NUMBERHB(bIndex);
	pMsg.index2[1] = SET_NUMBERLB(bIndex);

	pMsg.score[0] = gObj[aIndex].DuelScore;
	pMsg.score[1] = gObj[bIndex].DuelScore;

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
	DataSend(bIndex, (BYTE*)&pMsg, pMsg.header.size);

#else
	PMSG_DUEL_SCORE_SEND pMsg;

	pMsg.header.set(0xAD, sizeof(pMsg));

	pMsg.index1[0] = SET_NUMBERHB(aIndex);
	pMsg.index1[1] = SET_NUMBERLB(aIndex);

	pMsg.index2[0] = SET_NUMBERHB(bIndex);
	pMsg.index2[1] = SET_NUMBERLB(bIndex);

	pMsg.score[0] = gObj[aIndex].DuelScore;
	pMsg.score[1] = gObj[bIndex].DuelScore;

	DataSend(aIndex, (BYTE*)&pMsg, pMsg.header.size);
	DataSend(bIndex, (BYTE*)&pMsg, pMsg.header.size);
#endif
}

void CCustomDuel::GCSendDuelTrade(int aIndex, int bIsndex)
{
	PMSG_TRADE_RESPONSE_RECV pMsg;

	pMsg.header.setE(0x37, sizeof(pMsg));

	pMsg.response = 1;

	memcpy(pMsg.name, gObj[aIndex].Name, 10);

	gTrade.CGTradeResponseRecv(&pMsg, aIndex);
}