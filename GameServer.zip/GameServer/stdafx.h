#pragma once

#define WIN32_LEAN_AND_MEAN

#define _WIN32_WINNT _WIN32_WINNT_WINXP
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#ifndef GAMESERVER_TYPE
#define GAMESERVER_TYPE 0
#endif

#ifndef GAMESERVER_EXTRA
#define GAMESERVER_EXTRA 1
#endif

#ifndef GAMESERVER_UPDATE
#define GAMESERVER_UPDATE 603
#endif

#ifndef GAMESERVER_LANGUAGE
#define GAMESERVER_LANGUAGE 1
#endif

#ifndef ENCRYPT_STATE
#define ENCRYPT_STATE 1
#endif

#ifndef OLD_LUA
#define OLD_LUA
#endif

//#define CUSTOM_GAMESERVER

#if(GAMESERVER_UPDATE>=1001)
#define GAMESERVER_VERSION "1.0.0.1"
#define GAMESERVER_RELEASE "Release 1"
#elif(GAMESERVER_UPDATE>=801)
#define GAMESERVER_VERSION "1.0.0.1"
#define GAMESERVER_RELEASE "Release 1"
#elif(GAMESERVER_UPDATE>=601)
#define GAMESERVER_VERSION "1.0.0.1"
#define GAMESERVER_RELEASE "Release 67"
#elif(GAMESERVER_UPDATE>=401)
#define GAMESERVER_VERSION "1.0.0.1"
#define GAMESERVER_RELEASE "Release 1"
#elif(GAMESERVER_UPDATE>=201)
#define GAMESERVER_VERSION "1.0.0.1"
#define GAMESERVER_RELEASE "Release 101"
#elif(GAMESERVER_UPDATE>=101)
#define GAMESERVER_VERSION "1.0.1.3"
#define GAMESERVER_RELEASE "Release 103"
#elif(GAMESERVER_UPDATE>=99)
#define GAMESERVER_VERSION "1.0.0.1"
#define GAMESERVER_RELEASE "Release 1"
#else
#define GAMESERVER_VERSION "1.0.0.1"
#define GAMESERVER_RELEASE "Release 1"
#endif

#define ENCSTR(x) (char*)(x)


// System Include
#include <windows.h>
#include <winsock2.h>
#include <mswSock.h>
#include <commctrl.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <map>
#include <vector>
#include <queue>
#include <random>
#include <Rpc.h>
#include <algorithm>
#include <string>
#include <atltime.h>
#include <dbghelp.h>
#include <Psapi.h>
#include <timeapi.h>
#include <unordered_map>
#include <thread>

#pragma comment(lib,"User32.lib")
#pragma comment(lib,"ws2_32.lib")
#pragma comment(lib,"Rpcrt4.lib")
#pragma comment(lib,"dbghelp.lib")
#pragma comment(lib,"Psapi.lib")
#pragma comment(lib,"Gdi32.lib")
#pragma comment(lib,"Winmm.lib")

#pragma comment (lib, "Crypt32.lib")

#if(GAMESERVER_UPDATE>=701)
#if(NDEBUG==0)
#pragma comment(lib,"..\\..\\..\\Util\\cryptopp\\Debug\\cryptlib.lib")
#else
#pragma comment(lib,"..\\..\\..\\Util\\cryptopp\\Release\\cryptlib.lib")
#endif
#define stdin  (__acrt_iob_func(0))
#define stdout (__acrt_iob_func(1))
#define stderr (__acrt_iob_func(2))

FILE _iob[] = { *stdin, *stdout, *stderr };
extern "C" FILE * __cdecl __iob_func(void) { return _iob; }

#pragma comment(lib,"..\\..\\..\\Util\\mapm\\mapm.lib")
#endif

typedef char chr;

typedef float flt;

typedef short shrt;

typedef unsigned __int64 QWORD;