#include "stdafx.h"
#include "SkillHackSpeedCheck.h"
#include "ServerInfo.h"
#include "MemScript.h"
#include "Util.h"
#include "Log.h"

CSkillHackSpeedCheck gSkillHackSpeedCheck;

CSkillHackSpeedCheck::CSkillHackSpeedCheck()
{
	this->m_SkillHackSpeedCheckObj.clear();
}

CSkillHackSpeedCheck::~CSkillHackSpeedCheck()
{
	this->m_SkillHackSpeedCheckObj.clear();
}

void CSkillHackSpeedCheck::Load(char* path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->m_SkillHackSpeedCheckObj.clear();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			SKILL_HACK_SPEED_CHECK_OBJ info;

			info.skill = lpMemScript->GetNumber();

			SKILL_HACK_SPEED_CHECK_INFO skillHackInfo;

			skillHackInfo.MinSpeed = lpMemScript->GetAsNumber();

			skillHackInfo.MaxSpeed = lpMemScript->GetAsNumber();

			skillHackInfo.Delay = lpMemScript->GetAsNumber();

			skillHackInfo.Count = lpMemScript->GetAsNumber();

			std::map<int, SKILL_HACK_SPEED_CHECK_OBJ>::iterator it = this->m_SkillHackSpeedCheckObj.find(info.skill);

			if (it == this->m_SkillHackSpeedCheckObj.end()) {
				info.m_SkillHackSpeedCheckInfo.push_back(skillHackInfo);

				this->m_SkillHackSpeedCheckObj.insert(std::make_pair(info.skill, info));
			}
			else {
				it->second.m_SkillHackSpeedCheckInfo.push_back(skillHackInfo);
			}
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

SKILL_HACK_SPEED_CHECK_OBJ* CSkillHackSpeedCheck::GetSkillInfo(int skill)
{
	std::map<int, SKILL_HACK_SPEED_CHECK_OBJ>::iterator it = this->m_SkillHackSpeedCheckObj.find(skill);

	if (it == this->m_SkillHackSpeedCheckObj.end()) {
		return 0;
	}

	return &it->second;
}

bool CSkillHackSpeedCheck::CheckSkillSpeedHack(int aIndex, int skill)
{
	auto lpInfo = this->GetSkillInfo(skill);

	if (lpInfo == 0) {
		return 1;
	}

	auto lpObj = &gObj[aIndex];

	if (lpObj == 0) {
		return 1;
	}

	lpObj->SkillSpeedHackCount[skill]++;

	int stack = 0;
	int maxStack = lpInfo->m_SkillHackSpeedCheckInfo.size();

	for (auto& skills : lpInfo->m_SkillHackSpeedCheckInfo) {
		stack++;

		if (this->CheckSkillSpeedHackDelay(aIndex, skill, skills.Delay)) {
			if (this->CheckSkillPlayerSpeedMin(aIndex, skills.MinSpeed) && this->CheckSkillPlayerSpeedMax(aIndex, skills.MaxSpeed)) {
				if (gServerInfo.m_SkillHackSpeedCheckDebug == 1) {
					gLog.Output(LOG_HACK, "[%s][%s][%s] Speed Debug Skill: %d, Speed: [%d/%d], Delay: [%d/%d] Count: [%d/%d]"
						, lpObj->Account, lpObj->Name, gDefaultClassInfo.m_className[lpObj->Class].c_str()
						, skill
						, lpObj->PhysiSpeed, skills.MaxSpeed
						, (timeGetTime() - lpObj->SkillSpeedHackDelay[skill]), skills.Delay
						, lpObj->SkillSpeedHackCount[skill], skills.Count
					);
				}

				if (this->CheckSkillSpeedHackCount(aIndex, skill, skills.Count)) {
					gLog.Output(LOG_HACK, "[%s][%s][%s] Suspect Speed Skill: %d, Speed: [%d/%d], Delay: [%d/%d] Count: [%d/%d]"
						, lpObj->Account, lpObj->Name, gDefaultClassInfo.m_className[lpObj->Class].c_str()
						, skill
						, lpObj->PhysiSpeed, skills.MaxSpeed
						, (timeGetTime() - lpObj->SkillSpeedHackDelay[skill]), skills.Delay
						, lpObj->SkillSpeedHackCount[skill], skills.Count
					);
					return 0;
				}
			}
		}
		else {
			if (stack == maxStack) {
				if (this->CheckSkillSpeedHackMaxDelay(aIndex, skill, skills.Delay)) {
					lpObj->SkillSpeedHackCount[skill] = 0;
					lpObj->SkillSpeedHackDelay[skill] = timeGetTime();
				}
			}
		}
	}

	return 1;
}

bool CSkillHackSpeedCheck::CheckSkillSpeedHackDelay(int aIndex, int index, int Delay)
{
	return ((Delay == 0) ? 1 : (((timeGetTime() - gObj[aIndex].SkillSpeedHackDelay[index]) <= ((DWORD)Delay)) ? 1 : 0));
}

bool CSkillHackSpeedCheck::CheckSkillSpeedHackMaxDelay(int aIndex, int index, int MaxDelay)
{
	return ((MaxDelay == 0) ? 1 : (((DWORD)(timeGetTime() - gObj[aIndex].SkillSpeedHackDelay[index]) >= ((DWORD)MaxDelay)) ? 1 : 0));
}

bool CSkillHackSpeedCheck::CheckSkillSpeedHackCount(int aIndex, int index, int Count)
{
	return ((Count == 0) ? 1 : (((++gObj[aIndex].SkillSpeedHackCount[index]) >= ((DWORD)Count)) ? 1 : 0));
}

bool CSkillHackSpeedCheck::CheckSkillPlayerSpeedMin(int aIndex, int Speed)
{
	return (gObj[aIndex].PhysiSpeed >= Speed ? 1 : 0);
}

bool CSkillHackSpeedCheck::CheckSkillPlayerSpeedMax(int aIndex, int Speed)
{
	return (gObj[aIndex].PhysiSpeed <= Speed ? 1 : 0);
}
