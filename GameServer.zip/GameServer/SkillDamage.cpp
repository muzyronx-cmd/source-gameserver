// HackSpeedCheck.cpp: implementation of the CSkillDamage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SkillDamage.h"
#include "MemScript.h"
#include "SerialCheck.h"
#include "Util.h"
#include "Log.h"

CSkillDamage gSkillDamage;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSkillDamage::CSkillDamage()
{
	this->Init();
}

CSkillDamage::~CSkillDamage()
{

}

void CSkillDamage::Init()
{
	for (int i = 0; i < MAX_SKILL_DAMAGE; i++) {
		this->m_SkillDamage[i].Reset();
	}
}

void CSkillDamage::Load(char* path)
{
	CMemScript* lpMemScript = new CMemScript;

	if (lpMemScript == 0)
	{
		ErrorMessageBox(MEM_SCRIPT_ALLOC_ERROR, path);
		return;
	}

	if (lpMemScript->SetBuffer(path) == 0)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
		delete lpMemScript;
		return;
	}

	this->Init();

	try
	{
		while (true)
		{
			if (lpMemScript->GetToken() == TOKEN_END)
			{
				break;
			}

			if (strcmp("end", lpMemScript->GetString()) == 0)
			{
				break;
			}

			SKILL_DAMAGE_INFO info;

			info.Index = lpMemScript->GetNumber();

			info.Damage = lpMemScript->GetAsNumber();

			this->SetInfo(info);
		}
	}
	catch (...)
	{
		ErrorMessageBox(lpMemScript->GetLastError());
	}

	delete lpMemScript;
}

void CSkillDamage::SetInfo(SKILL_DAMAGE_INFO info)
{
	this->m_SkillDamage[info.Index] = info;
}

SKILL_DAMAGE_INFO* CSkillDamage::GetInfo(int index)
{
	if (index < 0 || index >= MAX_SKILL_DAMAGE)
	{
		return 0;
	}

	if (this->m_SkillDamage[index].Index != index)
	{
		return 0;
	}

	return &this->m_SkillDamage[index];
}

void CSkillDamage::DamageSkillCheck(int index, int* damage) {
	SKILL_DAMAGE_INFO * lpInfo = this->GetInfo(index);

	if (lpInfo == 0)
	{
		return;
	}

	(*damage) = ((*damage)*(lpInfo->Damage)) / 100;
}