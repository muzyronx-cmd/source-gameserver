// Duel.h: interface for the CCustomDuel class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "User.h"
#include "Duel.h"

//**********************************************//
//**********************************************//
//**********************************************//

class CCustomDuel
{
public:
	CCustomDuel();
	virtual ~CCustomDuel();
	bool CheckDuel(LPOBJ lpObj, LPOBJ lpTarget);
	bool CheckDuelUser(int aIndex);
	void CheckDuelScore(LPOBJ lpObj, LPOBJ lpTarget);
	void CheckCustomDuelUser();
	void ResetDuel(LPOBJ lpObj);
	void RespawnDuelUser(LPOBJ lpObj);
	void UserDieProc(LPOBJ lpObj, LPOBJ lpTarget);
	void CGDuelStartRecv(PMSG_DUEL_START_RECV* lpMsg, int aIndex);
	void CGDuelOkRecv(PMSG_DUEL_OK_RECV* lpMsg, int aIndex);
	void CGDuelEndRecv(int aIndex);
	void CGDuelEnd(int aIndex);
	bool GCDuelTradeOkButton(int aIndex);
	void GCDuelTradeCancel(LPOBJ lpObj);
	bool CheckDuelUserSpace(LPOBJ lpObj);
	void DuelFinish(LPOBJ lpObj, bool finished);
	void DuelSendItemWinner(int aIndex);
	void GCDuelStartSend(int aIndex, BYTE flag, int bIndex);
	void GCDuelOkSend(int aIndex, int bIndex);
	void GCDuelEndSend(int aIndex, BYTE result);
	void GCDuelScoreSend(int aIndex, int bIndex);
	void GCSendDuelTrade(int aIndex, int bIndex);
};

extern CCustomDuel gCustomDuel;
